"""
Coupe Stanley : % de chances de chaque équipe, mis à jour à chaque calcul (Mitch, 31 oct.).

POURQUOI PAS « le profil des champions » directement : depuis 2008 il y a 17 champions.
Apprendre un modèle sur 17 exemples, c'est apprendre du hasard. Ce qui se mesure bien, par
contre, c'est la FORCE d'une équipe et ce qu'elle vaut pour gagner un match : là on a
~25 000 matchs (saison + séries). Donc :

  1. Elo (cote de force) recalculée match par match depuis 2008-09 avec les résultats de
     l'API NHL. Les réglages (vitesse K, avantage de la glace, poids de l'écart de buts,
     retour vers la moyenne l'été) sont trouvés par une sim : ceux qui prédisent le mieux
     chaque match AVANT qu'il soit joué, sur 17 saisons.
  2. Simulation Monte-Carlo (10 000 fois) du reste de la saison avec le vrai calendrier,
     puis des séries au vrai format (3 premiers de chaque division + 2 meilleurs deuxièmes,
     2-2-1-1-1). Une incertitude sur la force de chaque équipe est ajoutée à chaque essai.
  3. Le test honnête « à pareille date » : pour chaque saison passée, on refait la même
     simulation au même jour de la saison qu'aujourd'hui, avec seulement ce qui était connu
     à ce moment-là, et on regarde quel % on donnait au futur champion. C'est aussi là
     qu'on voit les « patterns » : où étaient classés les champions à pareille date.

Tout est mis en cache dans data/coupe/ (récolte une fois, puis juste la saison en cours).
"""

import copy
import hashlib
import json
import math
import random
import time
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

import nhl_api as api

RACINE = Path(__file__).resolve().parent.parent
DIR = RACINE / "data" / "coupe"
PREMIERE = 2008
# Abréviations qui ont existé depuis 2008 (Atlanta -> Winnipeg 2011, Phoenix -> Arizona -> Utah)
EQUIPES = ["ANA", "BOS", "BUF", "CGY", "CAR", "CHI", "COL", "CBJ", "DAL", "DET", "EDM", "FLA", "LAK", "MIN",
           "MTL", "NSH", "NJD", "NYI", "NYR", "OTT", "PHI", "PIT", "SJS", "SEA", "STL", "TBL", "TOR", "UTA",
           "VAN", "VGK", "WSH", "WPG", "ATL", "PHX", "ARI"]
# Même franchise : l'Elo suit la franchise quand elle déménage
FRANCHISE = {"ATL": "WPG", "PHX": "ARI", "ARI": "UTA"}
BUDGET_S = 240
N_SIM = 10000
N_SIM_TEST = 2000
P_PROLONG = 0.23          # part des matchs qui vont en prolongation (le perdant prend 1 point)
SIGMA = 35.0              # incertitude sur la force d'une équipe dans chaque essai (points Elo)
# Saisons au format actuel des séries (divisions) : on saute la bulle 2019-20 et 2020-21 (divisions spéciales)
SAISONS_TEST = [f"{y}{y + 1}" for y in list(range(2013, 2019)) + list(range(2021, 2026))]


def _fr(t):
    while t in FRANCHISE:
        t = FRANCHISE[t]
    return t


def _lire(f, defaut):
    try:
        return json.loads(Path(f).read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return defaut


def _ecrire(f, data):
    Path(f).parent.mkdir(parents=True, exist_ok=True)
    Path(f).write_text(json.dumps(data, separators=(",", ":"), ensure_ascii=False), encoding="utf-8")


# =================================================================================
# 1. Récolte : tous les matchs (saison + séries) depuis 2008-09
# =================================================================================

def _matchs_saison(saison, equipes):
    """{gid: [date, type (2 saison, 3 séries), local, visiteur, buts loc, buts vis, fin, état]}."""
    chemins = [f"/club-schedule-season/{t}/{saison}" for t in equipes]
    api.fetch_many(chemins)
    out = {}
    for c in chemins:
        sch = api.get_json(c) or {}
        for g in sch.get("games", []) or []:
            if g.get("gameType") not in (2, 3) or not g.get("id"):
                continue
            h, a = g.get("homeTeam") or {}, g.get("awayTeam") or {}
            fin = (g.get("gameOutcome") or {}).get("lastPeriodType") or (g.get("periodDescriptor") or {}).get("periodType")
            out[str(g["id"])] = [g.get("gameDate"), g["gameType"], h.get("abbrev"), a.get("abbrev"),
                                 h.get("score"), a.get("score"), fin, g.get("gameState")]
    return out


def recolter(saison_courante):
    """Saisons passées : une fois (cache). Saison en cours : chaque calcul (résultats + calendrier)."""
    t0 = time.time()
    sc = str(saison_courante)
    an_c = int(sc[:4])
    for an in range(PREMIERE, an_c):
        s = f"{an}{an + 1}"
        f = DIR / f"{s}.json"
        if f.exists():
            continue
        if time.time() - t0 > BUDGET_S:
            break
        m = {g: v for g, v in _matchs_saison(s, EQUIPES).items() if v[7] in ("OFF", "FINAL")}
        if m:
            _ecrire(f, m)
    _ecrire(DIR / f"{sc}.json", _matchs_saison(sc, EQUIPES[:32]))


def charger(saison_courante):
    """Tous les matchs connus, en ordre de date : (date, saison, type, local, visiteur, bl, bv, fin, état, gid)."""
    out = []
    an_c = int(str(saison_courante)[:4])
    for an in range(PREMIERE, an_c + 1):
        s = f"{an}{an + 1}"
        for gid, v in _lire(DIR / f"{s}.json", {}).items():
            if v[0]:
                out.append((v[0], s, v[1], v[2], v[3], v[4], v[5], v[6], v[7], gid))
    out.sort(key=lambda r: (r[0], r[9]))
    return out


def joue(r):
    return r[8] in ("OFF", "FINAL") and r[5] is not None and r[6] is not None


# =================================================================================
# 2. Elo
# =================================================================================

class Elo:
    def __init__(self, K, hfa, mov, reg):
        self.K, self.hfa, self.mov, self.reg = K, hfa, mov, reg
        self.r = defaultdict(lambda: 1500.0)
        self.saison = None

    def p_local(self, h, a, bonus=0.0):
        return 1 / (1 + 10 ** (-(self.r[_fr(h)] + self.hfa + bonus - self.r[_fr(a)]) / 400))

    def nouvelle_saison(self, s):
        if self.saison is not None:
            for t in list(self.r):
                self.r[t] = 1500 + (self.r[t] - 1500) * (1 - self.reg)
        self.saison = s

    def ajouter(self, h, a, bh, ba, fin):
        p = self.p_local(h, a)
        y = 1.0 if bh > ba else 0.0
        ecart = abs(bh - ba) if fin not in ("SO",) else 1
        mult = 1 + self.mov * (math.log(ecart + 1) - math.log(2))
        d = self.K * mult * (y - p)
        self.r[_fr(h)] += d
        self.r[_fr(a)] -= d
        return p, y


GRILLE = {"K": [4, 6, 8, 10, 12], "hfa": [15, 30, 45], "mov": [0.0, 0.6, 1.2], "reg": [0.25, 0.4, 0.55]}


def regler(matchs, log=print):
    """Les réglages qui prédisent le mieux chaque match avant qu'il soit joué (2009-10 et +)."""
    rows = [r for r in matchs if joue(r)]
    meilleur = None
    for K in GRILLE["K"]:
        for hfa in GRILLE["hfa"]:
            for mov in GRILLE["mov"]:
                for reg in GRILLE["reg"]:
                    E = Elo(K, hfa, mov, reg)
                    ll = n = 0
                    for r in rows:
                        if r[1] != E.saison:
                            E.nouvelle_saison(r[1])
                        p, y = E.ajouter(r[3], r[4], r[5], r[6], r[7])
                        if int(r[1][:4]) >= PREMIERE + 1:
                            ll -= math.log(p if y else 1 - p); n += 1
                    if n and (meilleur is None or ll / n < meilleur[0]):
                        meilleur = (ll / n, {"K": K, "hfa": hfa, "mov": mov, "reg": reg, "logloss": round(ll / n, 5), "n": n})
    if meilleur:
        log(f"  coupe : Elo réglé {meilleur[1]}")
    return meilleur[1] if meilleur else {"K": 8, "hfa": 30, "mov": 0.6, "reg": 0.4, "logloss": None, "n": 0}


# =================================================================================
# 3. Simulation : reste de la saison + séries
# =================================================================================

def _serie(pa, pb_dom, rng):
    """Série 4 de 7, l'équipe A a l'avantage de la glace (matchs 1, 2, 5, 7 chez elle).
    pa = P(A gagne chez elle), pb_dom = P(B gagne chez elle). Retourne True si A gagne."""
    wa = wb = 0
    for i in range(7):
        chez_a = i in (0, 1, 4, 6)
        a_gagne = rng.random() < (pa if chez_a else 1 - pb_dom)
        wa += a_gagne; wb += not a_gagne
        if wa == 4 or wb == 4:
            return wa == 4
    return wa > wb


def simuler(E, equipes, restants, n_sim=N_SIM, sigma=SIGMA, graine=0, calendrier=None):
    """equipes : {abbr: {"pts", "pj", "rw", "div", "conf"}} (classement actuel).
    restants : [(local, visiteur)] matchs pas encore joués.
    calendrier : [(local, visiteur, déjà joué)] TOUS les matchs de la saison, en ordre. Si donné, chaque
    simulation a son propre fil de hasard et chaque match garde ses 2 tirages d'un jour à l'autre (on tire
    même pour les matchs déjà joués, et on les saute) : les % ne bougent que si un vrai match a changé
    quelque chose, pas à cause du tirage au sort.
    Retourne {abbr: {"proj", "p_series", "p_r2", "p_finale_conf", "p_finale", "p_coupe"}}."""
    rng = random.Random(graine)
    abbrs = sorted(equipes)
    acc = {t: defaultdict(float) for t in abbrs}
    # Rang final dans l'association, à chaque simulation : rangs[t][k] = nb de fois que t finit (k+1)e
    rangs = {t: [0] * 16 for t in abbrs}
    base = {t: E.r[_fr(t)] for t in abbrs}
    jeux = calendrier if calendrier is not None else [(h, a, False) for h, a in restants]
    for it in range(n_sim):
        if calendrier is not None:
            rng = random.Random(graine * 1_000_003 + it)
        force = {t: base[t] + rng.gauss(0, sigma) for t in abbrs}
        pts = {t: equipes[t]["pts"] for t in abbrs}
        rw = {t: equipes[t].get("rw", 0) for t in abbrs}
        for h, a, fait in jeux:
            u1, u2 = rng.random(), rng.random()
            if fait or h not in force or a not in force:
                continue
            p = 1 / (1 + 10 ** (-(force[h] + E.hfa - force[a]) / 400))
            g, perd = (h, a) if u1 < p else (a, h)
            pts[g] += 2
            if u2 < P_PROLONG:
                pts[perd] += 1
            else:
                rw[g] += 1
        for t in abbrs:
            acc[t]["proj"] += pts[t]
        cle = lambda t: (pts[t], rw[t], rng.random())
        acc[max(abbrs, key=cle)]["p_presidents"] += 1      # Trophée des Présidents
        champions_conf = []
        for conf in sorted({equipes[t]["conf"] for t in abbrs}):
            eqc = [t for t in abbrs if equipes[t]["conf"] == conf]
            for k, t in enumerate(sorted(eqc, key=cle, reverse=True)[:16]):
                rangs[t][k] += 1
            divs = sorted({equipes[t]["div"] for t in eqc})
            if len(divs) != 2:
                continue
            tops, reste = {}, []
            for d in divs:
                ordre = sorted([t for t in eqc if equipes[t]["div"] == d], key=cle, reverse=True)
                tops[d] = ordre[:3]; reste += ordre[3:]
            wc = sorted(reste, key=cle, reverse=True)[:2]
            if len(wc) < 2 or any(len(v) < 3 for v in tops.values()):
                continue
            d1, d2 = sorted(divs, key=lambda d: cle(tops[d][0]), reverse=True)
            for t in tops[d1] + tops[d2] + wc:
                acc[t]["p_series"] += 1
            # Le meilleur 1er affronte le 2e as, l'autre 1er le 1er as
            moities = [[(tops[d1][0], wc[1]), (tops[d1][1], tops[d1][2])],
                       [(tops[d2][0], wc[0]), (tops[d2][1], tops[d2][2])]]
            gagnants_div = []
            for moitie in moities:
                w = []
                for a, b in moitie:
                    w.append(_duel(a, b, force, cle, E, rng))
                for t in w:
                    acc[t]["p_r2"] += 1
                gagnants_div.append(_duel(w[0], w[1], force, cle, E, rng))
            for t in gagnants_div:
                acc[t]["p_finale_conf"] += 1
            champ = _duel(gagnants_div[0], gagnants_div[1], force, cle, E, rng)
            acc[champ]["p_finale"] += 1
            champions_conf.append(champ)
        if len(champions_conf) == 2:
            acc[_duel(champions_conf[0], champions_conf[1], force, cle, E, rng)]["p_coupe"] += 1
    out = {}
    for t in abbrs:
        a = acc[t]
        out[t] = {"proj": round(a["proj"] / n_sim, 1)} | {k: round(a[k] / n_sim, 4)
                                                         for k in ("p_series", "p_r2", "p_finale_conf", "p_finale", "p_coupe", "p_presidents")}
        n_conf = sum(1 for u in abbrs if equipes[u].get("conf") == equipes[t].get("conf"))
        out[t]["rangs"] = [round(c / n_sim, 4) for c in rangs[t][:n_conf]]
    return out


def _duel(a, b, force, cle, E, rng):
    """Série entre a et b : avantage de la glace au meilleur classement de saison."""
    if cle(b) > cle(a):
        a, b = b, a
    pa = 1 / (1 + 10 ** (-(force[a] + E.hfa - force[b]) / 400))
    pb = 1 / (1 + 10 ** (-(force[b] + E.hfa - force[a]) / 400))
    return a if _serie(pa, pb, rng) else b


# =================================================================================
# 4. Classement à une date (calculé à partir des matchs) + test à pareille date
# =================================================================================

def classement_matchs(matchs, saison, jusqua, divisions):
    """Points, PJ, victoires en temps réglementaire au soir du `jusqua` (exclu), à partir des matchs."""
    eq = {t: {"pts": 0, "pj": 0, "rw": 0, "div": divisions[t][0], "conf": divisions[t][1]} for t in divisions}
    for r in matchs:
        if r[1] != saison or r[2] != 2 or r[0] >= jusqua or not joue(r):
            continue
        h, a, bh, ba, fin = r[3], r[4], r[5], r[6], r[7]
        if h not in eq or a not in eq:
            continue
        g, p = (h, a) if bh > ba else (a, h)
        eq[g]["pts"] += 2; eq[h]["pj"] += 1; eq[a]["pj"] += 1
        if fin in ("OT", "SO"):
            eq[p]["pts"] += 1
        else:
            eq[g]["rw"] += 1
    return eq


def champion(matchs, saison):
    """Le gagnant du dernier match de séries de la saison."""
    po = [r for r in matchs if r[1] == saison and r[2] == 3 and joue(r)]
    if not po:
        return None
    r = max(po, key=lambda r: (r[0], r[9]))
    return r[3] if r[5] > r[6] else r[4]


def divisions_a(date_iso):
    """{abbr: (division, conférence)} selon l'API (classement d'une date)."""
    st = api.get_json(f"/standings/{date_iso}") or {}
    out = {}
    for s in st.get("standings", []) or []:
        t = (s.get("teamAbbrev") or {}).get("default")
        if t:
            out[t] = (s.get("divisionAbbrev"), s.get("conferenceAbbrev"))
    return out


def debut_saison(matchs, saison):
    d = [r[0] for r in matchs if r[1] == saison and r[2] == 2]
    return min(d) if d else None


def tester(matchs, params, jour, saison_courante, log=print):
    """Pour chaque saison passée : même jour de saison qu'aujourd'hui, seulement le connu à ce moment-là."""
    sc = str(saison_courante)
    d0 = debut_saison(matchs, sc)
    if not d0:
        return []
    jours = (date.fromisoformat(jour) - date.fromisoformat(d0)).days
    cibles = {}
    for s in SAISONS_TEST:
        ds = debut_saison(matchs, s)
        ch = champion(matchs, s)
        if ds and ch:
            cibles[s] = ((date.fromisoformat(ds) + timedelta(days=max(0, jours))).isoformat(), ch)
    E = Elo(params["K"], params["hfa"], params["mov"], params["reg"])
    out = []
    for r in matchs + [("9999-99-99", None, None, None, None, None, None, None, None, None)]:
        for s, (dc, ch) in list(cibles.items()):
            if r[0] >= dc and E.saison == s:
                divs = divisions_a(dc)
                if len(divs) >= 30:
                    eq = classement_matchs(matchs, s, dc, divs)
                    rest = [(x[3], x[4]) for x in matchs if x[1] == s and x[2] == 2 and x[0] >= dc]
                    sim = simuler(E, eq, rest, N_SIM_TEST)
                    rang_pts = sorted(eq, key=lambda t: (eq[t]["pts"] / max(1, eq[t]["pj"]), eq[t]["rw"]), reverse=True)
                    rang_elo = sorted(eq, key=lambda t: E.r[_fr(t)], reverse=True)
                    rang_sim = sorted(sim, key=lambda t: sim[t]["p_coupe"], reverse=True)
                    out.append({"saison": s, "date": dc, "champion": ch, "p_coupe": sim.get(ch, {}).get("p_coupe"),
                                "rang_pts": rang_pts.index(ch) + 1 if ch in rang_pts else None,
                                "rang_elo": rang_elo.index(ch) + 1 if ch in rang_elo else None,
                                "rang_sim": rang_sim.index(ch) + 1 if ch in rang_sim else None,
                                "favori": rang_sim[0], "p_favori": sim[rang_sim[0]]["p_coupe"]})
                    log(f"  coupe : test {s} au {dc} : {ch} avait {out[-1]['p_coupe']:.1%} (rang {out[-1]['rang_sim']})")
                del cibles[s]
        if r[1] is None:
            break
        if r[1] != E.saison:
            E.nouvelle_saison(r[1])
        if joue(r):
            E.ajouter(r[3], r[4], r[5], r[6], r[7])
    return out


# =================================================================================
# 4b. Trophées d'équipe : Présidents (dans simuler), Jennings, Jack Adams
# =================================================================================

JACK_ADAMS = {"20092010": "ARI", "20102011": "PIT", "20112012": "STL", "20122013": "OTT", "20132014": "COL",
              "20142015": "CGY", "20152016": "WSH", "20162017": "CBJ", "20172018": "VGK", "20182019": "NYI",
              "20192020": "BOS", "20202021": "CAR", "20212022": "CGY", "20222023": "BOS", "20232024": "VAN",
              "20242025": "WSH", "20252026": "TBL"}
K_GA = 10          # matchs « fictifs » à la moyenne de la ligue pour les buts accordés


def bilan_equipes(matchs, saison, jusqua):
    """{équipe: {"pj", "pts", "bc", "rest"}} au soir de `jusqua` (exclu), saison régulière."""
    out = defaultdict(lambda: {"pj": 0, "pts": 0, "bc": 0, "rest": 0})
    for r in matchs:
        if r[1] != saison or r[2] != 2:
            continue
        h, a = r[3], r[4]
        if r[0] < jusqua and joue(r):
            for t, bf, bc in ((h, r[5], r[6]), (a, r[6], r[5])):
                o = out[t]; o["pj"] += 1; o["bc"] += bc
                o["pts"] += 2 if bf > bc else (1 if r[7] in ("OT", "SO") else 0)
        else:
            out[h]["rest"] += 1; out[a]["rest"] += 1
    return dict(out)


def jennings(bil, n_sim=N_SIM, graine=1):
    """P(le moins de buts accordés à la fin) : rythme de chaque équipe ramené vers la ligue."""
    # Un fil de hasard par équipe : une équipe qui n'a pas joué garde exactement ses fins de saison d'hier
    rngs = {t: random.Random(graine * 1_000_003 + sum(map(ord, t)) * 131 + len(t)) for t in bil}
    tot_bc = sum(v["bc"] for v in bil.values()); tot_pj = sum(v["pj"] for v in bil.values())
    lig = tot_bc / tot_pj if tot_pj else 3.0
    taux = {t: (v["bc"] + lig * K_GA) / (v["pj"] + K_GA) for t, v in bil.items()}
    gains, proj = defaultdict(float), defaultdict(float)
    for _ in range(n_sim):
        fin = {}
        for t, v in bil.items():
            rng = rngs[t]
            lam = taux[t] * rng.gammavariate(30, 1 / 30) * v["rest"]
            fin[t] = v["bc"] + max(0.0, rng.gauss(lam, math.sqrt(max(lam, 1e-9))))
            proj[t] += fin[t]
        gains[min(fin, key=fin.get)] += 1
    return {t: {"p": gains[t] / n_sim, "proj": proj[t] / n_sim} for t in bil}


def elo_debut_saisons(matchs, params):
    """Elo de chaque équipe au 1er match de chaque saison (après le retour vers la moyenne de l'été)."""
    E = Elo(params["K"], params["hfa"], params["mov"], params["reg"])
    out = {}
    for r in matchs:
        if r[1] != E.saison:
            E.nouvelle_saison(r[1])
            out[r[1]] = None
        if out.get(r[1]) is None and r[2] == 2:
            out[r[1]] = {t: E.r[_fr(t)] for t in EQUIPES}
        if joue(r):
            E.ajouter(r[3], r[4], r[5], r[6], r[7])
    return out


def _pct_attendu(r):
    return 1 / (1 + 10 ** (-(r - 1500) / 400))


def score_adams(lignes, w):
    """lignes : [(équipe, % de points, % attendu)] -> score : surperformance vs attentes + succès."""
    def z(vs):
        m = sum(vs) / len(vs); sd = (sum((x - m) ** 2 for x in vs) / len(vs)) ** 0.5 or 1
        return [(x - m) / sd for x in vs]
    sur = z([p - e for _, p, e in lignes]); suc = z([p for _, p, _ in lignes])
    return [w * a + (1 - w) * b for a, b in zip(sur, suc)]


def _soft(s, tau):
    m = max(s); e = [math.exp((x - m) / tau) for x in s]; t = sum(e)
    return [x / t for x in e]


def regler_adams(matchs, params, debuts):
    meilleur = None
    for w in (0.4, 0.55, 0.7, 0.85, 1.0):
        for tau in (0.3, 0.5, 0.8, 1.2):
            ll = n = 0
            for s, g in JACK_ADAMS.items():
                if s not in debuts or not debuts[s]:
                    continue
                bil = bilan_equipes(matchs, s, "9999")
                lignes = [(t, v["pts"] / (2 * v["pj"]), _pct_attendu(debuts[s].get(t, 1500))) for t, v in bil.items() if v["pj"]]
                i = next((k for k, l in enumerate(lignes) if _fr(l[0]) == _fr(g)), None)
                if i is None:
                    continue
                ll += math.log(max(_soft(score_adams(lignes, w), tau)[i], 1e-9)); n += 1
            if n and (meilleur is None or ll / n > meilleur[0]):
                meilleur = (ll / n, {"w": w, "tau": tau, "n": n})
    return meilleur[1] if meilleur else None


def trophees_equipe(matchs, params, sim, sc, jour, etat, log=print):
    """Jennings, Jack Adams et le test à pareille date des trophées d'équipe."""
    out = {}
    bil = bilan_equipes(matchs, sc, jour)
    j = jennings(bil)
    out["jennings"] = sorted([{"t": t, "p": round(v["p"], 4), "bc": bil[t]["bc"], "pj": bil[t]["pj"], "proj": round(v["proj"])}
                              for t, v in j.items()], key=lambda x: -x["p"])[:10]
    out["presidents"] = sorted([{"t": t, "p": v.get("p_presidents", 0), "pts": None, "proj": v["proj"]} for t, v in sim.items()],
                               key=lambda x: -x["p"])[:10]
    debuts = elo_debut_saisons(matchs, params)
    pa = etat.get("adams")
    if not pa or etat.get("adams_n") != len(debuts):
        pa = regler_adams(matchs, params, debuts)
        etat["adams"], etat["adams_n"] = pa, len(debuts)
    if pa and debuts.get(sc):
        lignes = [(t, (sim[t]["proj"] / (2 * 82)) if t in sim else 0.5, _pct_attendu(debuts[sc].get(t, 1500))) for t in sim]
        pr = _soft(score_adams(lignes, pa["w"]), pa["tau"])
        out["adams"] = sorted([{"t": t, "p": round(p, 4), "pct": round(pc, 3), "attendu": round(e, 3)}
                               for (t, pc, e), p in zip(lignes, pr)], key=lambda x: -x["p"])[:10]
        out["adams_params"] = pa
    # À pareille date (léger : seulement les matchs)
    d0 = debut_saison(matchs, sc)
    jours = (date.fromisoformat(jour) - date.fromisoformat(d0)).days if d0 else 0
    tests = {"jennings": [], "adams": [], "presidents": []}
    for an in range(PREMIERE + 2, int(sc[:4])):
        s = f"{an}{an + 1}"
        if s in ("20122013", "20202021"):
            continue
        ds = debut_saison(matchs, s)
        if not ds:
            continue
        dc = (date.fromisoformat(ds) + timedelta(days=jours)).isoformat()
        b_dc, b_fin = bilan_equipes(matchs, s, dc), bilan_equipes(matchs, s, "9999")
        if not b_dc or not b_fin:
            continue
        # Jennings
        g = min((t for t in b_fin if b_fin[t]["pj"]), key=lambda t: b_fin[t]["bc"] / b_fin[t]["pj"] * 82)
        jj = jennings(b_dc, 1000)
        rang = sorted((t for t in b_dc if b_dc[t]["pj"]), key=lambda t: b_dc[t]["bc"] / b_dc[t]["pj"])
        tests["jennings"].append({"saison": s, "gagnant": g, "rang_stat": rang.index(g) + 1 if g in rang else None,
                                  "meneur": rang[0] if rang else None, "p": round(jj.get(g, {}).get("p", 0), 4)})
        # Présidents (meilleur % de points au soir de dc)
        gp = max(b_fin, key=lambda t: (b_fin[t]["pts"], -b_fin[t]["pj"]))
        rang = sorted((t for t in b_dc if b_dc[t]["pj"]), key=lambda t: -b_dc[t]["pts"] / (2 * b_dc[t]["pj"]))
        tests["presidents"].append({"saison": s, "gagnant": gp, "rang_stat": rang.index(gp) + 1 if gp in rang else None,
                                    "meneur": rang[0] if rang else None, "p": None})
        # Jack Adams
        ga = JACK_ADAMS.get(s)
        if pa and debuts.get(s) and ga:
            lig = [(t, v["pts"] / (2 * v["pj"]), _pct_attendu(debuts[s].get(t, 1500))) for t, v in b_dc.items() if v["pj"]]
            pr = _soft(score_adams(lig, pa["w"]), pa["tau"])
            ordre = sorted(range(len(lig)), key=lambda k: -pr[k])
            k = next((k for k, l in enumerate(lig) if _fr(l[0]) == _fr(ga)), None)
            tests["adams"].append({"saison": s, "gagnant": ga, "rang_stat": (ordre.index(k) + 1) if k is not None else None,
                                   "meneur": lig[ordre[0]][0], "p": round(pr[k], 4) if k is not None else 0.0})
    out["tests"] = tests
    return out


# =================================================================================
# 5. Le calcul de tous les jours
# =================================================================================

def calculer(saison_courante, jour, log=print):
    """Retourne le bloc "coupe" de data.json (ou None si pas de données)."""
    try:
        recolter(saison_courante)
    except Exception as ex:  # noqa: BLE001
        log(f"  coupe : récolte incomplète ({str(ex)[:100]})")
    matchs = charger(saison_courante)
    sc = str(saison_courante)
    if not any(r[1] == sc for r in matchs):
        return None
    etat = _lire(DIR / "etat.json", {})
    params = etat.get("params")
    n_saisons = len({r[1] for r in matchs})
    if not params or etat.get("n_saisons") != n_saisons or \
            (date.fromisoformat(jour) - date.fromisoformat(etat.get("regle", "2000-01-01"))).days >= 28:
        params = regler(matchs, log)
        etat.update({"params": params, "n_saisons": n_saisons, "regle": jour})
    # Elo à jour (jusqu'à hier soir)
    E = Elo(params["K"], params["hfa"], params["mov"], params["reg"])
    for r in matchs:
        if r[1] != E.saison:
            E.nouvelle_saison(r[1])
        if joue(r) and r[0] < jour:
            E.ajouter(r[3], r[4], r[5], r[6], r[7])
    st = api.standings_now() or {}
    eq = {}
    for s in st.get("standings", []) or []:
        t = (s.get("teamAbbrev") or {}).get("default")
        if t:
            eq[t] = {"pts": s.get("points", 0), "pj": s.get("gamesPlayed", 0), "rw": s.get("regulationWins", 0),
                     "div": s.get("divisionAbbrev"), "conf": s.get("conferenceAbbrev")}
    if len(eq) < 30:
        log("  coupe : classement indisponible")
        return None
    deja = {r[9] for r in matchs if r[1] == sc and joue(r)}
    restants = [(r[3], r[4]) for r in matchs if r[1] == sc and r[2] == 2 and r[9] not in deja]
    sim = simuler(E, eq, restants, calendrier=calendrier(matchs, sc, deja))
    # Test à pareille date (refait une fois par semaine : c'est la partie lourde)
    if (date.fromisoformat(jour) - date.fromisoformat(etat.get("teste", "2000-01-01"))).days >= 7 or not etat.get("test"):
        try:
            etat["test"] = tester(matchs, params, jour, sc, log)
            etat["teste"] = jour
        except Exception as ex:  # noqa: BLE001
            log(f"  coupe : test à pareille date impossible ({str(ex)[:100]})")
    # Historique jour par jour (la courbe de chaque équipe)
    hist = _lire(DIR / "historique.json", {})
    hist[jour] = {t: v["p_coupe"] for t, v in sim.items()}
    _ecrire(DIR / "historique.json", hist)
    _ecrire(DIR / "etat.json", etat)
    jours_h = sorted(d for d in hist if d >= (debut_saison(matchs, sc) or ""))
    equipes = []
    for t, v in sorted(sim.items(), key=lambda kv: -kv[1]["p_coupe"]):
        equipes.append({"t": t, "elo": round(E.r[_fr(t)]), "pts": eq[t]["pts"], "pj": eq[t]["pj"],
                        "div": eq[t]["div"], "conf": eq[t]["conf"], **v,
                        "courbe": [hist[d].get(t) for d in jours_h]})
    test = etat.get("test") or []
    try:
        equipe_tr = trophees_equipe(matchs, params, sim, sc, jour, etat, log)
        _ecrire(DIR / "etat.json", etat)
    except Exception as ex:  # noqa: BLE001
        log(f"  coupe : trophées d'équipe impossibles ({str(ex)[:100]})")
        equipe_tr = None
    veille = None
    try:
        veille = ecarts_veille(matchs, params, sc, jour, eq, deja, sim, equipe_tr, equipes, etat, log)
    except Exception as ex:  # noqa: BLE001
        log(f"  coupe : écart avec la veille impossible ({str(ex)[:100]})")
    return {"date": jour, "n_sim": N_SIM, "params": params, "jours": jours_h, "equipes": equipes, "test": test,
            "trophees_equipe": equipe_tr, "veille": veille,
            "n_matchs": sum(1 for r in matchs if joue(r)), "n_saisons": n_saisons,
            "restants": len(restants)}


# =================================================================================
# Écart avec la veille, et pourquoi (Coupe, Présidents, Jennings, Jack Adams)
# =================================================================================
# Même règle que les trophées de joueurs : l'écart vient seulement des matchs joués depuis la veille.
# Si l'algo a changé, les % de la veille sont refaits avec l'algo d'aujourd'hui (classement et matchs
# de la veille gardés dans data/coupe/veille.json).
_SOURCE = hashlib.sha1(Path(__file__).read_bytes()).hexdigest()
CLES = ("p_series", "p_r2", "p_finale_conf", "p_finale", "p_coupe", "p_presidents")


def calendrier(matchs, sc, deja):
    return [(r[3], r[4], r[9] in deja) for r in matchs if r[1] == sc and r[2] == 2]


def _pts_pct(x):
    return f"{x * 100:+.1f}".replace(".", ",")


def resultats_entre(matchs, sc, debut, fin):
    """{équipe: ["victoire 4-2 contre BOS", ...]} pour les matchs joués de `debut` (inclus) à `fin` (exclu)."""
    out = defaultdict(list)
    for r in matchs:
        if r[1] != sc or not joue(r) or not (debut <= r[0] < fin):
            continue
        h, a, bh, ba, f = r[3], r[4], r[5], r[6], r[7]
        suffixe = " (prol.)" if f == "OT" else " (tirs de barrage)" if f == "SO" else ""
        for t, adv, bp, bc, dom in ((h, a, bh, ba, True), (a, h, ba, bh, False)):
            out[t].append(f"{'victoire' if bp > bc else 'défaite'} {bp}-{bc} {'contre' if dom else 'à'} {adv}{suffixe}")
    return out


def raisons_equipes(lignes, p_now, p_ref, res, conf=None):
    """Ajoute dp, rang_av et raison à chaque ligne ({"t": équipe, ...})."""
    ids = set(p_now) | set(p_ref)
    delta = {t: p_now.get(t, 0.0) - p_ref.get(t, 0.0) for t in ids}
    rang_ref = {t: k + 1 for k, t in enumerate(sorted(p_ref, key=lambda t: -p_ref[t]))}
    for x in lignes:
        t = x["t"]
        dp = delta.get(t, 0.0)
        x["dp"] = round(dp, 4)
        x["rang_av"] = rang_ref.get(t)
        propre = res.get(t) or []
        morceaux = ["; ".join(propre) if propre else "n'a pas joué"]
        gagne = any(m.startswith("victoire") for m in propre)
        if abs(dp) >= 0.003 and (not propre or (dp < 0 and gagne) or (dp > 0 and not gagne)):
            autres = [u for u in ids if u != t and (conf is None or conf.get(u) == conf.get(t))]
            if autres:
                u = max(autres, key=delta.get) if dp < 0 else min(autres, key=delta.get)
                if (delta[u] > 0) == (dp < 0) and abs(delta[u]) >= 0.003:
                    morceaux.append(f"{u} {'monte' if delta[u] > 0 else 'recule'} ({_pts_pct(delta[u])}) : "
                                    + ("; ".join(res.get(u) or []) or "n'a pas joué"))
        if abs(dp) < 0.002:
            morceaux.insert(0, "stable")
        x["raison"] = " · ".join(morceaux)


def ecarts_veille(matchs, params, sc, jour, eq, deja, sim, equipe_tr, equipes, etat, log=print):
    sig = hashlib.sha1(f"{_SOURCE}|{json.dumps(params, sort_keys=True)}|{json.dumps(etat.get('adams'), sort_keys=True)}|{N_SIM}".encode()).hexdigest()[:12]
    te = {k: {x["t"]: x["p"] for x in (equipe_tr or {}).get(k) or []} for k in ("jennings", "presidents", "adams")}
    V = _lire(DIR / "veille.json", {})
    avant = sorted(j for j in V if j < jour)
    if avant:
        jr = avant[-1]
        ref = V[jr]
        if ref.get("sig") == sig:
            sim_ref, te_ref, recalc = ref["sim"], ref["te"], False
        else:
            # Algo changé : la veille refaite avec l'algo d'aujourd'hui (Elo jusqu'à la veille, classement de la veille)
            E = Elo(params["K"], params["hfa"], params["mov"], params["reg"])
            for r in matchs:
                if r[1] != E.saison:
                    E.nouvelle_saison(r[1])
                if joue(r) and r[0] < jr:
                    E.ajouter(r[3], r[4], r[5], r[6], r[7])
            deja_r = set(ref["deja"])
            rest_r = [(r[3], r[4]) for r in matchs if r[1] == sc and r[2] == 2 and r[9] not in deja_r]
            sim_ref = simuler(E, ref["eq"], rest_r, calendrier=calendrier(matchs, sc, deja_r))
            tr = trophees_equipe(matchs, params, sim_ref, sc, jr, copy.deepcopy(etat), log=lambda *_: None) or {}
            te_ref = {k: {x["t"]: x["p"] for x in tr.get(k) or []} for k in te}
            recalc = True
        res = resultats_entre(matchs, sc, jr, jour)
        conf = {t: v.get("conf") for t, v in eq.items()}
        for x in equipes:       # Coupe : un écart pour chaque étape
            r_ = sim_ref.get(x["t"]) or {}
            x["d"] = {k: round(x.get(k, 0) - r_.get(k, 0), 4) for k in CLES}
        raisons_equipes(equipes, {t: v["p_coupe"] for t, v in sim.items()},
                        {t: v.get("p_coupe", 0) for t, v in sim_ref.items()}, res, conf)
        for k in ("jennings", "presidents", "adams"):
            L = (equipe_tr or {}).get(k)
            if L:
                raisons_equipes(L, te[k], te_ref.get(k, {}), res, None)
        if equipe_tr is not None:
            equipe_tr["veille"] = {"jour": jr, "recalcul": recalc}
    V[jour] = {"sig": sig, "eq": eq, "deja": sorted(deja), "sim": sim, "te": te}
    for j in sorted(V)[:-3]:
        V.pop(j)
    _ecrire(DIR / "veille.json", V)
    return {"jour": jr, "recalcul": recalc} if avant else None
