"""
Registre des joueurs : les tendances propres à chaque joueur (Mitch, 26 oct.).

Le ML et les recettes voient les stats d'un joueur (tirs/60, TOI, PP...), mais pas QUI il
est : un gars qui tire beaucoup plus à domicile, qui disparaît en back-to-back, qui finit
mieux que ses xG, qui est tout-ou-rien... Le registre garde, pour chaque joueur, des ratios
(1.00 = comme la ligue) :

  dom / ext   tirs/60 à domicile et à l'étranger, comparés à SON rythme normal
  b2b         tirs/60 le 2e soir d'un back-to-back
  phys / doux tirs/60 contre les équipes physiques (beaucoup de mises en échec) et les autres
  ppf / ppl   tirs/60 les soirs avec beaucoup de PP (2+ min) et presque pas (< 0.5 min)
  fin         buts ÷ xGoals (MoneyPuck) : finisseur ou pas
  pas         passes ÷ xG de son équipe quand il est sur la glace : passeur ou pas
  disp        régularité : tout-ou-rien (> 1) ou toujours pareil (< 1)

Chaque ratio est comparé à ce que la ligue fait dans la même situation (ex. tout le monde tire
un peu plus à domicile : la recette le sait déjà, le registre garde juste l'écart du joueur).

CRÉDIBILITÉ (comme les actuaires pour les primes d'assurance) : un ratio est ramené vers 1
selon la quantité de données. ratio = 1 + (brut − 1) × n / (n + k). McDavid avec 300 matchs :
son ratio compte presque au complet. Une recrue avec 15 matchs : presque rien. Sans ça, la
sim trouverait des « tendances » qui sont juste de la chance (5 tirs 3 fois contre Boston).

LA SIM (une grosse run, gardée dans data/registre/registre.json) : pour chaque tendance, on
essaie plusieurs forces de rappel (k) et plusieurs mémoires (demi-vie : les 41, 82, 164
derniers matchs du joueur, ou toute sa carrière dans nos données) et on garde la combinaison
qui PRÉDIT le mieux les matchs suivants (chaque match prédit seulement avec les matchs
d'avant, sur 3 saisons + la saison en cours jusqu'à la coupe). Une tendance qui n'aide pas
est fermée (ratio = 1 pour tout le monde) : c'est la sim qui le dit, pas moi.
Ensuite, chaque calcul ajoute les nouveaux matchs au registre (quelques secondes) ; la sim
lourde est refaite aux 4 semaines ou quand les données changent (nouvelle saison récoltée).
"""

import json
import math
from collections import defaultdict
from datetime import date
from pathlib import Path

SPLITS = ["dom", "b2b", "phys", "pp"]
TENDANCES = SPLITS + ["fin", "pas", "disp"]
# Côtés affichés : (tendance, côté) -> nom court
COTES = {("dom", "in"): "dom", ("dom", "out"): "ext", ("b2b", "in"): "b2b", ("phys", "in"): "phys",
         ("phys", "out"): "doux", ("pp", "in"): "ppf", ("pp", "out"): "ppl"}
NOMS = {"dom": "À domicile", "ext": "À l'étranger", "b2b": "Back-to-back", "phys": "Vs équipes physiques",
        "doux": "Vs équipes pas physiques", "ppf": "Soirs avec beaucoup de PP", "ppl": "Soirs sans PP",
        "fin": "Finition (buts vs xG)", "pas": "Passeur (passes vs xG sur la glace)", "disp": "Tout-ou-rien"}
FEATS = ["reg_dom", "reg_b2b", "reg_phys", "reg_ppf", "reg_ppl", "reg_fin", "reg_pas", "reg_disp"]
# Grilles de la sim. k : en matchs (splits, disp) ou en xG (fin, pas).
HLS = [41, 82, 164, None]
KS = {"split": [5, 10, 20, 40, 80, 160, 320], "fin": [2, 5, 10, 20, 40, 80], "pas": [2, 5, 10, 20, 40, 80],
      "disp": [10, 20, 40, 80, 160, 320]}
JOURS_RECHERCHE = 28
PP_FORT, PP_FAIBLE = 2.0, 0.5
NAN = float("nan")


def _cote_pp(pp):
    if pp is None or pp != pp:
        return None
    return "in" if pp >= PP_FORT else "out" if pp < PP_FAIBLE else "mid"


class Registre:
    """Accumulateurs par joueur (pondérés par la mémoire) + totaux de la ligue (sans mémoire).
    `params` : {tendance: {"k", "hl", "actif"}}. Pour la sim, un seul hl pour tout."""

    def __init__(self, params):
        self.params = params
        self.dec = {t: (0.5 ** (1 / params[t]["hl"]) if params[t].get("hl") else 1.0) for t in TENDANCES}
        # split : [in_tirs, in_toi, in_n, out_tirs, out_toi, out_n, mid_tirs, mid_toi]
        self.j = defaultdict(lambda: {t: [0.0] * 8 for t in SPLITS} | {"fin": [0.0, 0.0], "pas": [0.0, 0.0],
                                                                        "disp": [0.0, 0.0, 0.0], "n": 0})
        self.L = {t: [0.0] * 8 for t in SPLITS} | {"fin": [0.0, 0.0], "pas": [0.0, 0.0], "disp": [0.0, 0.0]}

    # --- ajouter un match FINI ---
    def ajouter(self, pid, dom, b2b, phys, pp, toi, tirs, buts, passes, xg, onxgf):
        J, L = self.j[pid], self.L
        ctx = {"dom": "in" if dom else "out", "b2b": "in" if b2b else "out", "phys": "in" if phys else "out",
               "pp": _cote_pp(pp)}
        # Dispersion : écart du match vs SA moyenne d'avant (avant de l'ajouter)
        d = J["disp"]
        if d[0] >= 5:
            m = d[1] / d[0]
            L["disp"][0] += (tirs - m) ** 2 - m
            L["disp"][1] += m * m
        for t in SPLITS:
            s = ctx[t]
            if s is None or toi <= 0:
                continue
            a, la, q = J[t], L[t], self.dec[t]
            for i in range(8):
                a[i] *= q
            i0 = {"in": 0, "out": 3, "mid": 6}[s]
            a[i0] += tirs; a[i0 + 1] += toi
            la[i0] += tirs; la[i0 + 1] += toi
            if s != "mid":
                a[i0 + 2] += 1
        if xg is not None and xg == xg:
            q = self.dec["fin"]; f = J["fin"]
            f[0] = f[0] * q + buts; f[1] = f[1] * q + xg
            L["fin"][0] += buts; L["fin"][1] += xg
        if onxgf is not None and onxgf == onxgf:
            q = self.dec["pas"]; p = J["pas"]
            p[0] = p[0] * q + passes; p[1] = p[1] * q + onxgf
            L["pas"][0] += passes; L["pas"][1] += onxgf
        q = self.dec["disp"]
        d[0] = d[0] * q + 1; d[1] = d[1] * q + tirs; d[2] = d[2] * q + tirs * tirs
        J["n"] += 1

    # --- lire les ratios BRUTS (sans crédibilité) : (brut, n) par tendance/côté ---
    def _split(self, pid, t, s):
        a, la = self.j[pid][t], self.L[t]
        i0 = 0 if s == "in" else 3
        T_all = a[1] + a[4] + a[7]
        L_all = la[1] + la[4] + la[7]
        if a[i0 + 1] <= 0 or T_all <= 0 or la[i0 + 1] <= 0 or L_all <= 0:
            return None, 0.0
        p_s, p_all = a[i0] / a[i0 + 1], (a[0] + a[3] + a[6]) / T_all
        l_s, l_all = la[i0] / la[i0 + 1], (la[0] + la[3] + la[6]) / L_all
        if p_all <= 0 or l_s <= 0 or l_all <= 0:
            return None, 0.0
        return (p_s / p_all) / (l_s / l_all), a[i0 + 2]

    def alpha_ligue(self):
        n, d = self.L["disp"]
        return max(0.01, n / d) if d > 0 else 0.05

    def brut(self, pid, t, s=None):
        J, L = self.j[pid], self.L
        if t in SPLITS:
            return self._split(pid, t, s)
        if t in ("fin", "pas"):
            num, den = J[t]
            if den <= 0 or L[t][1] <= 0 or L[t][0] <= 0:
                return None, 0.0
            return (num / den) / (L[t][0] / L[t][1]), den
        d = J["disp"]
        if d[0] < 3 or d[1] <= 0:
            return None, 0.0
        m = d[1] / d[0]
        var = max(0.0, d[2] / d[0] - m * m)
        return max(0.0, (var - m) / (m * m)) / self.alpha_ligue(), d[0]

    def ratio(self, pid, t, s=None):
        """Ratio crédibilisé (1.0 si la tendance est fermée ou sans données)."""
        p = self.params[t]
        if not p.get("actif", True):
            return 1.0
        b, n = self.brut(pid, t, s)
        if b is None:
            return 1.0
        return 1 + (b - 1) * n / (n + p["k"])

    def feats(self, pid, dom, b2b, phys):
        return [self.ratio(pid, "dom", "in" if dom else "out"), self.ratio(pid, "b2b", "in" if b2b else "out"),
                self.ratio(pid, "phys", "in" if phys else "out"), self.ratio(pid, "pp", "in"),
                self.ratio(pid, "pp", "out"), self.ratio(pid, "fin"), self.ratio(pid, "pas"), self.ratio(pid, "disp")]

    def fiche(self, pid):
        """Pour la page : {côté: [ratio, brut, crédibilité]} + nombre de matchs."""
        out = {}
        for (t, s), nom in COTES.items():
            b, n = self.brut(pid, t, s)
            if b is None:
                continue
            k = self.params[t]["k"]
            c = n / (n + k)
            out[nom] = [round(self.ratio(pid, t, s), 3), round(b, 3), round(c if self.params[t].get("actif", True) else 0, 2)]
        for t in ("fin", "pas", "disp"):
            b, n = self.brut(pid, t)
            if b is None:
                continue
            c = n / (n + self.params[t]["k"])
            out[t] = [round(self.ratio(pid, t), 3), round(b, 3), round(c if self.params[t].get("actif", True) else 0, 2)]
        return {"n": self.j[pid]["n"], "t": out} if out else None


# =================================================================================
# La sim : quelle force de rappel (k) et quelle mémoire (hl) prédisent le mieux ?
# =================================================================================

def _dev_poisson(y, lam):
    import numpy as np
    lam = np.maximum(lam, 1e-6)
    with np.errstate(all="ignore"):
        t = np.where(y > 0, y * np.log(y / lam), 0.0)
    return 2 * (t - (y - lam))


def _ll_nb(y, lam, alpha):
    import numpy as np
    from scipy.special import gammaln
    a = np.maximum(alpha, 1e-4)
    r = 1 / a
    lam = np.maximum(lam, 1e-6)
    return gammaln(y + r) - gammaln(r) - gammaln(y + 1) + r * np.log(r / (r + lam)) + y * np.log(lam / (r + lam))


def rechercher(rows, coupe, log=print):
    """rows : (date, saison, pid, dom, b2b, phys, pp, toi, tirs, buts, passes, xg, onxgf), en ordre.
    Évalue chaque match AVANT de l'ajouter, seulement les matchs avant `coupe`.
    Retourne {tendance: {"k", "hl", "actif", "gain", "n", "grille"}}."""
    import numpy as np
    obs = {t: defaultdict(list) for t in TENDANCES}
    for hl in HLS:
        R = Registre({t: {"k": 0, "hl": hl} for t in TENDANCES})
        acc = {t: [] for t in TENDANCES}     # (brut, n, y, lam_base)
        for (d, _s, pid, dom, b2b, phys, pp, toi, tirs, buts, passes, xg, onxgf) in rows:
            if d >= coupe:
                break
            J = R.j[pid]
            ctx = {"dom": "in" if dom else "out", "b2b": "in" if b2b else "out", "phys": "in" if phys else "out",
                   "pp": _cote_pp(pp)}
            for t in SPLITS:
                s = ctx[t]
                if s in ("in", "out") and toi > 0:
                    a, la = J[t], R.L[t]
                    T_all, L_all = a[1] + a[4] + a[7], la[1] + la[4] + la[7]
                    i0 = 0 if s == "in" else 3
                    if T_all > 0 and L_all > 0 and la[i0 + 1] > 0:
                        p_all = (a[0] + a[3] + a[6]) / T_all
                        f_l = (la[i0] / la[i0 + 1]) / ((la[0] + la[3] + la[6]) / L_all)
                        b, n = R._split(pid, t, s)
                        if b is not None and p_all > 0:
                            acc[t].append((b, n, tirs, p_all * toi * f_l))
            if xg is not None and xg == xg and xg > 0:
                b, n = R.brut(pid, "fin")
                if b is not None:
                    acc["fin"].append((b, n, buts, xg * R.L["fin"][0] / R.L["fin"][1]))
            if onxgf is not None and onxgf == onxgf and onxgf > 0:
                b, n = R.brut(pid, "pas")
                if b is not None:
                    acc["pas"].append((b, n, passes, onxgf * R.L["pas"][0] / R.L["pas"][1]))
            dd = J["disp"]
            if dd[0] >= 5 and dd[1] > 0:
                b, n = R.brut(pid, "disp")
                if b is not None:
                    acc["disp"].append((b, n, tirs, dd[1] / dd[0], R.alpha_ligue()))
            R.ajouter(pid, dom, b2b, phys, pp, toi, tirs, buts, passes, xg, onxgf)
        for t in TENDANCES:
            if not acc[t]:
                continue
            A = np.array(acc[t], dtype=float)
            b, n, y, lam = A[:, 0], A[:, 1], A[:, 2], A[:, 3]
            grille = KS["split"] if t in SPLITS else KS[t]
            if t == "disp":
                aL = A[:, 4]
                base = _ll_nb(y, lam, aL).sum()
                for k in grille:
                    a_p = aL * (1 + (b - 1) * n / (n + k))
                    obs[t][(hl, k)] = (float((_ll_nb(y, lam, a_p).sum() - base) / abs(base)), len(y))
            else:
                base = _dev_poisson(y, lam).sum()
                for k in grille:
                    r = 1 + (b - 1) * n / (n + k)
                    obs[t][(hl, k)] = (float((base - _dev_poisson(y, lam * r).sum()) / base), len(y))
    out = {}
    for t in TENDANCES:
        if not obs[t]:
            out[t] = {"k": 40, "hl": 82, "actif": False, "gain": None, "n": 0, "grille": []}
            continue
        (hl, k), (g, n) = max(obs[t].items(), key=lambda kv: kv[1][0])
        out[t] = {"k": k, "hl": hl, "actif": bool(g > 0), "gain": round(g, 5), "n": n,
                  "grille": [[h if h else 0, kk, round(gg, 5)] for (h, kk), (gg, _n) in sorted(obs[t].items(), key=lambda kv: (kv[0][0] or 9999, kv[0][1]))]}
        log(f"  registre : {t:5} meilleur k={k} mémoire={hl or 'carrière'} gain {g * 100:+.3f} % ({n} matchs)"
            f"{'' if g > 0 else ' -> fermée'}")
    return out


# =================================================================================
# Base de données + passe finale (features du ML, prédictions des soirs passés, ce soir)
# =================================================================================

def _lire(f, defaut):
    try:
        return json.loads(Path(f).read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return defaut


def preparer(rows, jours_sc, saisons_pretes, jour, dossier, noms=None, cibles=None, log=print):
    """Lance la sim si besoin (première fois, aux 4 semaines, nouvelle saison récoltée), puis
    rejoue tout le registre avec les paramètres gardés.
    cibles : {(date, pid)} des joueurs dont on veut les ratios d'avant-match (soirs passés).
    Retourne {"params", "feats" (une liste par ligne), "avant" {(date, pid): fiche+contexte},
              "R" (registre final), "db" (résumé)}."""
    dossier = Path(dossier)
    db = _lire(dossier / "registre.json", None)
    a_faire = (not db or sorted(db.get("saisons", [])) != sorted(saisons_pretes)
               or (date.fromisoformat(jour) - date.fromisoformat(db["recherche"])).days >= JOURS_RECHERCHE)
    if a_faire and len(jours_sc) >= 6:
        coupe = jours_sc[int(len(jours_sc) * 0.7)]
        params = rechercher(rows, coupe, log)
        db = {"recherche": jour, "coupe": coupe, "saisons": sorted(saisons_pretes), "params": params}
    elif not db:
        db = {"recherche": None, "coupe": None, "saisons": [], "params":
              {t: {"k": 40, "hl": 82, "actif": False, "gain": None} for t in TENDANCES}}
    params = db["params"]
    R = Registre(params)
    feats, avant = [], {}
    cibles = cibles or set()
    for (d, _s, pid, dom, b2b, phys, pp, toi, tirs, buts, passes, xg, onxgf) in rows:
        feats.append(R.feats(pid, dom, b2b, phys))
        if (d, pid) in cibles:
            avant[(d, pid)] = {"ctx": [bool(dom), bool(b2b), bool(phys)], "r": _ratios_soir(R, pid, dom, b2b, phys)}
        R.ajouter(pid, dom, b2b, phys, pp, toi, tirs, buts, passes, xg, onxgf)
    # Sauvegarde : paramètres de la sim + fiche de chaque joueur (pour consultation)
    joueurs = {}
    for pid in R.j:
        f = R.fiche(pid)
        if f:
            if noms and pid in noms:
                f["nom"] = noms[pid]
            joueurs[str(pid)] = f
    db.update({"maj": jour, "n_matchs": len(rows), "alpha_ligue": round(R.alpha_ligue(), 4), "joueurs": joueurs})
    dossier.mkdir(parents=True, exist_ok=True)
    (dossier / "registre.json").write_text(json.dumps(db, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    return {"params": params, "feats": feats, "avant": avant, "R": R, "db": db}


def _ratios_soir(R, pid, dom, b2b, phys):
    """Les ratios qui s'appliquent à un match (selon le contexte), pour ajuster une prédiction."""
    return {"tirs": R.ratio(pid, "dom", "in" if dom else "out") * R.ratio(pid, "b2b", "in" if b2b else "out")
                    * R.ratio(pid, "phys", "in" if phys else "out"),
            "ppf": R.ratio(pid, "pp", "in"), "ppl": R.ratio(pid, "pp", "out"),
            "fin": R.ratio(pid, "fin"), "pas": R.ratio(pid, "pas"),
            "alpha": R.alpha_ligue() * R.ratio(pid, "disp"), "alpha_L": R.alpha_ligue()}


# =================================================================================
# Appliquer le registre à une prédiction (la recette en service ou le ML)
# =================================================================================

def _logit(p):
    p = min(max(p, 1e-4), 1 - 1e-4)
    return math.log(p / (1 - p))


def _sig(x):
    return 1 / (1 + math.exp(-x))


def _p_nb(lam, s, alpha):
    """P(Y >= s) pour une binomiale négative (moyenne lam, var = lam + alpha·lam²)."""
    r = 1 / max(alpha, 1e-4)
    q = r / (r + lam)
    p0 = q ** r
    cum, pk = p0, p0
    for k in range(1, s):
        pk = pk * (k - 1 + r) / k * (1 - q)
        cum += pk
    return max(1e-6, 1 - cum)


def _p_pois(lam, s):
    cum, pk = math.exp(-lam), math.exp(-lam)
    for k in range(1, s):
        pk *= lam / k
        cum += pk
    return max(1e-6, 1 - cum)


MARCHES = {"tirs1": ("tirs", 1), "tirs": ("tirs", 2), "tirs3": ("tirs", 3), "tirs4": ("tirs", 4),
           "buts": ("buts", 1), "buts2": ("buts", 2), "buts3": ("buts", 3), "passes": ("passes", 1),
           "passes2": ("passes", 2), "pts1": ("pts", 1), "pts2": ("pts", 2)}


def multiplicateurs(r, ppu):
    """Ce soir : multiplicateur des tirs (lieu × b2b × physique × PP selon l'unité DailyFaceoff),
    des buts (tirs × finition) et des passes (passeur)."""
    f_pp = r["ppf"] if ppu == "pp1" else r["ppl"] if ppu == "aucune" else 1.0
    mt = r["tirs"] * f_pp
    return {"tirs": mt, "buts": mt * r["fin"], "passes": r["pas"] * (f_pp ** 0.5)}


def ajuster(preds_base, r, ppu):
    """preds_base : {marché: {"p", "lam"}} (recette en service). Retourne la même chose ajustée
    par le registre. Si tous les ratios valent 1, le résultat est identique à la base.
    On déplace la proba de la base dans l'échelle des cotes (logit) du même écart que le
    modèle simple (Poisson / binomiale négative) entre la moyenne d'avant et celle d'après :
    la forme fine de la recette est gardée, seul l'effet du registre s'ajoute."""
    mu = multiplicateurs(r, ppu)
    out = {}
    lam_b = (preds_base.get("buts") or {}).get("lam")
    lam_a = (preds_base.get("passes") or {}).get("lam")
    for m, pv in preds_base.items():
        if m not in MARCHES or not isinstance(pv, dict) or pv.get("p") is None:
            continue
        stat, s = MARCHES[m]
        lam = pv.get("lam")
        if stat == "pts":
            if lam_b is None or lam_a is None:
                continue
            l0 = lam_b + lam_a
            l1 = lam_b * mu["buts"] + lam_a * mu["passes"]
            d = _logit(_p_pois(l1, s)) - _logit(_p_pois(l0, s))
        elif lam is None:
            continue
        elif stat == "tirs":
            l1 = lam * mu["tirs"]
            d = _logit(_p_nb(l1, s, r["alpha"])) - _logit(_p_nb(lam, s, r["alpha_L"]))
        else:
            l1 = lam * mu[stat]
            d = _logit(_p_pois(l1, s)) - _logit(_p_pois(lam, s))
        out[m] = {"p": round(_sig(_logit(pv["p"]) + d), 4), "lam": round(l1, 3)}
    # Garde-fou : 1+ >= 2+ >= 3+ >= 4+ (et pareil pour buts, passes, points)
    for ordre in (("tirs1", "tirs", "tirs3", "tirs4"), ("buts", "buts2", "buts3"), ("passes", "passes2"), ("pts1", "pts2")):
        prec = 1.0
        for m in ordre:
            if m in out:
                out[m]["p"] = min(out[m]["p"], prec)
                prec = out[m]["p"]
    return out


def ajouter_preds(entrees, base_de, ratios_de, ppu_de):
    """preds["reg"] = la recette en service (base_de(e, m)) ajustée par le registre du joueur."""
    n = 0
    for e in entrees:
        r = ratios_de(e)
        if not r:
            continue
        base = {}
        for m in MARCHES:
            pv = base_de(e, m)
            if pv and pv.get("p") is not None:
                base[m] = pv
        adj = ajuster(base, r, ppu_de(e))
        if adj:
            e.setdefault("preds", {})["reg"] = adj
            n += 1
    return n
