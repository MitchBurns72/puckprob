"""
Profit simulé : « si on avait parié 1 $ chaque fois que la version voyait de la valeur ».

POURQUOI (Mitch, 25 oct.) : le but c'est l'argent, pas le plus gros % de réussite. Une
version peut prédire un peu moins bien en moyenne mais mieux là où la cote se trompe.
Règle de pari, fixée d'avance (pas ajustée après coup) : on parie quand
  proba de la version × cote − 1 > 5 %   (5 % de valeur attendue minimum).
Les cotes sont celles qu'on archive (cotes US via l'API, pas Mise-o-jeu) au dernier calcul
avant le match.

Le profit est BRUYANT : 100 paris à cote 2.00, c'est ± 10 $ juste par chance. Le juge
l'utilise seulement avec assez de paris et en gardant un œil sur la qualité des probas.
"""

SEUIL_VALEUR = 0.05
MIN_PARIS = 80          # en bas de ça, le profit est trop chanceux : le juge regarde le Brier
MARGE = 2.0             # la nouvelle doit faire au moins 2 $ de plus (sur 1 $ par pari)
PIRE_BRIER = -0.005     # et ne pas prédire plus de 0.5 % moins bien en moyenne


def pari(p, prix, gagne):
    """Profit d'un pari de 1 $ (None si la version ne parierait pas)."""
    if p is None or not prix or prix <= 1 or p * prix - 1 <= SEUIL_VALEUR:
        return None
    return prix - 1 if gagne else -1.0


def paris_match(cle, pv, cotes, h, a):
    """Profits des paris de match d'une prédiction (victoire : les deux côtés ; totaux : plus/moins)."""
    out = []
    if not cotes or not pv:
        return out
    if cle == "victoire" and pv.get("p_home") is not None:
        for p, prix, g in ((pv["p_home"], cotes.get("home"), h > a), (1 - pv["p_home"], cotes.get("away"), a > h)):
            r = pari(p, prix, g)
            if r is not None:
                out.append(r)
    elif cle in ("total55", "total65"):
        ligne = 5.5 if cle == "total55" else 6.5
        po = (pv.get("p_over") or {}).get(str(ligne))
        if po is not None and cotes.get("ligne") == ligne:
            for p, prix, g in ((po, cotes.get("over"), h + a > ligne), (1 - po, cotes.get("under"), h + a < ligne)):
                r = pari(p, prix, g)
                if r is not None:
                    out.append(r)
    return out


def bilan(profits):
    profits = [x for x in profits if x is not None]
    return {"paris": len(profits), "profit": round(sum(profits), 2),
            "roi": round(sum(profits) / len(profits), 4) if profits else None}


def decider(gain_brier, b_new, b_old):
    """Le juge : (remplacer ?, raison). b_new / b_old = bilan() sur les MÊMES soirs jamais vus."""
    if max(b_new["paris"], b_old["paris"]) >= MIN_PARIS:
        if gain_brier is not None and gain_brier < PIRE_BRIER:
            return False, f"profit pas retenu : probas {gain_brier * 100:+.2f} % moins bonnes"
        if b_new["profit"] >= b_old["profit"] + MARGE:
            return True, f"profit {b_new['profit']:+.2f} $ vs {b_old['profit']:+.2f} $ ({b_new['paris']} vs {b_old['paris']} paris)"
        return False, f"profit {b_new['profit']:+.2f} $ vs {b_old['profit']:+.2f} $ : pas assez mieux"
    return None, f"seulement {max(b_new['paris'], b_old['paris'])} paris : jugé sur la qualité des probas"
