"""
Trophées individuels : Art Ross, Norris, Vezina, Calder (Mitch, 31 oct.).

Même principe que la Coupe : on simule 10 000 fois le reste de la saison de chaque candidat,
et on refait la même chose « à pareille date » pour chaque saison passée pour voir où étaient
les gagnants et ce que le modèle leur aurait donné.

Art Ross = le plus de points : c'est une stat, donc la simulation donne directement le gagnant.
Norris, Vezina, Calder = des VOTES (journalistes, DG). On ne peut pas simuler des votes, mais
on peut apprendre ce que les votants récompensent : un score de stats (ex. Norris = points et
temps de glace) dont les poids sont choisis pour que le vrai gagnant de chaque saison depuis
2009-10 soit le plus probable. La part de hasard des votes est mesurée en même temps (τ) :
plus les votes sont imprévisibles, plus les % sont étalés.

Données : l'API de stats de la LNH (api.nhle.com/stats/rest), totaux à une date donnée.
Les listes finales des saisons passées sont gardées dans data/trophees/ (une seule fois).
"""

import hashlib
import json
import math
import random
import time
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path
from urllib.parse import quote

import nhl_api as api

RACINE = Path(__file__).resolve().parent.parent
DIR = RACINE / "data" / "trophees"
STATS = "https://api.nhle.com/stats/rest/en"
N_SIM = 10000
N_SIM_TEST = 2000
PREMIERE = 2009
BUDGET_S = 200
K_PRIOR = 25          # matchs « fictifs » de la saison passée mélangés au rythme actuel (Art Ross, Calder)
SV_LIGUE = 0.903
K_SV = 1500           # tirs fictifs à la moyenne de la ligue pour le % d'arrêts

# Gagnants (votes) : saison -> nom. Art Ross se calcule avec les stats.
NORRIS = {"20092010": "Duncan Keith", "20102011": "Nicklas Lidstrom", "20112012": "Erik Karlsson",
          "20122013": "P.K. Subban", "20132014": "Duncan Keith", "20142015": "Erik Karlsson",
          "20152016": "Drew Doughty", "20162017": "Brent Burns", "20172018": "Victor Hedman",
          "20182019": "Mark Giordano", "20192020": "Roman Josi", "20202021": "Adam Fox",
          "20212022": "Cale Makar", "20222023": "Erik Karlsson", "20232024": "Quinn Hughes",
          "20242025": "Cale Makar", "20252026": "Zach Werenski"}
VEZINA = {"20092010": "Ryan Miller", "20102011": "Tim Thomas", "20112012": "Henrik Lundqvist",
          "20122013": "Sergei Bobrovsky", "20132014": "Tuukka Rask", "20142015": "Carey Price",
          "20152016": "Braden Holtby", "20162017": "Sergei Bobrovsky", "20172018": "Pekka Rinne",
          "20182019": "Andrei Vasilevskiy", "20192020": "Connor Hellebuyck", "20202021": "Marc-Andre Fleury",
          "20212022": "Igor Shesterkin", "20222023": "Linus Ullmark", "20232024": "Connor Hellebuyck",
          "20242025": "Connor Hellebuyck", "20252026": "Andrei Vasilevskiy"}
CALDER = {"20092010": "Tyler Myers", "20102011": "Jeff Skinner", "20112012": "Gabriel Landeskog",
          "20122013": "Jonathan Huberdeau", "20132014": "Nathan MacKinnon", "20142015": "Aaron Ekblad",
          "20152016": "Artemi Panarin", "20162017": "Auston Matthews", "20172018": "Mathew Barzal",
          "20182019": "Elias Pettersson", "20192020": "Cale Makar", "20202021": "Kirill Kaprizov",
          "20212022": "Moritz Seider", "20222023": "Matty Beniers", "20232024": "Connor Bedard",
          "20242025": "Lane Hutson", "20252026": "Matthew Schaefer"}
# Sources : hockey-reference.com (vérifié le 31 oct. 2026)
HART = {"20092010": "Henrik Sedin", "20102011": "Corey Perry", "20112012": "Evgeni Malkin", "20122013": "Alex Ovechkin",
        "20132014": "Sidney Crosby", "20142015": "Carey Price", "20152016": "Patrick Kane", "20162017": "Connor McDavid",
        "20172018": "Taylor Hall", "20182019": "Nikita Kucherov", "20192020": "Leon Draisaitl", "20202021": "Connor McDavid",
        "20212022": "Auston Matthews", "20222023": "Connor McDavid", "20232024": "Nathan MacKinnon",
        "20242025": "Connor Hellebuyck", "20252026": "Nikita Kucherov"}
LINDSAY = {"20092010": "Alex Ovechkin", "20102011": "Daniel Sedin", "20112012": "Evgeni Malkin", "20122013": "Sidney Crosby",
           "20132014": "Sidney Crosby", "20142015": "Carey Price", "20152016": "Patrick Kane", "20162017": "Connor McDavid",
           "20172018": "Connor McDavid", "20182019": "Nikita Kucherov", "20192020": "Leon Draisaitl", "20202021": "Connor McDavid",
           "20212022": "Auston Matthews", "20222023": "Connor McDavid", "20232024": "Nathan MacKinnon",
           "20242025": "Nikita Kucherov", "20252026": "Connor McDavid"}
SELKE = {"20092010": "Pavel Datsyuk", "20102011": "Ryan Kesler", "20112012": "Patrice Bergeron", "20122013": "Jonathan Toews",
         "20132014": "Patrice Bergeron", "20142015": "Patrice Bergeron", "20152016": "Anze Kopitar", "20162017": "Patrice Bergeron",
         "20172018": "Anze Kopitar", "20182019": "Ryan O'Reilly", "20192020": "Sean Couturier", "20202021": "Aleksander Barkov",
         "20212022": "Patrice Bergeron", "20222023": "Patrice Bergeron", "20232024": "Aleksander Barkov",
         "20242025": "Aleksander Barkov", "20252026": "Nick Suzuki"}
BYNG = {"20092010": "Martin St. Louis", "20102011": "Martin St. Louis", "20112012": "Brian Campbell", "20122013": "Martin St. Louis",
        "20132014": "Ryan O'Reilly", "20142015": "Jiri Hudler", "20152016": "Anze Kopitar", "20162017": "Johnny Gaudreau",
        "20172018": "William Karlsson", "20182019": "Aleksander Barkov", "20192020": "Nathan MacKinnon", "20202021": "Jaccob Slavin",
        "20212022": "Kyle Connor", "20222023": "Anze Kopitar", "20232024": "Jaccob Slavin", "20242025": "Anze Kopitar",
        "20252026": "Cole Caufield"}
# Selke : les deux AUTRES finalistes de chaque saison (le gagnant est dans SELKE).
# Pourquoi : le Selke se vote beaucoup à la réputation. Les votants le traitent comme un prix de carrière
# (Bergeron finaliste 12 saisons de suite) ; on gagne rarement sans avoir déjà reçu des votes, et
# presque jamais pour la première fois avec une équipe hors des séries. Être finaliste avant compte
# donc autant que gagner, juste un peu moins. Vérifié (annonces de finalistes NHL.com, NBC, TSN,
# The Hockey News, CBS ; 2025-26 = top 3 du vote) le 31 oct. 2026.
SELKE_FINALISTES = {
    "20082009": ["Ryan Kesler", "Mike Richards"], "20092010": ["Ryan Kesler", "Jordan Staal"],
    "20102011": ["Pavel Datsyuk", "Jonathan Toews"], "20112012": ["David Backes", "Pavel Datsyuk"],
    "20122013": ["Patrice Bergeron", "Pavel Datsyuk"], "20132014": ["Anze Kopitar", "Jonathan Toews"],
    "20142015": ["Anze Kopitar", "Jonathan Toews"], "20152016": ["Patrice Bergeron", "Ryan Kesler"],
    "20162017": ["Ryan Kesler", "Mikko Koivu"], "20172018": ["Patrice Bergeron", "Sean Couturier"],
    "20182019": ["Patrice Bergeron", "Mark Stone"], "20192020": ["Patrice Bergeron", "Ryan O'Reilly"],
    "20202021": ["Patrice Bergeron", "Mark Stone"], "20212022": ["Aleksander Barkov", "Elias Lindholm"],
    "20222023": ["Nico Hischier", "Mitch Marner"], "20232024": ["Auston Matthews", "Jordan Staal"],
    "20242025": ["Anthony Cirelli", "Sam Reinhart"], "20252026": ["Anthony Cirelli", "Brock Nelson"]}
# Gagnants d'avant 2009-10 : servent seulement à la réputation des premières saisons calibrées
SELKE_AVANT = {"20052006": "Rod Brind'Amour", "20062007": "Rod Brind'Amour", "20072008": "Pavel Datsyuk",
               "20082009": "Pavel Datsyuk"}
REP_ANS = 6          # la réputation regarde les 6 saisons d'avant
REP_DECLIN = 0.8     # chaque saison plus vieille compte 20 % de moins
REP_FINALISTE = 0.5  # être finaliste vaut la moitié d'une victoire

# Saisons testées « à pareille date » : on saute le lock-out (2012-13) et 2020-21 (début en janvier)
SAUTER = {"20122013", "20202021"}


def _nrm(s):
    import unicodedata
    s = unicodedata.normalize("NFD", s or "").encode("ascii", "ignore").decode().lower()
    return " ".join("".join(c if c.isalnum() else " " for c in s).split())


def _lire(f, defaut):
    try:
        return json.loads(Path(f).read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return defaut


def _ecrire(f, data):
    Path(f).parent.mkdir(parents=True, exist_ok=True)
    Path(f).write_text(json.dumps(data, separators=(",", ":"), ensure_ascii=False), encoding="utf-8")


# =================================================================================
# 1. Listes de joueurs (API de stats), avec cache
# =================================================================================

def _url(kind, cay, prop, start):
    tri = quote(json.dumps([{"property": prop, "direction": "DESC"}], separators=(",", ":")))
    return (f"{STATS}/{kind}/summary?isAggregate=false&isGame=false&sort={tri}&start={start}&limit=100"
            f"&cayenneExp={quote(cay)}")


def _patiner(r):
    toi = r.get("timeOnIcePerGame")
    return {"id": r.get("playerId"), "nom": r.get("skaterFullName") or r.get("playerName") or "?",
            "eq": (r.get("teamAbbrevs") or "").split(",")[-1].strip(), "pos": r.get("positionCode"),
            "pj": r.get("gamesPlayed") or 0, "b": r.get("goals") or 0, "a": r.get("assists") or 0,
            "pts": r.get("points") or 0, "toi": round(toi / 60, 2) if toi else None,
            "pm": r.get("plusMinus"), "fo": r.get("faceoffWinPct"), "pim": r.get("penaltyMinutes")}


def _gardien(r):
    sa, sv = r.get("shotsAgainst") or 0, r.get("savePct")
    return {"id": r.get("playerId"), "nom": r.get("goalieFullName") or r.get("playerName") or "?",
            "eq": (r.get("teamAbbrevs") or "").split(",")[-1].strip(), "pj": r.get("gamesPlayed") or 0,
            "gs": r.get("gamesStarted") or r.get("gamesPlayed") or 0, "v": r.get("wins") or 0,
            "sv": sv, "sa": sa, "arrets": r.get("saves") if r.get("saves") is not None else (round(sa * sv) if sv else 0),
            "gaa": r.get("goalsAgainstAverage")}


GROUPES = {  # nom: (rapport, filtre en plus, tri, pages, lecteur)
    "points": ("skater", "", "points", 3, _patiner),
    "buts": ("skater", "", "goals", 2, _patiner),
    "def": ("skater", ' and positionCode="D"', "points", 1, _patiner),
    "recrues": ("skater", " and isRookie=1", "points", 1, _patiner),
    "gardiens": ("goalie", "", "wins", 1, _gardien),
}


def liste(groupe, saison, jusqua=None, cache=True):
    """Joueurs d'un groupe, totaux de la saison (jusqu'à `jusqua` inclus si donné)."""
    kind, extra, prop, pages, lire = GROUPES[groupe]
    f = DIR / "cache" / f"{groupe}_{saison}_{jusqua or 'fin'}.json"
    if cache and f.exists():
        data = _lire(f, [])
        # Vieux cache d'avant l'ajout de +/-, mises au jeu et punitions : on le refait (sinon le Selke
        # et le Lady Byng seraient calibrés sans ces stats, pour toujours)
        if not data or kind != "skater" or "pim" in data[0]:
            return data
    cay = f"seasonId={saison} and gameTypeId=2{extra}" + (f' and gameDate<="{jusqua} 23:59:59"' if jusqua else "")
    out, vus = [], set()
    for p in range(pages):
        rep = api.get_json(_url(kind, cay, prop, p * 100)) or {}
        page = rep.get("data", []) or []
        for r in page:
            x = lire(r)
            if x["id"] not in vus:
                vus.add(x["id"]); out.append(x)
        if len(page) < 100:
            break
    if cache and out:
        _ecrire(f, out)
    return out


# =================================================================================
# 2. Scores de vote (Norris, Vezina, Calder) appris sur les gagnants passés
# =================================================================================

def _z(vals):
    v = [x for x in vals if x is not None]
    if len(v) < 2:
        return lambda x: 0.0
    m = sum(v) / len(v)
    s = (sum((x - m) ** 2 for x in v) / len(v)) ** 0.5 or 1.0
    return lambda x: 0.0 if x is None else (x - m) / s


def _candidats_fin(trophee, joueurs):
    """Les candidats « sérieux » d'une fin de saison (assez de matchs)."""
    if not joueurs:
        return []
    mx = max(j["pj"] for j in joueurs)
    if trophee == "vezina":
        return [j for j in joueurs if j["pj"] >= 0.35 * mx and j.get("sv")]
    if trophee == "selke":
        return [j for j in joueurs if j["pj"] >= 0.5 * mx and j.get("pos") == "C"]
    if trophee == "byng":
        return [j for j in joueurs if j["pj"] >= 0.6 * mx]
    return [j for j in joueurs if j["pj"] >= 0.5 * mx]


def scores(trophee, cands, P):
    """Score de vote de chaque candidat (z-scores dans le groupe), selon les poids P."""
    if trophee == "norris":
        zp, zt = _z([c["pts"] for c in cands]), _z([c.get("toi") for c in cands])
        return [P["w"] * zp(c["pts"]) + (1 - P["w"]) * zt(c.get("toi")) for c in cands]
    if trophee == "calder":
        zp = _z([c["pts"] for c in cands])
        return [zp(c["pts"]) + (P["d"] if c.get("pos") == "D" else 0) for c in cands]
    if trophee == "vezina":
        zs, zv, zg = _z([c.get("sv") for c in cands]), _z([c["v"] for c in cands]), _z([c["pj"] for c in cands])
        return [P["a"] * zs(c.get("sv")) + P["b"] * zv(c["v"]) + P["c"] * zg(c["pj"]) for c in cands]
    if trophee in ("hart", "lindsay"):
        zp, ze = _z([c["pts"] for c in cands]), _z([c.get("eqp") for c in cands])
        return [P["w"] * zp(c["pts"]) + (1 - P["w"]) * ze(c.get("eqp")) for c in cands]
    if trophee == "selke":
        zp, zf, zm = _z([c["pts"] for c in cands]), _z([c.get("fo") for c in cands]), _z([c.get("pm") for c in cands])
        ze = _z([c.get("eqp") for c in cands])
        # d = poids de la réputation (votes des saisons passées), e = équipe qui gagne (séries)
        return [P["a"] * zp(c["pts"]) + P["b"] * zf(c.get("fo")) + P["c"] * zm(c.get("pm"))
                + P["d"] * c.get("rep", c.get("deja", 0)) + P.get("e", 0) * ze(c.get("eqp")) for c in cands]
    if trophee == "byng":
        zp = _z([c["pts"] for c in cands])
        zq = _z([-(c.get("pim") or 0) / max(1, c["pj"]) for c in cands])
        return [P["w"] * zp(c["pts"]) + (1 - P["w"]) * zq(-(c.get("pim") or 0) / max(1, c["pj"])) for c in cands]
    if trophee == "rocket":
        return [c["b"] + c["pts"] / 1000 for c in cands]
    return [c["pts"] + c["b"] / 1000 for c in cands]


def _softmax(s, tau):
    m = max(s)
    e = [math.exp((x - m) / tau) for x in s]
    t = sum(e)
    return [x / t for x in e]


GRILLES = {"norris": [{"w": w} for w in (0.2, 0.35, 0.5, 0.65, 0.8, 1.0)],
           "calder": [{"d": d} for d in (0.0, 0.4, 0.8, 1.2, 1.6)],
           "vezina": [{"a": a, "b": b, "c": c} for a in (0.5, 1.0) for b in (0.0, 0.5, 1.0) for c in (0.0, 0.5, 1.0)],
           "hart": [{"w": w} for w in (0.4, 0.55, 0.7, 0.85, 1.0)],
           "lindsay": [{"w": w} for w in (0.4, 0.55, 0.7, 0.85, 1.0)],
           # Selke : seuls les rapports entre poids comptent (τ règle l'échelle), d'où a presque fixe
           "selke": [{"a": 1.0, "b": b, "c": c, "d": d, "e": e} for b in (0.0, 0.3, 0.6)
                     for c in (0.0, 0.3, 0.6) for d in (0.0, 0.8, 1.6, 2.4, 3.2) for e in (0.0, 0.4, 0.8, 1.2, 1.6)],
           "byng": [{"w": w} for w in (0.3, 0.45, 0.6, 0.75, 0.9)]}
TAUS = [0.25, 0.4, 0.6, 0.9, 1.3, 2.0]
GAGNANTS = {"norris": NORRIS, "vezina": VEZINA, "calder": CALDER, "hart": HART, "lindsay": LINDSAY, "selke": SELKE, "byng": BYNG}
GROUPE_DE = {"art": "points", "rocket": "buts", "norris": "def", "vezina": "gardiens", "calder": "recrues",
             "hart": "points", "lindsay": "points", "selke": "points", "byng": "points"}
VOTES = ("norris", "vezina", "calder", "hart", "lindsay", "selke", "byng")
STATS_T = ("art", "rocket")


def reputation_selke(saison):
    """{nom normalisé: (score, nb de Selke, nb de fois finaliste)} sur les REP_ANS saisons AVANT `saison`.
    Seulement le passé : la saison en cours ne compte jamais (sinon la calibration tricherait)."""
    an = int(saison[:4])
    out = defaultdict(lambda: [0.0, 0, 0])
    for k in range(1, REP_ANS + 1):
        s = f"{an - k}{an - k + 1}"
        poids = REP_DECLIN ** (k - 1)
        g = SELKE.get(s) or SELKE_AVANT.get(s)
        if g:
            r = out[_nrm(g)]; r[0] += poids; r[1] += 1
        for f in SELKE_FINALISTES.get(s, []):
            r = out[_nrm(f)]; r[0] += poids * REP_FINALISTE; r[2] += 1
    return out


def enrichir(t, cands, saison, pct_eq):
    """Ajoute ce que le score a besoin : force de l'équipe (Hart, Lindsay, Selke), réputation (Selke)."""
    an = int(saison[:4])
    passes = {_nrm(SELKE.get(f"{a}{a + 1}", "")) for a in range(an - 3, an)}
    rep = reputation_selke(saison) if t == "selke" else {}
    for c in cands:
        c["eqp"] = pct_eq.get(c["eq"])
        if t == "selke":
            c["deja"] = 1 if _nrm(c["nom"]) in passes else 0
            r = rep.get(_nrm(c["nom"]))
            c["rep"], c["rep_g"], c["rep_f"] = (round(r[0], 3), r[1], r[2]) if r else (0.0, 0, 0)
    return cands


def calibrer(trophee, finales, log=print, pct_saisons=None):
    """Poids + τ qui rendent les vrais gagnants les plus probables (vraisemblance)."""
    meilleur = None
    pct_saisons = pct_saisons or {}
    finales = {s: enrichir(trophee, [dict(j) for j in js], s, pct_saisons.get(s, {})) for s, js in finales.items()}
    for P in GRILLES[trophee]:
        for tau in TAUS:
            ll = n = 0
            for s, joueurs in finales.items():
                g = GAGNANTS[trophee].get(s)
                cands = _candidats_fin(trophee, joueurs)
                i = next((k for k, c in enumerate(cands) if _nrm(c["nom"]) == _nrm(g)), None) if g else None
                if i is None:
                    continue
                sc_ = scores(trophee, cands, P)
                pr = _softmax(sc_, tau)
                ll += math.log(max(pr[i], 1e-9)); n += 1
                # Selke : les 2 autres finalistes, comme « parmi le reste, ils sortent en tête » (demi-poids)
                fins = [_nrm(f) for f in SELKE_FINALISTES.get(s, [])] if trophee == "selke" else []
                if fins:
                    reste = [k for k in range(len(cands)) if k != i]
                    pr2 = _softmax([sc_[k] for k in reste], tau)
                    for f in fins:
                        j = next((q for q, k in enumerate(reste) if _nrm(cands[k]["nom"]) == f), None)
                        if j is not None:
                            ll += 0.5 * math.log(max(pr2[j], 1e-9))
            if n and (meilleur is None or ll / n > meilleur[0]):
                meilleur = (ll / n, {**P, "tau": tau, "n": n, "ll": round(ll / n, 3)})
    if meilleur:
        log(f"  trophées : {trophee} réglé {meilleur[1]}")
    return meilleur[1] if meilleur else None


# =================================================================================
# 3. Simulation du reste de la saison
# =================================================================================

def simuler(trophee, cands, restants_eq, pv_eq, prior, P, n_sim=N_SIM, graine=0):
    """cands : joueurs à date. restants_eq : matchs restants par équipe. pv_eq : % de victoires
    de l'équipe. prior : {id: points par match la saison passée}. Retourne [(cand, p, projection)]."""
    # Un fil de hasard PAR JOUEUR (même graine chaque jour) : si rien n'a changé pour lui, ses fins de saison
    # simulées sont identiques à celles d'hier. Les écarts d'un jour à l'autre viennent donc des matchs
    # joués, pas du tirage au sort.
    rngs = {c["id"]: random.Random(graine * 1_000_003 + int(c["id"] or 0)) for c in cands}
    if not cands:
        return []
    jt = {}
    for c in cands:
        rest = restants_eq.get(c["eq"], 0)
        gp_eq = max(1, c.get("gp_eq") or c["pj"])
        dispo = min(1.0, c["pj"] / gp_eq) * 0.97 if c["pj"] else 0.5
        jt[c["id"]] = rest * dispo
    gains = defaultdict(float)
    proj = defaultdict(float)
    for _ in range(n_sim):
        fin = []
        for c in cands:
            m = jt[c["id"]]
            rng = rngs[c["id"]]
            if trophee == "vezina":
                gs_eq = max(1, c.get("gp_eq") or c["gs"])
                deps = restants_eq.get(c["eq"], 0) * min(1.0, c["gs"] / gs_eq)
                v = c["v"] + _binom(rng, deps, pv_eq.get(c["eq"], 0.5))
                tirs_dep = (c["sa"] / c["gs"]) if c["gs"] else 28.0
                sa_sim = deps * tirs_dep
                taux = (c["arrets"] + SV_LIGUE * K_SV) / (c["sa"] + K_SV)
                taux = min(0.99, max(0.8, taux + rng.gauss(0, 0.006)))
                arr = c["arrets"] + sa_sim * taux + rng.gauss(0, math.sqrt(max(sa_sim, 1) * taux * (1 - taux)))
                sv = arr / (c["sa"] + sa_sim) if c["sa"] + sa_sim else None
                fin.append({**c, "v": v, "pj": c["pj"] + deps, "sv": sv})
                proj[c["id"]] += v
            elif trophee == "rocket":
                pr = prior.get(c["id"])           # ici : buts par match la saison passée
                bpg = c["b"] / c["pj"] if c["pj"] else 0.0
                base = pr if pr is not None else bpg * 0.85
                taux = (c["b"] + base * K_PRIOR) / (c["pj"] + K_PRIOR) * rng.gammavariate(40, 1 / 40)
                b = c["b"] + _poisson(rng, taux * m)
                fin.append({**c, "b": b, "pj": c["pj"] + m})
                proj[c["id"]] += b
            else:
                pr = prior.get(c["id"])
                ppg = c["pts"] / c["pj"] if c["pj"] else 0.0
                base = pr if pr is not None else ppg * 0.85
                taux = (c["pts"] + base * K_PRIOR) / (c["pj"] + K_PRIOR)
                taux *= rng.gammavariate(40, 1 / 40)
                pts = c["pts"] + _poisson(rng, taux * m)
                bt = c["b"] + (pts - c["pts"]) * (c["b"] / c["pts"] if c["pts"] else 0.4)
                pim = (c.get("pim") or 0) * (c["pj"] + m) / c["pj"] if c["pj"] else c.get("pim")
                fin.append({**c, "pts": pts, "b": bt, "pj": c["pj"] + m, "pim": pim})
                proj[c["id"]] += pts
        if trophee in STATS_T:
            s = scores(trophee, fin, None)
            best = max(range(len(fin)), key=lambda i: s[i])
            gains[fin[best]["id"]] += 1
        else:
            pool = _candidats_fin(trophee, fin) or fin
            pr = _softmax(scores(trophee, pool, P), P["tau"])
            for c, p in zip(pool, pr):
                gains[c["id"]] += p
    out = [(c, gains[c["id"]] / n_sim, proj[c["id"]] / n_sim) for c in cands]
    out.sort(key=lambda x: -x[1])
    return out


def _poisson(rng, lam):
    if lam <= 0:
        return 0
    if lam > 15:   # loi normale : même chose à ce niveau, 20x plus rapide
        return max(0, int(round(rng.gauss(lam, math.sqrt(lam)))))
    L, k, p = math.exp(-lam), 0, 1.0
    while True:
        p *= rng.random()
        if p <= L:
            return k
        k += 1


def _binom(rng, n, p):
    n = max(0.0, n)
    return max(0.0, rng.gauss(n * p, math.sqrt(max(n * p * (1 - p), 1e-9))))


# =================================================================================
# 4. Contexte d'équipe à une date (matchs restants, % de victoires) depuis les matchs de la Coupe
# =================================================================================

def contexte_equipes(matchs, saison, jusqua):
    """{équipe: matchs restants}, {équipe: % victoires}, {équipe: matchs joués} au soir de `jusqua`."""
    gp, v, tot = defaultdict(int), defaultdict(int), defaultdict(int)
    for r in matchs:
        if r[1] != saison or r[2] != 2:
            continue
        h, a = r[3], r[4]
        tot[h] += 1; tot[a] += 1
        if r[0] <= jusqua and r[5] is not None and r[6] is not None and r[8] in ("OFF", "FINAL"):
            gp[h] += 1; gp[a] += 1
            v[h if r[5] > r[6] else a] += 1
    rest = {t: max(0, tot[t] - gp[t]) for t in tot}
    pv = {t: (v[t] / gp[t]) if gp[t] else 0.5 for t in tot}
    return rest, pv, dict(gp)


def _prior(saison):
    """Points par match de la saison d'avant (joueurs avec 20+ matchs)."""
    an = int(saison[:4]) - 1
    out = {}
    for j in liste("points", f"{an}{an + 1}"):
        if j["pj"] >= 20:
            out[j["id"]] = j["pts"] / j["pj"]
    return out


def _prior_buts(saison):
    an = int(saison[:4]) - 1
    return {j["id"]: j["b"] / j["pj"] for j in liste("points", f"{an}{an + 1}") if j["pj"] >= 20}


def _preparer(cands, gp_eq):
    for c in cands:
        c["gp_eq"] = gp_eq.get(c["eq"], c["pj"])
    return cands


# =================================================================================
# 5. Le calcul
# =================================================================================

def calculer(saison_courante, jour, matchs, log=print):
    """matchs : la liste de coupe.charger() (calendrier + résultats). Retourne le bloc de data.json."""
    sc = str(saison_courante)
    t0 = time.time()
    etat = _lire(DIR / "etat.json", {})
    an_c = int(sc[:4])
    passees = [f"{a}{a + 1}" for a in range(PREMIERE, an_c)]
    # Listes finales des saisons passées (une fois) -> calibration des votes
    finales = {g: {} for g in GROUPE_DE.values()}
    for s in passees:
        for g in finales:
            if time.time() - t0 > BUDGET_S and not (DIR / "cache" / f"{g}_{s}_fin.json").exists():
                continue
            try:
                finales[g][s] = liste(g, s)
            except Exception:  # noqa: BLE001
                pass
    # Vérifications : le filtre des recrues et celui de la date existent-ils vraiment dans l'API ?
    dispo_recrues = bool(finales["recrues"]) and any(
        finales["recrues"].get(s) and finales["points"].get(s) and
        finales["recrues"][s][0]["id"] != finales["points"][s][0]["id"] for s in finales["recrues"])
    pct_saisons = {s: contexte_equipes(matchs, s, "9999")[1] for s in passees}
    params = etat.get("params") or {}
    if (not params or any(t not in params for t in VOTES) or "e" not in (params.get("selke") or {"e": 0})
            or (date.fromisoformat(jour) - date.fromisoformat(etat.get("regle", "2000-01-01"))).days >= 28):
        params = {t: calibrer(t, finales[GROUPE_DE[t]], log, pct_saisons) for t in VOTES}
        etat.update({"params": params, "regle": jour})
    # Ce soir
    rest, pv, gp_eq = contexte_equipes(matchs, sc, jour)
    priors = {"pts": _prior(sc), "b": _prior_buts(sc)}
    listes = {}
    out = {"date": jour, "n_sim": N_SIM, "trophees": {}}
    ctx = {"rest": rest, "pv": pv, "gp": gp_eq}
    jour_ref, veille = charger_veille(jour)
    instantane = {"ctx": ctx, "trophees": {}}
    for t in STATS_T + VOTES:
        if t == "calder" and not dispo_recrues:
            out["trophees"][t] = {"dispo": False, "msg": "L'API ne filtre pas les recrues comme prévu : Calder pas disponible pour l'instant."}
            continue
        P = params.get(t) if t in VOTES else {}
        if t in VOTES and not P:
            out["trophees"][t] = {"dispo": False, "msg": "Pas assez de saisons passées pour apprendre ce que les votants récompensent."}
            continue
        g = GROUPE_DE[t]
        if g not in listes:
            listes[g] = liste(g, sc, cache=False)
        cands = _preparer([dict(c) for c in listes[g]], gp_eq)
        cands = _filtrer(t, cands)
        enrichir(t, cands, sc, pv)
        prior_t = priors["b" if t == "rocket" else "pts"]
        res = simuler(t, cands, rest, pv, prior_t, P)
        top = [_ligne(t, c, p, pr, sc) for c, p, pr in res[:10]]
        sig = signature(t, P)
        p_now = {c["id"]: p for c, p, _ in res}
        instantane["trophees"][t] = {"sig": sig, "cands": cands, "p": {str(k): round(v, 5) for k, v in p_now.items()}}
        bloc = {"dispo": True, "params": P, "top": top}
        V = (veille or {}).get("trophees", {}).get(t)
        if V:
            try:
                rctx = veille["ctx"]
                if V.get("sig") == sig:
                    p_ref = {int(k): v for k, v in V["p"].items()}
                    recalc = False
                else:   # algo changé : les % de la veille refaits avec l'algo d'aujourd'hui
                    rr = simuler(t, V["cands"], rctx["rest"], rctx["pv"], prior_t, P)
                    p_ref = {c["id"]: p for c, p, _ in rr}
                    recalc = True
                ecarts(t, top, p_now, p_ref, {c["id"]: c for c in cands}, {c["id"]: c for c in V["cands"]}, ctx, rctx)
                bloc["veille"] = {"jour": jour_ref, "recalcul": recalc}
            except Exception as ex:  # noqa: BLE001
                log(f"  trophées : écart avec la veille impossible pour {t} ({str(ex)[:80]})")
        out["trophees"][t] = bloc
    # À pareille date (refait chaque semaine, c'est la partie lourde)
    if (date.fromisoformat(jour) - date.fromisoformat(etat.get("teste", "2000-01-01"))).days >= 7 or not etat.get("tests"):
        try:
            etat["tests"] = tester(matchs, params, jour, sc, dispo_recrues, log)
            etat["teste"] = jour
        except Exception as ex:  # noqa: BLE001
            log(f"  trophées : test à pareille date impossible ({str(ex)[:100]})")
    for t, lst in (etat.get("tests") or {}).items():
        if t in out["trophees"]:
            out["trophees"][t]["test"] = lst
    _ecrire(DIR / "etat.json", etat)
    garder_veille(jour, instantane)
    return out


# =================================================================================
# 6. Écart avec la veille, et pourquoi
# =================================================================================
# Règle : l'écart affiché vient SEULEMENT des matchs joués depuis la veille, jamais d'un changement d'algo.
# Si l'algo a changé (code mis à jour, poids recalibrés), on recalcule les % de la veille avec l'algo
# d'aujourd'hui, à partir des stats de la veille gardées dans data/trophees/veille.json.
_SOURCE = hashlib.sha1(Path(__file__).read_bytes()).hexdigest()


def signature(t, P):
    return hashlib.sha1(f"{_SOURCE}|{t}|{json.dumps(P, sort_keys=True)}|{N_SIM}".encode()).hexdigest()[:12]


def _pts_pct(x):
    """0.0234 -> « +2,3 » (points de pourcentage)."""
    return f"{x * 100:+.1f}".replace(".", ",")


def _equipe_resultat(eq, ctx, ref):
    """« son équipe a gagné » / « a perdu » / None, à partir des % de victoires et matchs joués."""
    gp1, gp0 = (ctx["gp"].get(eq) or 0), (ref["gp"].get(eq) or 0)
    if gp1 <= gp0:
        return None
    v1, v0 = (ctx["pv"].get(eq) or 0) * gp1, (ref["pv"].get(eq) or 0) * gp0
    g = round(v1 - v0)
    n = gp1 - gp0
    if n == 1:
        return "son équipe a gagné" if g >= 1 else "son équipe a perdu"
    return f"son équipe : {g} victoire{'s' if g > 1 else ''} en {n} matchs"


def resume_joueur(t, c, h):
    """Ce que le joueur a fait depuis la veille (c = aujourd'hui, h = veille). None = n'a pas joué."""
    if t == "vezina":
        dgs, dpj = c.get("gs", 0) - h.get("gs", 0), c.get("pj", 0) - h.get("pj", 0)
        if dgs <= 0 and dpj <= 0:
            return None
        dv = c.get("v", 0) - h.get("v", 0)
        dsa, darr = (c.get("sa") or 0) - (h.get("sa") or 0), (c.get("arrets") or 0) - (h.get("arrets") or 0)
        txt = ("victoire" if dv > 0 else "défaite") if dgs > 0 else "en relève"
        return f"{txt}, {round(darr)} arrêts sur {round(dsa)}" if dsa > 0 else txt
    dpj = c.get("pj", 0) - h.get("pj", 0)
    if dpj <= 0:
        return None
    db, da = c.get("b", 0) - h.get("b", 0), c.get("a", 0) - h.get("a", 0)
    tete = f"{dpj} matchs" if dpj > 1 else "1 match"
    if t == "rocket":
        corps = f"{db} but{'s' if db > 1 else ''}" if db else "aucun but"
    else:
        corps = f"{db} B, {da} A" if db or da else "aucun point"
    extra = []
    if t == "selke" and c.get("pm") is not None and h.get("pm") is not None and c["pm"] != h["pm"]:
        extra.append(f"{c['pm'] - h['pm']:+d} au +/-")
    if t == "byng" and (c.get("pim") or 0) > (h.get("pim") or 0):
        extra.append(f"{(c.get('pim') or 0) - (h.get('pim') or 0)} min de pénalité")
    return f"{tete} : {corps}" + (f" ({', '.join(extra)})" if extra else "")


def _a_produit(t, c, h):
    if t == "vezina":
        return c.get("v", 0) > h.get("v", 0)
    if t == "rocket":
        return c.get("b", 0) > h.get("b", 0)
    return c.get("pts", 0) > h.get("pts", 0)


def ecarts(t, top, p_now, p_ref, c_now, c_ref, ctx, ref_ctx):
    """Ajoute à chaque ligne du top : dp (écart en proportion), rang_av, raison (texte)."""
    ids = set(p_now) | set(p_ref)
    delta = {i: p_now.get(i, 0.0) - p_ref.get(i, 0.0) for i in ids}
    ordre_ref = sorted(p_ref, key=lambda i: -p_ref[i])
    rang_ref = {i: k + 1 for k, i in enumerate(ordre_ref)}
    for x in top:
        i = x["id"]
        dp = delta.get(i, p_now.get(i, 0.0))
        x["dp"] = round(dp, 4)
        x["rang_av"] = rang_ref.get(i)
        c, h = c_now.get(i), c_ref.get(i)
        morceaux = []
        if h is None:
            morceaux.append("nouveau dans la course")
        else:
            r = resume_joueur(t, c, h)
            morceaux.append(r or "n'a pas joué")
            if t in ("hart", "lindsay", "selke"):
                eqr = _equipe_resultat(c.get("eq"), ctx, ref_ctx)
                if eqr:
                    morceaux.append(eqr)
            if x["rang_av"] and x["rang_av"] > 10:
                morceaux.insert(0, f"entre dans le top 10 (était {x['rang_av']}e)")
            # Un rival explique l'écart quand ce que le joueur a fait ne l'explique pas
            joue, produit = r is not None, _a_produit(t, c, h)
            if abs(dp) >= 0.003 and (not joue or (dp < 0 and produit) or (dp > 0 and not produit)):
                autres = [j for j in ids if j != i and j in c_now and j in c_ref]
                if autres:
                    j = max(autres, key=delta.get) if dp < 0 else min(autres, key=delta.get)
                    if (delta[j] > 0) == (dp < 0) and abs(delta[j]) >= 0.003:
                        rj = resume_joueur(t, c_now[j], c_ref[j]) or "n'a pas joué"
                        verbe = "monte" if delta[j] > 0 else "recule"
                        morceaux.append(f"{c_now[j]['nom']} {verbe} ({_pts_pct(delta[j])}) : {rj}")
        if abs(dp) < 0.002 and h is not None:
            morceaux.insert(0, "stable")
        x["raison"] = " · ".join(morceaux)
    return top


def charger_veille(jour):
    """(jour de référence, instantané) : le dernier calcul d'un jour AVANT `jour`."""
    v = _lire(DIR / "veille.json", {})
    avant = sorted(j for j in v if j < jour)
    return (avant[-1], v[avant[-1]]) if avant else (None, None)


def garder_veille(jour, instantane):
    v = _lire(DIR / "veille.json", {})
    v[jour] = instantane
    for j in sorted(v)[:-3]:      # 3 jours suffisent
        v.pop(j)
    _ecrire(DIR / "veille.json", v)


def _filtrer(t, cands):
    if t == "vezina":
        return [c for c in cands if c["gs"] >= 1][:40]
    if t == "selke":
        return [c for c in cands if c.get("pos") == "C"][:60]
    return cands[:60]


def _ligne(t, c, p, pr, saison):
    d = {"id": c["id"], "nom": c["nom"], "eq": c["eq"], "pos": c.get("pos"), "pj": c["pj"], "p": round(p, 4),
         "photo": f"https://assets.nhle.com/mugs/nhl/{saison}/{c['eq']}/{c['id']}.png"}
    if t == "vezina":
        d.update({"v": c["v"], "sv": c.get("sv"), "gaa": c.get("gaa"), "proj": round(pr, 1)})
    elif t == "selke":
        d.update({"pts": c["pts"], "b": c["b"], "a": c["a"], "fo": c.get("fo"), "pm": c.get("pm"), "deja": c.get("deja"),
                  "rep_g": c.get("rep_g"), "rep_f": c.get("rep_f"), "eqp": c.get("eqp"), "proj": round(pr, 1)})
    elif t == "byng":
        d.update({"pts": c["pts"], "b": c["b"], "a": c["a"], "pim": c.get("pim"), "proj": round(pr, 1)})
    elif t in ("hart", "lindsay"):
        d.update({"pts": c["pts"], "b": c["b"], "a": c["a"], "eqp": c.get("eqp"), "proj": round(pr, 1)})
    else:
        d.update({"pts": c["pts"], "b": c["b"], "a": c["a"], "toi": c.get("toi"), "proj": round(pr, 1)})
    return d


def tester(matchs, params, jour, sc, dispo_recrues, log=print):
    """Chaque saison passée, au même jour de saison qu'aujourd'hui : où était le gagnant, quel % on
    lui donnait, qui menait. Si l'API ignore le filtre de date, on le détecte (totaux = fin de saison)."""
    debut = lambda s: min((r[0] for r in matchs if r[1] == s and r[2] == 2), default=None)
    d0 = debut(sc)
    if not d0:
        return {}
    jours = (date.fromisoformat(jour) - date.fromisoformat(d0)).days
    out = {t: [] for t in STATS_T + VOTES}
    an_c = int(sc[:4])
    for an in range(PREMIERE + 1, an_c):
        s = f"{an}{an + 1}"
        ds = debut(s)
        if s in SAUTER or not ds:
            continue
        dc = (date.fromisoformat(ds) + timedelta(days=max(0, jours - 1))).isoformat()
        rest, pv, gp_eq = contexte_equipes(matchs, s, dc)
        priors = {"pts": _prior(s), "b": _prior_buts(s)}
        for t in out:
            if t == "calder" and not dispo_recrues:
                continue
            P = params.get(t) if t in VOTES else {}
            if t in VOTES and not P:
                continue
            fin = liste(GROUPE_DE[t], s)
            a_date = liste(GROUPE_DE[t], s, dc)
            if not fin or not a_date:
                continue
            # L'API a-t-elle vraiment coupé à la date ? (sinon les totaux sont ceux de la fin)
            if a_date[0]["pj"] >= fin[0]["pj"] and jours < 150:
                log("  trophées : l'API ignore la date, test à pareille date impossible")
                return {}
            if t == "art":
                g_nom = max(fin, key=lambda c: (c["pts"], c["b"]))["nom"]
            elif t == "rocket":
                g_nom = max(fin, key=lambda c: (c["b"], c["pts"]))["nom"]
            else:
                g_nom = GAGNANTS[t].get(s)
            cands = _filtrer(t, _preparer([dict(c) for c in a_date], gp_eq))
            enrichir(t, cands, s, pv)
            res = simuler(t, cands, rest, pv, priors["b" if t == "rocket" else "pts"], P, N_SIM_TEST)
            ordre = [c for c, _, _ in res]
            stat = (lambda c: c["v"]) if t == "vezina" else (lambda c: c["b"]) if t == "rocket" else (lambda c: c["pts"])
            rang_stat = sorted(cands, key=lambda c: -stat(c))
            gi = next((k for k, c in enumerate(rang_stat) if _nrm(c["nom"]) == _nrm(g_nom)), None)
            gs = next((k for k, c in enumerate(ordre) if _nrm(c["nom"]) == _nrm(g_nom)), None)
            out[t].append({"saison": s, "date": dc, "gagnant": g_nom,
                           "rang_stat": gi + 1 if gi is not None else None,
                           "stat": stat(rang_stat[gi]) if gi is not None else None,
                           "meneur": rang_stat[0]["nom"], "stat_meneur": stat(rang_stat[0]),
                           "p": round(res[gs][1], 4) if gs is not None else 0.0,
                           "rang_sim": gs + 1 if gs is not None else None,
                           "favori": res[0][0]["nom"], "p_favori": round(res[0][1], 4)})
        log(f"  trophées : test {s} au {dc} fait")
    return out
