"""Version FRANÇAISE du site public (puckprob.ca/fr/).

Le site anglais (site_public.py) est la version par défaut sur puckprob.ca ; celle-ci écrit les mêmes pages
en français dans le sous-dossier fr/. Les deux se répondent : un bouton FR | EN dans l'en-tête mène à la même
page dans l'autre langue, et chaque page déclare son équivalent à Google (balises hreflang).
Appelé par site_public.construire() : la mémoire des joueurs, les fichiers communs et le manifeste sont gérés là.
"""
import hashlib
import html
import json
import re
import shutil
import unicodedata
from datetime import date
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
DOCS = RACINE / "docs"
DIR_SITE = DOCS / "public"
# Mémoire cumulative des joueurs : un joueur vu une fois garde sa page (sinon Google
# tomberait sur des 404 les soirs où il ne joue pas). Commitée par le workflow avec data/.
MEMOIRE = RACINE / "data" / "site" / "joueurs.json"
RACINE_URL = "https://puckprob.ca"
DOMAINE = RACINE_URL + "/fr"   # adresse canonique des pages françaises
NOM_SITE = "PuckProb"
# Fichiers statiques copiés tels quels depuis docs/
ACTIFS = ("logo.png", "favicon-64.png", "icone-180.png", "icone-512.png", "og.png")

# ---------------------------------------------------------------------------------
# Libellés (mêmes que la page)
# ---------------------------------------------------------------------------------
MARCHES = [("tirs1", "Tirs 1+"), ("tirs", "Tirs 2+"), ("tirs3", "Tirs 3+"), ("tirs4", "Tirs 4+"),
           ("buts", "But"), ("buts2", "2+ buts"), ("buts3", "3+ buts"),
           ("passes", "Passe"), ("passes2", "2+ passes"), ("pts1", "1+ point"), ("pts2", "2+ points")]
NOM_MARCHE = dict(MARCHES) | {"victoire": "Victoire", "total55": "+5,5 buts dans le match",
                              "total65": "+6,5 buts dans le match"}
EQUIPES = {"ANA": "Anaheim", "BOS": "Boston", "BUF": "Buffalo", "CGY": "Calgary", "CAR": "Caroline",
           "CHI": "Chicago", "COL": "Colorado", "CBJ": "Columbus", "DAL": "Dallas", "DET": "Détroit",
           "EDM": "Edmonton", "FLA": "Floride", "LAK": "Los Angeles", "MIN": "Minnesota", "MTL": "Montréal",
           "NSH": "Nashville", "NJD": "New Jersey", "NYI": "Islanders de New York", "NYR": "Rangers de New York",
           "OTT": "Ottawa", "PHI": "Philadelphie", "PIT": "Pittsburgh", "SJS": "San Jose", "SEA": "Seattle",
           "STL": "St. Louis", "TBL": "Tampa Bay", "TOR": "Toronto", "UTA": "Utah", "VAN": "Vancouver",
           "VGK": "Vegas", "WSH": "Washington", "WPG": "Winnipeg"}
COULEUR = {"ANA": "#F47A38", "BOS": "#FFB81C", "BUF": "#003087", "CGY": "#C8102E", "CAR": "#CE1126",
           "CHI": "#CF0A2C", "COL": "#6F263D", "CBJ": "#002654", "DAL": "#006847", "DET": "#CE1126",
           "EDM": "#FF4C00", "FLA": "#C8102E", "LAK": "#A2AAAD", "MIN": "#154734", "MTL": "#AF1E2D",
           "NSH": "#FFB81C", "NJD": "#CE1126", "NYI": "#00539B", "NYR": "#0038A8", "OTT": "#C52032",
           "PHI": "#F74902", "PIT": "#FCB514", "SJS": "#006D75", "SEA": "#68A2B9", "STL": "#002F87",
           "TBL": "#002868", "TOR": "#00205B", "UTA": "#6CACE4", "VAN": "#00205B", "VGK": "#B4975A",
           "WSH": "#C8102E", "WPG": "#004C97"}
TROPHEES = {
    "art": ("Trophée Art-Ross", "le plus de points en saison régulière", "points"),
    "rocket": ("Trophée Maurice-Richard", "le plus de buts en saison régulière (le Rocket)", "buts"),
    "hart": ("Trophée Hart", "le joueur le plus utile à son équipe, voté par les journalistes", "points"),
    "lindsay": ("Trophée Ted-Lindsay", "le meilleur joueur selon les joueurs eux-mêmes", "points"),
    "norris": ("Trophée Norris", "le meilleur défenseur", "points"),
    "vezina": ("Trophée Vezina", "le meilleur gardien", "victoires"),
    "calder": ("Trophée Calder", "la meilleure recrue", "points"),
    "selke": ("Trophée Selke", "le meilleur attaquant défensif", "points"),
    "byng": ("Trophée Lady-Byng", "l'esprit sportif allié au talent", "points"),
}
TROPHEES_EQ = {
    "presidents": ("Trophée des Présidents", "le meilleur bilan de la saison régulière"),
    "jennings": ("Trophée William-M.-Jennings", "les gardiens de l'équipe qui accorde le moins de buts"),
    "adams": ("Trophée Jack-Adams", "l'entraîneur de l'année (on donne l'équipe, son entraîneur est le candidat)"),
}
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre",
        "novembre", "décembre"]
JOURS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]

e = html.escape  # tout texte qui vient des données passe par là

# Même page dans l'autre langue : les chemins français et anglais se correspondent un pour un
VERS_EN = {"joueurs/": "players/", "equipes/": "teams/", "trophees/": "trophies/", "coupe-stanley/": "stanley-cup/",
           "bilan/": "track-record/", "a-propos/": "about/"}


def chemin_en(chemin):
    for fr, en in VERS_EN.items():
        if chemin.startswith(fr):
            return en + chemin[len(fr):]
    return chemin


def date_fr(d, jour_sem=False):
    try:
        x = date.fromisoformat(str(d)[:10])
    except ValueError:
        return str(d or "")
    j = "1er" if x.day == 1 else str(x.day)
    return (f"{JOURS[x.weekday()]} " if jour_sem else "") + f"{j} {MOIS[x.month - 1]} {x.year}"


def pct(p, dec=None):
    """0.4567 -> « 46 % » ; sous 10 %, une décimale (virgule à la québécoise)."""
    if p is None:
        return "–"
    x = p * 100
    if x >= 99.5:
        return "99+\u00a0%"
    if x < 0.1:
        return "<0,1\u00a0%"
    d = dec if dec is not None else (1 if x < 10 else 0)
    return f"{x:.{d}f}".replace(".", ",") + "\u00a0%"   # espace insécable : le % ne tombe jamais seul sur une ligne


def mille(n):
    """12345 -> « 12 345 » (espace comme séparateur de milliers, à la française)."""
    try:
        return f"{int(n):,}".replace(",", "\u00a0")
    except (TypeError, ValueError):
        return "–"


def slugifier(nom):
    s = unicodedata.normalize("NFKD", str(nom)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-") or "joueur"


def saison_txt(s):
    s = str(s or "")
    return f"{s[:4]}-{s[4:]}" if len(s) == 8 else s


# ---------------------------------------------------------------------------------
# Gabarit commun : LE MÊME LOOK QUE L'APPLICATION
# ---------------------------------------------------------------------------------
# Le CSS des pages texte = le CSS de l'application (copié de docs/index.html à chaque calcul)
# + quelques règles en plus. Même en-tête, même menu, mêmes listes : un seul site.
CSS_EXTRA = """
/* --- Pages texte du site public (en plus du style de l'application) --- */
main{display:block}
.cp-tete h1{font:800 30px/1 var(--f-display);text-transform:uppercase;color:#fff;margin:0;letter-spacing:.02em;position:relative;z-index:1}
.cp-tete .eq-t{display:flex;align-items:center;gap:10px}
.cp-tete .eq-t img{width:44px;height:44px}
.tr .rgn{font:italic 800 18px/1 var(--f-display);color:var(--muted);text-align:center}
.tr .nm{font:800 19px/1.05 var(--f-display);text-transform:uppercase;min-width:0}
.tr .nm small{display:block;font:500 12px var(--f-body);color:var(--muted);text-transform:none;margin-top:3px}
.tr .pc{font:italic 800 30px/.9 var(--f-display);text-align:right}
.tr .pc small{font-size:15px}
.tr a,.cp a{color:inherit;text-decoration:none}
.tr a:hover,.cp a:hover{text-decoration:underline;text-decoration-color:var(--goal);text-underline-offset:3px}
.cp .pck{display:block;font:600 11px var(--f-body);color:var(--muted);font-style:normal;margin-top:3px}
.pl{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:3px 10px;align-items:center;padding:10px 12px;border-top:1px solid var(--line)}
.pl:first-child{border-top:0}
.pl .lib{font:700 15px/1.1 var(--f-body)}
.pl .lib small{display:block;font-weight:500;font-size:11.5px;color:var(--muted);margin-top:2px}
.pl .pc{font:italic 800 26px/.9 var(--f-display);text-align:right}
.pl .pc small{font-size:13px}
.pl .barre{grid-column:1 / 3;height:7px;background:var(--chip);clip-path:var(--biais)}
.pl .barre i{display:block;height:100%;background:linear-gradient(90deg,var(--eq,var(--ice)),color-mix(in srgb,var(--eq,var(--ice)) 60%,var(--led)))}
.bloc{margin:0 0 14px}
.bloc > h2{margin:18px 0 8px}
.chiffres{display:flex;flex-wrap:wrap;gap:10px 22px}
.chiffres div{min-width:64px}
.chiffres b{display:block;font:italic 800 28px/1 var(--f-display)}
.chiffres span{font-size:11.5px;color:var(--muted)}
.fiche-tete{display:flex;align-items:center;gap:14px}
.fiche-tete .ph{width:64px;height:64px;border-radius:50%;overflow:hidden;flex:none;box-shadow:0 0 0 3px var(--eq)}
.fiche-tete .rno{font-size:26px}
.grille{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}
.grille a{display:flex;align-items:center;gap:8px;background:var(--surface);border:1px solid var(--line);border-radius:6px;
  padding:9px 10px;text-decoration:none;color:var(--ink);font:700 15px/1.1 var(--f-body);box-shadow:var(--ombre)}
.grille a img{width:26px;height:26px;flex:none}
.texte p{margin:8px 0;max-width:68ch;line-height:1.55}
.texte h2{margin:22px 0 6px}
.lien-plus{display:inline-block;margin:10px 0 4px;font:italic 800 16px/1 var(--f-display);text-transform:uppercase;letter-spacing:.03em;
  color:#fff;background:var(--goal);padding:10px 22px 10px 14px;clip-path:var(--biais);text-decoration:none}
.pied{margin:28px 0 0;padding-top:14px;border-top:1px solid var(--line)}
.pied nav{display:flex;flex-wrap:wrap;gap:4px 14px;margin-top:8px}
.pied nav a{color:var(--ice);font-size:12.5px}
"""

# Menu du site : le même dans l'application (mode public) et dans chaque page texte
MENU = [("", "Ce soir"), ("trophees/", "Trophées"), ("coupe-stanley/", "Coupe"),
        ("equipes/", "Équipes"), ("bilan/", "Bilan"), ("a-propos/", "À propos")]


def menu_html(r, actif):
    liens = "".join(f'<a href="{r}{c}"{" aria-current=\"page\"" if c == actif else ""}>{n}</a>' for c, n in MENU)
    return f'<nav class="menu" aria-label="Menu du site">{liens}</nav>'


def pastille_src(t):
    """Même pastille que l'application (SVG en data URI) : rond à la couleur de l'équipe + abréviation."""
    c = COULEUR.get(t, "#6B7C8C")
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="46" fill="{c}" '
           f'stroke="#fff" stroke-width="6"/><text x="50" y="61" font-size="31" font-family="Arial Narrow,Arial,sans-serif" '
           f'font-weight="700" fill="#fff" text-anchor="middle">{e(t or "")}</text></svg>')
    from urllib.parse import quote
    return "data:image/svg+xml," + quote(svg)


def pastille(t, taille=26):
    return f'<img src="{pastille_src(t)}" alt="" width="{taille}" height="{taille}" style="vertical-align:middle">'


def eq_html(t, r, nom_long=False):
    """Équipe cliquable vers sa page (pastille + nom)."""
    if t not in EQUIPES:
        return e(t or "")
    return f'<a class="eq" href="{r}equipes/{t.lower()}/">{pastille(t, 22)} {e(EQUIPES[t] if nom_long else t)}</a>'


def barre(p, mx=1.0):
    w = 0 if not p or not mx else min(100, p / mx * 100)
    return f'<span class="barre"><i style="width:{w:.1f}%"></i></span>'


def pc_gros(p):
    """Le gros % de l'application : « 40<small>%</small> », 99+, <0,1, une décimale sous 10 %."""
    if p is None:
        return "–"
    x = p * 100
    t = "99+" if x >= 99.5 else "<0,1" if x < 0.1 else (f"{x:.1f}".replace(".", ",") if x < 10 else f"{x:.0f}")
    return f"{t}<small>%</small>"


def initiales(nom):
    return "".join(w[0] for w in str(nom or "").split()[:2]).upper()


def rond_no(no, nom):
    return f'<span class="rno">{e(str(no)) if no not in (None, "") else e(initiales(nom))}</span>'


def tete(titre, texte="", h1=True):
    """Bandeau marine de l'application (comme « Coupe Stanley » dans l'onglet Trophées)."""
    t = f"<h1>{titre}</h1>" if h1 else f"<h2>{titre}</h2>"
    return f'<div class="cp-tete">{t}{f"<p>{texte}</p>" if texte else ""}</div>'


def page(chemin, titre, desc, corps, actif=None, jsonld=None, maj=None):
    """Enveloppe HTML complète, même en-tête et même menu que l'application."""
    prof = chemin.count("/")
    r = "../" * prof
    ld = f'<script type="application/ld+json">{json.dumps(jsonld, ensure_ascii=False)}</script>\n' if jsonld else ""
    return f"""<!doctype html>
<html lang="fr-CA">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{e(titre)}</title>
<meta name="description" content="{e(desc)}">
<link rel="canonical" href="{DOMAINE}/{chemin}">
<link rel="alternate" hreflang="fr" href="{DOMAINE}/{chemin}">
<link rel="alternate" hreflang="en" href="{RACINE_URL}/{chemin_en(chemin)}">
<link rel="alternate" hreflang="x-default" href="{RACINE_URL}/{chemin_en(chemin)}">
<meta name="theme-color" content="#0A2342">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{NOM_SITE}">
<meta property="og:locale" content="fr_CA">
<meta property="og:title" content="{e(titre)}">
<meta property="og:description" content="{e(desc)}">
<meta property="og:url" content="{DOMAINE}/{chemin}">
<meta property="og:image" content="{DOMAINE}/og.png">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" type="image/png" href="{r}favicon-64.png">
<link rel="apple-touch-icon" href="{r}icone-180.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,600;0,700;0,800;1,700;1,800&family=Barlow:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="{r}site.css">
{ld}</head>
<body>
<div class="wrap">
<header class="bug">
  <div class="bug-t">
    <a href="{r}" aria-label="{NOM_SITE}, les matchs de ce soir"><img class="logo-site" src="{r}logo.png" alt="{NOM_SITE}" width="900" height="150"></a>
    <div class="maj">{e(maj or "")}</div>
  </div>
  <a class="lang" href="{r}../{chemin_en(chemin)}" hreflang="en" lang="en" aria-label="English version">EN</a>
</header>
{menu_html(r, actif)}
<main>
{corps}
</main>
<footer class="pied">
<b>{NOM_SITE}</b> calcule des probabilités à partir des données publiques de la LNH, des statistiques avancées de
<a href="https://moneypuck.com" rel="noopener">MoneyPuck.com</a> et des alignements de
<a href="https://www.dailyfaceoff.com" rel="noopener">DailyFaceoff</a>. Site indépendant, non affilié à la LNH ni à ses équipes.
Une probabilité n'est pas une certitude : le hockey reste le hockey.
{menu_html(r, actif).replace('class="menu"', 'class="menu-pied"')}
</footer>
</div>
</body>
</html>
"""


# ---------------------------------------------------------------------------------
# Lecture des données publiques
# ---------------------------------------------------------------------------------
def probs_joueur(j, principale):
    """{marché: p} de la prédiction principale, et {marché: p} ajusté à l'alignement du soir."""
    P = (j.get("preds") or {})
    base = P.get(principale) or P.get("combo") or {}
    soir = P.get("soir") or {}
    f = lambda d: {m: v["p"] for m, v in d.items() if isinstance(v, dict) and v.get("p") is not None}
    return f(base), f(soir)


def preds_match(g, principale):
    P = g.get("preds") or {}
    return P.get(principale) or P.get("combo") or {}


def candidats_trophees(pub):
    """{pid: {trophée: (rang, p)}} + infos de base des candidats (nom, équipe, position)."""
    out, infos = {}, {}
    for t, B in ((pub.get("trophees") or {}).get("trophees") or {}).items():
        for i, x in enumerate((B or {}).get("top") or []):
            pid = str(x.get("id"))
            out.setdefault(pid, {})[t] = (i + 1, x.get("p"))
            infos[pid] = x
    return out, infos


# ---------------------------------------------------------------------------------
# Mémoire des joueurs (slug stable + dernier calcul connu)
# ---------------------------------------------------------------------------------
def maj_memoire(pub, mem):
    principale = pub.get("principale")
    jour = pub.get("date")
    pris = {v["slug"]: pid for pid, v in mem.items() if v.get("slug")}

    def fiche(pid, nom):
        f = mem.setdefault(pid, {})
        if not f.get("slug"):
            s = slugifier(nom)
            if s in pris and pris[s] != pid:          # deux Sebastian Aho : le 2e prend son numéro LNH
                s = f"{s}-{pid}"
            f["slug"] = s
            pris[s] = pid
        return f

    for j in pub.get("joueurs") or []:
        pid = str(j.get("pid"))
        f = fiche(pid, j.get("name"))
        base, soir = probs_joueur(j, principale)
        f.update({"nom": j.get("name"), "eq": j.get("team"), "pos": j.get("pos"), "no": j.get("no"),
                  "saison": j.get("saison"), "vu": jour})
        if base:
            f["dernier"] = {"date": jour, "opp": j.get("opp"), "home": j.get("home"), "gid": j.get("gameId"),
                            "p": {m: round(p, 4) for m, p in base.items()},
                            "soir": {m: round(p, 4) for m, p in soir.items()},
                            "l10": {"tirs": j.get("l10_shots"), "buts": j.get("l10_goals"), "passes": j.get("l10_assists")}}
    cands, infos = candidats_trophees(pub)
    for f in mem.values():
        f.pop("troph", None)                         # recalculé à neuf : un joueur sorti du top 10 n'y reste pas
    for pid, tr in cands.items():
        x = infos[pid]
        f = fiche(pid, x.get("nom"))
        f.setdefault("nom", x.get("nom"))
        f.setdefault("pos", x.get("pos"))
        f["eq"] = x.get("eq") or f.get("eq")
        f["troph"] = {t: [r, p] for t, (r, p) in tr.items()}
        f.setdefault("vu", jour)
    return mem


# ---------------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------------
def liens_joueurs(mem):
    return {pid: v["slug"] for pid, v in mem.items() if v.get("slug")}


def nom_joueur(nom, pid, slugs, r):
    s = slugs.get(str(pid))
    return f'<a href="{r}joueurs/{s}/">{e(nom or "")}</a>' if s else e(nom or "")


def section_matchs(pub, r):
    principale = pub.get("principale")
    lignes = []
    for g in pub.get("games") or []:
        c = preds_match(g, principale)
        ph = c.get("p_home")
        if ph is None:
            continue
        tot = c.get("total")
        lignes.append(f"""<tr><td>{eq_html(g.get("away"), r)} <span class="note">@</span> {eq_html(g.get("home"), r)}</td>
<td class="n"><span class="p">{pct(1 - ph)}</span><br><span class="note">{e(g.get("away") or "")}</span></td>
<td class="n"><span class="p">{pct(ph)}</span><br><span class="note">{e(g.get("home") or "")}</span></td>
<td class="n">{f"{tot:.1f}".replace(".", ",") if tot else "–"}</td></tr>""")
    if not lignes:
        return "<p>Pas de match à l'horaire pour cette date.</p>"
    return f"""<div class="carte tbl"><table><thead><tr><th>Match</th><th class="n">Visiteur</th><th class="n">Local</th>
<th class="n">Buts attendus</th></tr></thead><tbody>{"".join(lignes)}</tbody></table></div>
<p class="note">Probabilité de gagner le match (prolongation et tirs de barrage inclus).</p>"""


def top_marche(pub, m, n, slugs, r):
    principale = pub.get("principale")
    rows = []
    for j in pub.get("joueurs") or []:
        p = probs_joueur(j, principale)[0].get(m)
        if p is not None:
            rows.append((p, j))
    rows.sort(key=lambda x: -x[0])
    rows = rows[:n]
    if not rows:
        return ""
    mx = rows[0][0]
    corps = "".join(f"""<tr><td>{nom_joueur(j.get("name"), j.get("pid"), slugs, r)}<br><span class="note">{e(j.get("team") or "")} {"vs" if j.get("home") else "@"} {e(j.get("opp") or "")}</span></td>
<td class="n"><span class="p">{pct(p)}</span>{barre(p, mx)}</td></tr>""" for p, j in rows)
    return f"""<div class="carte tbl"><h3>{e(NOM_MARCHE[m])}</h3><table><tbody>{corps}</tbody></table></div>"""


def page_accueil_resume(pub, mem, r=""):
    """Bloc texte inséré dans la page de l'application (index.html) : ce que Google lit."""
    slugs = liens_joueurs(mem)
    jour = pub.get("date")
    favs = ""
    eqs = ((pub.get("coupe") or {}).get("equipes") or [])[:5]
    if eqs:
        favs = ('<div class="carte"><h3>Favoris de la Coupe Stanley</h3><ul class="liste">' + "".join(
            f'<li>{eq_html(x["t"], r, True)}<b>{pct(x.get("p_coupe"))}</b></li>' for x in eqs)
            + f'</ul><p><a href="{r}coupe-stanley/">Les 32 équipes</a></p></div>')
    tr = []
    for t, (nom, _, _) in TROPHEES.items():
        top = ((((pub.get("trophees") or {}).get("trophees") or {}).get(t) or {}).get("top") or [])
        if top:
            x = top[0]
            tr.append(f'<li><span><a href="{r}trophees/{t}/">{e(nom.replace("Trophée ", ""))}</a> · '
                      f'{nom_joueur(x.get("nom"), x.get("id"), slugs, r)}</span><b>{pct(x.get("p"))}</b></li>')
    tr_html = f'<div class="carte"><h3>Courses aux trophées : les favoris</h3><ul class="liste">{"".join(tr)}</ul></div>' if tr else ""
    return f"""<section class="resume-public" aria-labelledby="resume-titre">
<h2 id="resume-titre">En bref, {e(date_fr(jour, True))}</h2>
{section_matchs(pub, r)}
<div class="duo">{top_marche(pub, "buts", 10, slugs, r)}{top_marche(pub, "pts1", 10, slugs, r)}{top_marche(pub, "tirs3", 10, slugs, r)}</div>
{favs}{tr_html}
<p><a href="{r}trophees/">Tous les trophées</a> · <a href="{r}equipes/">Les 32 équipes</a> · <a href="{r}bilan/">Notre bilan : est-ce que nos % disent vrai?</a> · <a href="{r}a-propos/">Comment c'est calculé</a></p>
</section>"""


def maj_txt(pub):
    return f"Mis à jour le {date_fr(pub.get('date'))}"


def ligne_joueur(rang, nom_html, no, nom, eq, sous, p, mx, stat=""):
    """Une ligne de joueur au style de l'onglet Trophées de l'application."""
    return f"""<div class="tr" style="--eq:{COULEUR.get(eq, '#6B7C8C')}">
<span class="rgn">{rang}</span><span class="ph">{rond_no(no, nom)}</span>
<span class="nm">{nom_html}<small>{sous}</small></span>
<span class="pc">{pc_gros(p)}</span>{barre(p, mx)}{f'<span class="stat">{stat}</span>' if stat else ""}</div>"""


def ligne_equipe(rang, t, r, sous, p, mx, etiquette=""):
    """Une ligne d'équipe au style de la Coupe dans l'application."""
    nom = f'<a href="{r}equipes/{t.lower()}/">{e(EQUIPES.get(t, t))}</a>' if t in EQUIPES else e(t or "")
    return f"""<div class="cp" style="--eq:{COULEUR.get(t, '#6B7C8C')}">
<span class="rgn">{rang}</span><img class="lg" src="{pastille_src(t)}" alt="">
<span class="nm">{nom}<small>{sous}</small></span>
<span class="pc">{pc_gros(p)}{f'<span class="pck">{etiquette}</span>' if etiquette else ""}</span>{barre(p, mx)}</div>"""


def ligne_prob(lib, p, sous=""):
    return f"""<div class="pl"><span class="lib">{e(lib)}{f"<small>{sous}</small>" if sous else ""}</span>
<span class="pc">{pc_gros(p)}</span>{barre(p)}</div>"""


def page_joueur(pid, f, pub, slugs):
    chemin = f"joueurs/{f['slug']}/"
    r = "../../"
    nom, eq = f.get("nom") or "Joueur", f.get("eq")
    pos = {"D": "Défenseur", "G": "Gardien"}.get(f.get("pos"), "Attaquant")
    jour = pub.get("date")
    d = f.get("dernier")
    s = f.get("saison") or {}
    coul = COULEUR.get(eq, "#6B7C8C")
    no = f.get("no")
    blocs = []
    if d and d.get("p"):
        ce_soir = d.get("date") == jour
        lieu = "contre" if d.get("home") else "à"
        adv = EQUIPES.get(d.get("opp"), d.get("opp"))
        titre = f"Ce soir, {lieu} {adv}" if ce_soir else f"Son dernier match calculé : {date_fr(d.get('date'))}, {lieu} {adv}"
        soir = d.get("soir") or {}
        lignes = "".join(ligne_prob(lib, d["p"][m], f"avec l'alignement du soir : {pct(soir[m])}" if soir.get(m) is not None else "")
                         for m, lib in MARCHES if m in d["p"])
        l10 = d.get("l10") or {}
        forme = ""
        if l10.get("tirs"):
            forme = (f'<p class="aide" style="margin:8px 2px 0">10 derniers matchs — tirs : {" · ".join(map(str, l10["tirs"]))} · '
                     f'buts : {sum(l10.get("buts") or [])} · passes : {sum(l10.get("passes") or [])}</p>')
        rien = "" if ce_soir else '<p class="aide" style="margin:8px 2px 0">Pas de match pour lui ce soir : la page se met à jour à son prochain match.</p>'
        blocs.append(f'<section class="bloc"><h2>{e(titre)}</h2><div class="cp-liste" style="--eq:{coul}">{lignes}</div>{forme}{rien}</section>')
    elif f.get("pos") == "G":
        blocs.append('<p class="aide">Les gardiens n\'ont pas de probabilités de tirs ou de points : on les suit dans la course au Vezina.</p>')
    tr = f.get("troph") or {}
    if tr:
        lignes = "".join(
            f'<div class="pl" style="--eq:{coul}"><span class="lib"><a href="{r}trophees/{t}/" style="color:inherit">{e((TROPHEES.get(t) or (t,))[0])}</a>'
            f'<small>{rg}<sup>e</sup> de la course</small></span><span class="pc">{pc_gros(p)}</span>{barre(p)}</div>'
            for t, (rg, p) in sorted(tr.items(), key=lambda kv: -(kv[1][1] or 0)))
        blocs.append(f'<section class="bloc"><h2>Courses aux trophées</h2><div class="cp-liste">{lignes}</div></section>')
    if s.get("pj") is not None:
        pr = s.get("proj") or {}
        toi = f'<div><b>{s["toi"]:.1f}</b><span>min/match</span></div>'.replace(".", ",") if s.get("toi") else ""
        blocs.append(f"""<section class="bloc"><h2>Cette saison</h2><div class="card"><div class="chiffres">
<div><b>{s.get("pj")}</b><span>matchs</span></div><div><b>{s.get("b", 0)}</b><span>buts</span></div>
<div><b>{s.get("a", 0)}</b><span>passes</span></div><div><b>{s.get("pts", 0)}</b><span>points</span></div>
<div><b>{s.get("tirs", 0)}</b><span>tirs</span></div>{toi}</div>
{f'<p class="aide">Projection en fin de saison : {pr.get("b")} buts, {pr.get("a")} passes, {pr.get("pts")} points, {pr.get("tirs")} tirs.</p>' if pr else ""}</div></section>""")
    num = f" · #{e(str(no))}" if no not in (None, "") else ""
    p_but = d["p"].get("buts") if d and d.get("p") and d.get("date") == jour else None
    desc = (f"{nom} ({EQUIPES.get(eq, eq)}) : {pct(p_but)} de chances de marquer ce soir, plus ses probabilités de tirs, de passes et de points, et ses chances aux trophées. Mis à jour chaque jour."
            if p_but is not None else
            f"{nom} ({EQUIPES.get(eq, eq)}) : probabilités de buts, de tirs, de passes et de points match par match, statistiques et chances aux trophées.")
    corps = f"""<div class="cp-tete"><div class="fiche-tete" style="--eq:{coul}"><span class="ph">{rond_no(no, nom)}</span>
<div><h1>{e(nom)}</h1><p><a href="{r}equipes/{(eq or '').lower()}/" style="color:inherit">{e(EQUIPES.get(eq, eq or ""))}</a> · {pos}{num}</p></div></div></div>
{"".join(blocs) or '<div class="card"><div class="vide">Aucune donnée pour le moment.</div></div>'}
<a class="lien-plus" href="{r}">Tous les matchs de ce soir</a>"""
    ld = {"@context": "https://schema.org", "@type": "ProfilePage",
          "mainEntity": {"@type": "Person", "name": nom, "affiliation": {"@type": "SportsTeam", "name": EQUIPES.get(eq, eq or "")}}}
    return chemin, page(chemin, f"{nom} : probabilités de buts, points et tirs | {NOM_SITE}", desc, corps, jsonld=ld, maj=maj_txt(pub))


def page_equipe(t, pub, mem, slugs):
    chemin = f"equipes/{t.lower()}/"
    r = "../../"
    nom = EQUIPES[t]
    coul = COULEUR.get(t, "#6B7C8C")
    blocs = []
    C = pub.get("coupe") or {}
    eqs = C.get("equipes") or []
    x = next((v for v in eqs if v.get("t") == t), None)
    if x:
        rang = eqs.index(x) + 1
        etapes = [("p_series", "Fait les séries"), ("p_r2", "Gagne une série"), ("p_finale_conf", "Finale d'association"),
                  ("p_finale", "Finale de la Coupe"), ("p_coupe", "Gagne la Coupe Stanley"), ("p_presidents", "Trophée des Présidents")]
        lignes = "".join(ligne_prob(lib, x.get(k)) for k, lib in etapes if x.get(k) is not None)
        blocs.append(f"""<section class="bloc"><div class="card"><div class="chiffres"><div><b>{x.get("pts", "–")}</b><span>points</span></div>
<div><b>{x.get("pj", "–")}</b><span>matchs joués</span></div><div><b>{round(x["proj"]) if x.get("proj") is not None else "–"}</b><span>points projetés</span></div>
<div><b>{rang}<sup>e</sup></b><span>favori de la Coupe</span></div></div></div></section>
<section class="bloc"><h2>Ses chances</h2><p class="aide" style="margin:0 2px 8px">Sur {mille(C.get("n_sim", 0))} fins de saison simulées.</p>
<div class="cp-liste" style="--eq:{coul}">{lignes}</div></section>""")
    principale = pub.get("principale")
    for g in pub.get("games") or []:
        if t in (g.get("home"), g.get("away")):
            c = preds_match(g, principale)
            if c.get("p_home") is None:
                continue
            dom = g.get("home") == t
            adv = g.get("away") if dom else g.get("home")
            p = c["p_home"] if dom else 1 - c["p_home"]
            tot = f'{c["total"]:.1f}'.replace(".", ",") if c.get("total") else None
            blocs.append(f"""<section class="bloc"><h2>Ce soir {"contre" if dom else "à"} {e(EQUIPES.get(adv, adv))}</h2>
<div class="cp-liste" style="--eq:{coul}">{ligne_prob("Gagne le match", p, "prolongation et tirs de barrage compris")}</div>
{f'<p class="aide" style="margin:8px 2px 0">Buts attendus dans le match : {tot}</p>' if tot else ""}</section>""")
    jou = sorted(((pid, f) for pid, f in mem.items() if f.get("eq") == t and f.get("slug")),
                 key=lambda kv: -((kv[1].get("saison") or {}).get("pts") or 0))
    if jou:
        liens = "".join(f'<a href="{r}joueurs/{f["slug"]}/" style="--eq:{coul}"><span class="ph" style="width:26px;height:26px;border-radius:50%;overflow:hidden;flex:none">{rond_no(f.get("no"), f.get("nom"))}</span>{e(f.get("nom") or "")}</a>' for _, f in jou)
        blocs.append(f'<section class="bloc"><h2>Joueurs</h2><div class="grille">{liens}</div></section>')
    desc = f"{nom} : chances de faire les séries et de gagner la Coupe Stanley, probabilité de victoire ce soir et probabilités de ses joueurs. Mis à jour chaque jour."
    corps = f"""<div class="cp-tete"><div class="eq-t"><img src="{pastille_src(t)}" alt=""><h1>{e(nom)}</h1></div></div>
{"".join(blocs) or '<div class="card"><div class="vide">Les simulations arrivent au prochain calcul.</div></div>'}"""
    return chemin, page(chemin, f"{nom} : chances de séries et de Coupe Stanley | {NOM_SITE}", desc, corps, actif="equipes/",
                        jsonld={"@context": "https://schema.org", "@type": "SportsTeam", "name": nom, "sport": "Hockey"}, maj=maj_txt(pub))


def page_equipes(pub):
    chemin = "equipes/"
    liens = "".join(f'<a href="{t.lower()}/"><img src="{pastille_src(t)}" alt="">{e(n)}</a>' for t, n in sorted(EQUIPES.items(), key=lambda kv: kv[1]))
    corps = f"""{tete("Les 32 équipes", "Chances de séries, de Coupe Stanley et probabilités du soir, équipe par équipe.")}
<div class="grille">{liens}</div>"""
    return chemin, page(chemin, f"Équipes de la LNH : chances de séries et de Coupe | {NOM_SITE}",
                        "Les 32 équipes de la LNH : chances de faire les séries, de gagner la Coupe Stanley et probabilités de victoire, mises à jour chaque jour.",
                        corps, actif="equipes/", maj=maj_txt(pub))


def page_coupe(pub):
    chemin = "coupe-stanley/"
    r = "../"
    C = pub.get("coupe") or {}
    eqs = C.get("equipes") or []
    if eqs:
        mx = max((x.get("p_coupe") or 0) for x in eqs) or 1
        lignes = "".join(ligne_equipe(i + 1, x["t"], r, f'{x.get("pts", "–")} pts en {x.get("pj", "–")} matchs · séries {pct(x.get("p_series"))}',
                                      x.get("p_coupe"), mx, "Coupe") for i, x in enumerate(eqs))
        liste = f'<div class="cp-liste">{lignes}</div>'
    else:
        liste = '<div class="card"><div class="vide">Les simulations arrivent au prochain calcul.</div></div>'
    n = C.get("n_sim")
    corps = f"""{tete("Qui va gagner la Coupe Stanley?",
                     f"{mille(n) + ' fins' if n else 'Des milliers de fins'} de saison simulées chaque jour à partir de la force de chaque équipe (un classement Elo réglé sur les saisons passées) et des matchs qui restent à son calendrier, puis les séries au vrai format. Le % = la part des simulations où l'équipe soulève la Coupe.")}
{liste}"""
    return chemin, page(chemin, f"Chances de gagner la Coupe Stanley, équipe par équipe | {NOM_SITE}",
                        "Probabilités de chaque équipe de la LNH de faire les séries et de gagner la Coupe Stanley, recalculées chaque jour par simulation.",
                        corps, actif="coupe-stanley/", maj=maj_txt(pub))


def stat_troph(t, x):
    p = lambda v: "–" if v is None else v
    proj = round(x["proj"]) if x.get("proj") is not None else "–"
    if t == "vezina":
        sv = f"{x['sv']:.3f}".lstrip("0") if x.get("sv") is not None else "–"
        return f"<span><b>{p(x.get('v'))}</b> victoires</span><span>% d'arrêts <b>{sv}</b></span><span>projeté <b>{proj}</b> victoires</span>"
    if t == "rocket":
        return f"<span><b>{p(x.get('b'))}</b> buts</span><span>projeté <b>{proj}</b> buts</span>"
    return f"<span><b>{p(x.get('pts'))}</b> pts ({p(x.get('b'))} B, {p(x.get('a'))} A)</span><span>projeté <b>{proj}</b> pts</span>"


def page_trophee(t, pub, slugs, mem):
    chemin = f"trophees/{t}/"
    r = "../../"
    nom, desc_t, _ = TROPHEES[t]
    B = ((pub.get("trophees") or {}).get("trophees") or {}).get(t) or {}
    top = B.get("top") or []
    vote = t not in ("art", "rocket")
    methode = ("C'est un vote : on a appris ce que les votants récompensent à partir des gagnants des saisons passées, "
               "puis on simule la fin de saison 10 000 fois." if vote else
               "On simule le reste de la saison 10 000 fois, match par match, au rythme de chaque joueur.")
    if top:
        mx = top[0].get("p") or 1
        lignes = "".join(ligne_joueur(
            i + 1, nom_joueur(x.get("nom"), x.get("id"), slugs, r), (mem.get(str(x.get("id"))) or {}).get("no"), x.get("nom"), x.get("eq"),
            f'{e(x.get("eq") or "")} · {x.get("pj", "–")} matchs', x.get("p"), mx, stat_troph(t, x)) for i, x in enumerate(top))
        liste = f'<div class="cp-liste">{lignes}</div>'
    else:
        liste = f'<div class="card"><div class="vide">{e(B.get("msg") or "Le calcul arrive bientôt.")}</div></div>'
    T = [x for x in (B.get("test") or []) if x.get("gagnant")]
    test = ""
    if T:
        top3 = sum(1 for x in T if x.get("rang_stat") and x["rang_stat"] <= 3)
        s_ = "s" if len(T) > 1 else ""
        test = (f'<p class="aide" style="margin:10px 2px 0">Testé sur {len(T)} saison{s_} passée{s_}, à pareille date : '
                f'le gagnant était dans notre top 3 {top3} fois sur {len(T)}.</p>')
    corps = f"""{tete(e(nom), e(desc_t[0].upper() + desc_t[1:]) + ". " + methode)}
{liste}{test}
<a class="lien-plus" href="{r}trophees/">Les autres trophées</a>"""
    favori = f" Favori : {top[0].get('nom')} ({pct(top[0].get('p'))})." if top else ""
    return chemin, page(chemin, f"{nom} : qui va le gagner? Chances de chaque candidat | {NOM_SITE}",
                        f"Chances de chaque candidat au {nom} ({desc_t}), recalculées chaque jour.{favori}", corps,
                        actif="trophees/", maj=maj_txt(pub))


def page_trophee_eq(t, pub):
    chemin = f"trophees/{t}/"
    r = "../../"
    nom, desc_t = TROPHEES_EQ[t]
    L = (((pub.get("coupe") or {}).get("trophees_equipe")) or {}).get(t) or []
    if L:
        mx = max((x.get("p") or 0) for x in L) or 1
        lignes = "".join(ligne_equipe(i + 1, x.get("t"), r, "", x.get("p"), mx) for i, x in enumerate(L[:16]))
        liste = f'<div class="cp-liste">{lignes}</div>'
    else:
        liste = '<div class="card"><div class="vide">Le calcul arrive bientôt.</div></div>'
    corps = f"""{tete(e(nom), e(desc_t[0].upper() + desc_t[1:]) + ".")}
{liste}
<a class="lien-plus" href="{r}trophees/">Les autres trophées</a>"""
    return chemin, page(chemin, f"{nom} : chances de chaque équipe | {NOM_SITE}",
                        f"Chances de chaque équipe au {nom} ({desc_t}), recalculées chaque jour.", corps,
                        actif="trophees/", maj=maj_txt(pub))


def page_trophees(pub, slugs, mem):
    chemin = "trophees/"
    r = "../"
    blocs = []
    for t, (nom, desc_t, _) in TROPHEES.items():
        top = ((((pub.get("trophees") or {}).get("trophees") or {}).get(t) or {}).get("top") or [])[:3]
        mx = (top[0].get("p") if top else 1) or 1
        lignes = "".join(ligne_joueur(i + 1, nom_joueur(x.get("nom"), x.get("id"), slugs, r), (mem.get(str(x.get("id"))) or {}).get("no"),
                                      x.get("nom"), x.get("eq"), e(x.get("eq") or ""), x.get("p"), mx) for i, x in enumerate(top))
        blocs.append(f'<section class="bloc"><h2><a href="{t}/" style="color:inherit">{e(nom)}</a></h2><p class="aide" style="margin:0 2px 8px">{e(desc_t[0].upper() + desc_t[1:])}</p>'
                     f'{f"<div class=cp-liste>{lignes}</div>" if lignes else "<div class=card><div class=vide>Calcul à venir.</div></div>"}'
                     f'<a class="aide" href="{t}/" style="display:inline-block;margin:6px 2px 0">Les 10 favoris →</a></section>')
    for t, (nom, desc_t) in TROPHEES_EQ.items():
        L = ((((pub.get("coupe") or {}).get("trophees_equipe")) or {}).get(t) or [])[:3]
        mx = (L[0].get("p") if L else 1) or 1
        lignes = "".join(ligne_equipe(i + 1, x.get("t"), r, "", x.get("p"), mx) for i, x in enumerate(L))
        blocs.append(f'<section class="bloc"><h2><a href="{t}/" style="color:inherit">{e(nom)}</a></h2><p class="aide" style="margin:0 2px 8px">{e(desc_t[0].upper() + desc_t[1:])}</p>'
                     f'{f"<div class=cp-liste>{lignes}</div>" if lignes else "<div class=card><div class=vide>Calcul à venir.</div></div>"}'
                     f'<a class="aide" href="{t}/" style="display:inline-block;margin:6px 2px 0">Le classement complet →</a></section>')
    corps = f"""{tete("Les trophées de la LNH", "Les favoris de chaque trophée, recalculés chaque jour. Touche un trophée pour voir ses 10 favoris.")}
{"".join(blocs)}"""
    return chemin, page(chemin, f"Trophées de la LNH : les favoris du Hart, Norris, Vezina, Calder et plus | {NOM_SITE}",
                        "Qui va gagner le Hart, l'Art-Ross, le Maurice-Richard, le Norris, le Vezina, le Calder et les autres trophées de la LNH? Chances recalculées chaque jour.",
                        corps, actif="trophees/", maj=maj_txt(pub))


def bloc_calib(nom, st):
    calib = [c for c in (st.get("calib") or []) if c.get("n")]
    if not st.get("n") or not calib:
        return ""
    brut = lambda x: "–" if x is None else f"{round(x * 100)} %"
    tranche = lambda t: t.replace("-", " à ") + " %"
    rows = "".join(f"""<tr><td>{e(tranche(c["tranche"]))}</td><td>{c["n"]}</td><td>{brut(c.get("predit"))}</td>
<td><b>{brut(c.get("reel"))}</b></td></tr>""" for c in calib)
    note = st.get("note")
    return f"""<section class="bloc"><h2>{e(nom)}</h2><div class="card">
<div class="chiffres"><div><b>{mille(st["n"])}</b><span>prédictions vérifiées</span></div>
{f'<div><b>{note:.0f}</b><span>note /100</span></div>' if note is not None else ""}
{f'<div><b>{round(st["precision"] * 100)} %</b><span>bon côté</span></div>' if st.get("precision") is not None else ""}</div>
<div class="tbl"><table><thead><tr><th>On disait</th><th>Fois</th><th>En moyenne</th><th>C'est arrivé</th></tr></thead>
<tbody>{rows}</tbody></table></div></div></section>"""


def page_bilan(pub, stats):
    chemin = "bilan/"
    principale = pub.get("principale")
    blocs = []
    for m, st in ((stats or {}).get("matchs") or {}).items():
        blocs.append(bloc_calib(NOM_MARCHE.get(m, m), (st or {}).get(principale) or {}))
    for m, lib in MARCHES:
        st = (((stats or {}).get("joueurs") or {}).get(m) or {}).get(principale) or {}
        blocs.append(bloc_calib(lib, st))
    blocs = [b for b in blocs if b]
    retro, direct = (stats or {}).get("soirs_retro"), (stats or {}).get("soirs_direct")
    soirs = ""
    if retro is not None or direct is not None:
        soirs = (f"<p class=\"aide\">Soirs comptés : {direct or 0} prédits avant les matchs, {retro or 0} rejoués après coup "
                 "avec seulement les données disponibles avant le match (pour avoir plus d'historique dès le départ).</p>")
    corps = f"""{tete("Notre bilan", "Est-ce que nos % disent vrai? Chaque prédiction est vérifiée après le match. Si on dit 70 % cent fois, ça devrait arriver environ 70 fois : la colonne « C'est arrivé » le montre, tranche par tranche.")}
<div class="card"><p class="aide" style="margin:0"><b>Note /100</b> : 50 = pas mieux que donner le même % à tout le monde, 100 = parfait (impossible).
Pour les joueurs, 55 à 60 est un bon modèle ; pour les victoires, même les meilleurs modèles publics tournent autour de 52 à 55, le hockey est très aléatoire.
<b>Bon côté</b> : la part des fois où le côté jugé favori est arrivé.</p>{soirs}</div>
{"".join(blocs) or '<div class="card"><div class="vide">Le bilan se remplit au fil des soirs.</div></div>'}"""
    return chemin, page(chemin, f"Bilan : nos probabilités LNH vérifiées après chaque match | {NOM_SITE}",
                        "Chaque probabilité publiée par PuckProb est vérifiée après le match. Calibration et précision, marché par marché.",
                        corps, actif="bilan/", maj=maj_txt(pub))


def page_apropos(pub):
    chemin = "a-propos/"
    corps = f"""{tete("Comment c'est calculé", f"{NOM_SITE} donne, chaque soir de match, la probabilité que chaque joueur obtienne un tir, un but, une passe ou un point, la probabilité de chaque équipe de gagner, et les chances aux trophées et à la Coupe Stanley. Que des pourcentages.")}
<div class="card texte">
<h2>Les joueurs</h2>
<p>Pour chaque joueur : son rythme de tirs, de buts et de passes par 60 minutes (pondéré vers ses matchs récents et ramené vers la moyenne
quand il a peu joué), son temps de glace prévu, son unité d'avantage numérique, l'adversaire (défensive, gardien partant), le domicile,
les matchs en deux soirs de suite, ses tendances personnelles et les statistiques avancées de MoneyPuck. Avec l'alignement du soir,
on ajuste son trio, son avantage numérique et le gardien adverse.</p>
<p>Chaque facteur fait monter (+) ou baisser (−) ses chances par rapport à un match ordinaire : dans l'application, touche « Pourquoi ce % » sous un joueur pour les voir un par un.
Plusieurs modèles sont comparés en continu sur les vrais résultats ; celui qui prédit le mieux chaque catégorie est celui qu'on publie.</p>
<h2>Les matchs</h2>
<p>Les buts attendus de chaque équipe viennent de la forme récente, de l'attaque et de la défensive des deux équipes et des gardiens.
La probabilité de victoire inclut la prolongation et les tirs de barrage.</p>
<h2>Les trophées et la Coupe</h2>
<p>Le reste de la saison est simulé 10 000 fois. Pour les trophées votés (Hart, Norris, Vezina, Calder, Selke, etc.), on a appris ce que
les votants récompensent à partir des gagnants des saisons passées. Au Selke, par exemple, la réputation compte beaucoup.</p>
<h2>Vérifié, tous les soirs</h2>
<p>Chaque probabilité est comparée au résultat réel. Tout est sur la page <a href="../bilan/">Bilan</a>.</p>
<h2>Sources</h2>
<p>Données publiques de la LNH, statistiques avancées de <a href="https://moneypuck.com" rel="noopener">MoneyPuck.com</a>,
alignements de <a href="https://www.dailyfaceoff.com" rel="noopener">DailyFaceoff</a>. Site indépendant, non affilié à la LNH
ni à ses équipes. Aucune photo ni aucun logo officiel n'est utilisé.</p></div>"""
    return chemin, page(chemin, f"Comment PuckProb calcule ses probabilités LNH | {NOM_SITE}",
                        "La méthode derrière les probabilités de PuckProb : joueurs, matchs, trophées et Coupe Stanley.",
                        corps, actif="a-propos/", maj=maj_txt(pub))


def page_404():
    corps = f"""{tete("Page introuvable", "Cette page n'existe pas, ou plus.")}<a class="lien-plus" href="/">Retour aux matchs du soir</a>"""
    h = page("404/", f"Page introuvable | {NOM_SITE}", "Page introuvable.", corps)
    h = h.replace(f'<link rel="canonical" href="{DOMAINE}/404/">\n', '<meta name="robots" content="noindex">\n')
    return h.replace('="../', '="/')


# ---------------------------------------------------------------------------------
# Page de l'application (index.html) : docs/index.html en mode public + texte pour Google
# ---------------------------------------------------------------------------------
def page_app(pub, mem):
    src = (DOCS / "index.html").read_text(encoding="utf-8")
    src = src.replace('<html lang="fr-CA">', '<html lang="fr-CA" data-public="1">', 1)
    titre = f"{NOM_SITE} : probabilités LNH du soir, buts, points, tirs et trophées"
    desc = ("Probabilités de chaque joueur de la LNH ce soir (buts, passes, points, tirs), chances de victoire de chaque match, "
            "favoris des trophées et de la Coupe Stanley. Mis à jour chaque jour, vérifié après chaque match.")
    tete = f"""<title>{e(titre)}</title>
<meta name="description" content="{e(desc)}">
<link rel="canonical" href="{DOMAINE}/">
<link rel="alternate" hreflang="fr" href="{DOMAINE}/">
<link rel="alternate" hreflang="en" href="{RACINE_URL}/">
<link rel="alternate" hreflang="x-default" href="{RACINE_URL}/">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{NOM_SITE}">
<meta property="og:locale" content="fr_CA">
<meta property="og:title" content="{e(titre)}">
<meta property="og:description" content="{e(desc)}">
<meta property="og:url" content="{DOMAINE}/">
<meta property="og:image" content="{DOMAINE}/og.png">
<meta name="twitter:card" content="summary_large_image">
<script type="application/ld+json">{json.dumps({"@context": "https://schema.org", "@type": "WebSite", "name": NOM_SITE, "url": DOMAINE + "/", "inLanguage": "fr-CA"}, ensure_ascii=False)}</script>"""
    src = src.replace("<title>PuckProb</title>", tete, 1)
    src = src.replace('<meta name="robots" content="noindex">\n', "", 1)
    # Le résumé texte va juste avant la fin du contenu principal (marqueur posé dans docs/index.html)
    resume = page_accueil_resume(pub, mem)
    style = """<style>.resume-public{margin-top:28px}.resume-public h3{font:800 18px/1.1 var(--f-display);text-transform:uppercase;margin:14px 0 6px}
.resume-public table{width:100%;border-collapse:collapse;font-size:14px}.resume-public td,.resume-public th{padding:6px;border-bottom:1px solid var(--line);text-align:left}
.resume-public .n{text-align:right}.resume-public .p{font:800 18px/1 var(--f-display)}.resume-public .note{color:var(--muted);font-size:12px}
.resume-public .carte{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin:10px 0}
.resume-public .barre{display:block;height:5px;border-radius:3px;background:var(--surface2);margin-top:3px}.resume-public .barre i{display:block;height:100%;border-radius:3px;background:var(--ice)}
.resume-public .pas{display:inline-grid;place-items:center;width:22px;height:22px;border-radius:50%;color:#fff;font:800 9px/1 var(--f-display);margin-right:5px;vertical-align:middle}
.resume-public a{color:var(--ice)}.resume-public a.eq{display:inline-flex;align-items:center;white-space:nowrap;color:inherit;text-decoration:none}
.resume-public th{font-style:normal}.resume-public .liste{list-style:none;margin:0;padding:0}
.resume-public .liste li{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--line)}
.resume-public .liste li:last-child{border-bottom:0}.resume-public .liste b{font:800 18px/1 var(--f-display);white-space:nowrap}</style>"""
    # Préfixe rp- : la page de l'application a déjà ses propres .eq, .liste, .carte, etc.
    for c in ("eq", "pas", "liste", "carte", "barre", "note", "p", "n", "tbl", "duo"):
        resume = resume.replace(f'class="{c}"', f'class="rp-{c}"').replace(f'class="{c} ', f'class="rp-{c} ')
        style = re.sub(rf"\.resume-public (a)?\.{c}\b", lambda m: f".resume-public {m.group(1) or ''}.rp-{c}", style)
    if "<!-- public:resume -->" in src:
        src = src.replace("<!-- public:resume -->", style + resume, 1)
    return src


# ---------------------------------------------------------------------------------
# Construction complète
# ---------------------------------------------------------------------------------
def construire_fr(pub, stats, mem, dest):
    """Écrit les pages françaises dans dest (le dossier fr/ du site). Retourne la liste des chemins écrits."""
    slugs = liens_joueurs(mem)
    pages = {}
    pages["index.html"] = page_app(pub, mem)
    c, h = page_trophees(pub, slugs, mem)
    pages[c + "index.html"] = h
    for fn in (page_equipes, page_coupe, page_apropos):
        c, h = fn(pub)
        pages[c + "index.html"] = h
    c, h = page_bilan(pub, stats)
    pages[c + "index.html"] = h
    for t in TROPHEES:
        c, h = page_trophee(t, pub, slugs, mem)
        pages[c + "index.html"] = h
    for t in TROPHEES_EQ:
        c, h = page_trophee_eq(t, pub)
        pages[c + "index.html"] = h
    for t in EQUIPES:
        c, h = page_equipe(t, pub, mem, slugs)
        pages[c + "index.html"] = h
    for pid, f in mem.items():
        if f.get("slug"):
            c, h = page_joueur(pid, f, pub, slugs)
            pages[c + "index.html"] = h
    for chemin, contenu in pages.items():
        p = Path(dest) / chemin
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(contenu, encoding="utf-8")
    return sorted(pages)
