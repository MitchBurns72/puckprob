"""Site public PuckProb (puckprob.ca) : construit docs/public/ à chaque calcul.

Pourquoi un dossier complet au lieu d'une seule page :
  - Google lit mal une page bâtie en JavaScript. Chaque page ici contient déjà son texte
    (noms, équipes, %) dans le HTML : c'est ça qui se fait indexer et trouver.
  - Une page par joueur, par équipe, par trophée = des centaines de portes d'entrée
    (« probabilité Suzuki but ce soir », « favori trophée Hart »).
  - Le repo puckprob ne fait que copier ce dossier (miroir.py) : toute la logique reste ici,
    dans Tirs-nhl, et se met à jour avec le zip habituel.

Règle d'or : seulement des probabilités. Aucune cote, aucun bet, aucun bookmaker, aucune
photo ni logo de la LNH (pastilles maison aux couleurs des équipes).

Les liens sont tous RELATIFS (../../) : le site marche autant sur puckprob.ca que sur
mitchburns72.github.io/puckprob/ en attendant le domaine. Seuls l'adresse canonique et le
sitemap sont absolus (Google l'exige), d'où DOMAINE.
"""
import hashlib
import html
import json
import re
import shutil
import unicodedata
from datetime import date
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
DOCS = RACINE / "docs"
DIR_SITE = DOCS / "public"
# Mémoire cumulative des joueurs : un joueur vu une fois garde sa page (sinon Google
# tomberait sur des 404 les soirs où il ne joue pas). Commitée par le workflow avec data/.
MEMOIRE = RACINE / "data" / "site" / "joueurs.json"
DOMAINE = "https://puckprob.ca"
NOM_SITE = "PuckProb"
# Fichiers statiques copiés tels quels depuis docs/
ACTIFS = ("logo.png", "favicon-64.png", "icone-180.png", "icone-512.png", "og.png")

# ---------------------------------------------------------------------------------
# Libellés (mêmes que la page)
# ---------------------------------------------------------------------------------
# Site public en anglais (décision de Mitch, nov. 2026) : tous les libellés affichés sont en anglais
MARCHES = [("tirs1", "1+ shots"), ("tirs", "2+ shots"), ("tirs3", "3+ shots"), ("tirs4", "4+ shots"),
           ("buts", "Goal"), ("buts2", "2+ goals"), ("buts3", "3+ goals"),
           ("passes", "Assist"), ("passes2", "2+ assists"), ("pts1", "1+ point"), ("pts2", "2+ points")]
NOM_MARCHE = dict(MARCHES) | {"victoire": "Win", "total55": "Over 5.5 goals in the game",
                              "total65": "Over 6.5 goals in the game"}
EQUIPES = {"ANA": "Anaheim", "BOS": "Boston", "BUF": "Buffalo", "CGY": "Calgary", "CAR": "Carolina",
           "CHI": "Chicago", "COL": "Colorado", "CBJ": "Columbus", "DAL": "Dallas", "DET": "Detroit",
           "EDM": "Edmonton", "FLA": "Florida", "LAK": "Los Angeles", "MIN": "Minnesota", "MTL": "Montreal",
           "NSH": "Nashville", "NJD": "New Jersey", "NYI": "NY Islanders", "NYR": "NY Rangers",
           "OTT": "Ottawa", "PHI": "Philadelphia", "PIT": "Pittsburgh", "SJS": "San Jose", "SEA": "Seattle",
           "STL": "St. Louis", "TBL": "Tampa Bay", "TOR": "Toronto", "UTA": "Utah", "VAN": "Vancouver",
           "VGK": "Vegas", "WSH": "Washington", "WPG": "Winnipeg"}
COULEUR = {"ANA": "#F47A38", "BOS": "#FFB81C", "BUF": "#003087", "CGY": "#C8102E", "CAR": "#CE1126",
           "CHI": "#CF0A2C", "COL": "#6F263D", "CBJ": "#002654", "DAL": "#006847", "DET": "#CE1126",
           "EDM": "#FF4C00", "FLA": "#C8102E", "LAK": "#A2AAAD", "MIN": "#154734", "MTL": "#AF1E2D",
           "NSH": "#FFB81C", "NJD": "#CE1126", "NYI": "#00539B", "NYR": "#0038A8", "OTT": "#C52032",
           "PHI": "#F74902", "PIT": "#FCB514", "SJS": "#006D75", "SEA": "#68A2B9", "STL": "#002F87",
           "TBL": "#002868", "TOR": "#00205B", "UTA": "#6CACE4", "VAN": "#00205B", "VGK": "#B4975A",
           "WSH": "#C8102E", "WPG": "#004C97"}
TROPHEES = {
    "art": ("Art Ross Trophy", "most points in the regular season", "points"),
    "rocket": ("Maurice \"Rocket\" Richard Trophy", "most goals in the regular season", "goals"),
    "hart": ("Hart Trophy", "the player most valuable to his team, voted by the writers", "points"),
    "lindsay": ("Ted Lindsay Award", "the best player, voted by the players themselves", "points"),
    "norris": ("Norris Trophy", "the best defenseman", "points"),
    "vezina": ("Vezina Trophy", "the best goaltender", "wins"),
    "calder": ("Calder Trophy", "the best rookie", "points"),
    "selke": ("Selke Trophy", "the best defensive forward", "points"),
    "byng": ("Lady Byng Trophy", "sportsmanship combined with skill", "points"),
}
TROPHEES_EQ = {
    "presidents": ("Presidents' Trophy", "the best regular-season record"),
    "jennings": ("William M. Jennings Trophy", "the goalies of the team that allows the fewest goals"),
    "adams": ("Jack Adams Award", "coach of the year (we rank the team; its coach is the candidate)"),
}
MOIS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
        "November", "December"]
JOURS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
# Chemins d'URL du site (en anglais)
P_JOUEURS, P_EQUIPES, P_TROPHEES, P_COUPE, P_BILAN, P_APROPOS = "players/", "teams/", "trophies/", "stanley-cup/", "track-record/", "about/"
P_CONF = "privacy/"
# Même page en français (puckprob.ca/fr/…) : pour le bouton FR | EN et les balises hreflang
VERS_FR = {"players/": "joueurs/", "teams/": "equipes/", "trophies/": "trophees/", "stanley-cup/": "coupe-stanley/",
           "track-record/": "bilan/", "about/": "a-propos/", "privacy/": "confidentialite/"}


def chemin_fr(chemin):
    for en, fr in VERS_FR.items():
        if chemin.startswith(en):
            return fr + chemin[len(en):]
    return chemin

e = html.escape  # tout texte qui vient des données passe par là

# Courriel du site (renvoyé vers le Gmail de Mitch par Namecheap) et numéro AdSense (vide = pas de pub)
COURRIEL = "contact@puckprob.ca"
MAJ_POLITIQUE = "2026-11-01"


def adsense_client():
    """Numéro AdSense lu dans config.json (« adsense_client » : "ca-pub-…"). Vide = aucune pub, aucune bannière."""
    try:
        return str(json.loads((RACINE / "config.json").read_text(encoding="utf-8")).get("adsense_client") or "").strip()
    except (OSError, ValueError):
        return ""



def date_fr(d, jour_sem=False):
    try:
        x = date.fromisoformat(str(d)[:10])
    except ValueError:
        return str(d or "")
    # Format anglais : « Sunday, November 1, 2026 »
    return (f"{JOURS[x.weekday()]}, " if jour_sem else "") + f"{MOIS[x.month - 1]} {x.day}, {x.year}"


def pct(p, dec=None):
    """0.4567 -> « 46% » ; sous 10 %, une décimale (point décimal, site en anglais)."""
    if p is None:
        return "–"
    x = p * 100
    if x >= 99.5:
        return "99+%"
    if x < 0.1:
        return "<0.1%"
    d = dec if dec is not None else (1 if x < 10 else 0)
    return f"{x:.{d}f}%"


def mille(n):
    """12345 -> « 12,345 » (virgule des milliers, à l'anglaise)."""
    try:
        return f"{int(n):,}"
    except (TypeError, ValueError):
        return "–"


def slugifier(nom):
    s = unicodedata.normalize("NFKD", str(nom)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-") or "player"


def saison_txt(s):
    s = str(s or "")
    return f"{s[:4]}-{s[4:]}" if len(s) == 8 else s


# ---------------------------------------------------------------------------------
# Gabarit commun : LE MÊME LOOK QUE L'APPLICATION
# ---------------------------------------------------------------------------------
# Le CSS des pages texte = le CSS de l'application (copié de docs/index.html à chaque calcul)
# + quelques règles en plus. Même en-tête, même menu, mêmes listes : un seul site.
CSS_EXTRA = """
/* --- Pages texte du site public (en plus du style de l'application) --- */
main{display:block}
.cp-tete h1{font:800 30px/1 var(--f-display);text-transform:uppercase;color:#fff;margin:0;letter-spacing:.02em;position:relative;z-index:1}
.cp-tete .eq-t{display:flex;align-items:center;gap:10px}
.cp-tete .eq-t img{width:44px;height:44px}
.tr .rgn{font:italic 800 18px/1 var(--f-display);color:var(--muted);text-align:center}
.tr .nm{font:800 19px/1.05 var(--f-display);text-transform:uppercase;min-width:0}
.tr .nm small{display:block;font:500 12px var(--f-body);color:var(--muted);text-transform:none;margin-top:3px}
.tr .pc{font:italic 800 30px/.9 var(--f-display);text-align:right}
.tr .pc small{font-size:15px}
.tr a,.cp a{color:inherit;text-decoration:none}
.tr a:hover,.cp a:hover{text-decoration:underline;text-decoration-color:var(--goal);text-underline-offset:3px}
.cp .pck{display:block;font:600 11px var(--f-body);color:var(--muted);font-style:normal;margin-top:3px}
.pl{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:3px 10px;align-items:center;padding:10px 12px;border-top:1px solid var(--line)}
.pl:first-child{border-top:0}
.pl .lib{font:700 15px/1.1 var(--f-body)}
.pl .lib small{display:block;font-weight:500;font-size:11.5px;color:var(--muted);margin-top:2px}
.pl .pc{font:italic 800 26px/.9 var(--f-display);text-align:right}
.pl .pc small{font-size:13px}
.pl .barre{grid-column:1 / 3;height:7px;background:var(--chip);clip-path:var(--biais)}
.pl .barre i{display:block;height:100%;background:linear-gradient(90deg,var(--eq,var(--ice)),color-mix(in srgb,var(--eq,var(--ice)) 60%,var(--led)))}
.bloc{margin:0 0 14px}
.bloc > h2{margin:18px 0 8px}
.chiffres{display:flex;flex-wrap:wrap;gap:10px 22px}
.chiffres div{min-width:64px}
.chiffres b{display:block;font:italic 800 28px/1 var(--f-display)}
.chiffres span{font-size:11.5px;color:var(--muted)}
.fiche-tete{display:flex;align-items:center;gap:14px}
.fiche-tete .ph{width:64px;height:64px;border-radius:50%;overflow:hidden;flex:none;box-shadow:0 0 0 3px var(--eq)}
.fiche-tete .rno{font-size:26px}
.grille{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}
.grille a{display:flex;align-items:center;gap:8px;background:var(--surface);border:1px solid var(--line);border-radius:6px;
  padding:9px 10px;text-decoration:none;color:var(--ink);font:700 15px/1.1 var(--f-body);box-shadow:var(--ombre)}
.grille a img{width:26px;height:26px;flex:none}
.texte p{margin:8px 0;max-width:68ch;line-height:1.55}
.texte h2{margin:22px 0 6px}
.lien-plus{display:inline-block;margin:10px 0 4px;font:italic 800 16px/1 var(--f-display);text-transform:uppercase;letter-spacing:.03em;
  color:#fff;background:var(--goal);padding:10px 22px 10px 14px;clip-path:var(--biais);text-decoration:none}
.pied{margin:28px 0 0;padding-top:14px;border-top:1px solid var(--line)}
.pied nav{display:flex;flex-wrap:wrap;gap:4px 14px;margin-top:8px}
.pied nav a{color:var(--ice);font-size:12.5px}
"""

# Menu du site : le même dans l'application (mode public) et dans chaque page texte
MENU = [("", "Tonight"), ("trophies/", "Trophies"), ("stanley-cup/", "Cup"),
        ("teams/", "Teams"), ("track-record/", "Track record"), ("about/", "About")]


def menu_html(r, actif):
    liens = "".join(f'<a href="{r}{c}"{" aria-current=\"page\"" if c == actif else ""}>{n}</a>' for c, n in MENU)
    return f'<nav class="menu" aria-label="Site menu">{liens}</nav>'


def pastille_src(t):
    """Même pastille que l'application (SVG en data URI) : rond à la couleur de l'équipe + abréviation."""
    c = COULEUR.get(t, "#6B7C8C")
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="46" fill="{c}" '
           f'stroke="#fff" stroke-width="6"/><text x="50" y="61" font-size="31" font-family="Arial Narrow,Arial,sans-serif" '
           f'font-weight="700" fill="#fff" text-anchor="middle">{e(t or "")}</text></svg>')
    from urllib.parse import quote
    return "data:image/svg+xml," + quote(svg)


def pastille(t, taille=26):
    return f'<img src="{pastille_src(t)}" alt="" width="{taille}" height="{taille}" style="vertical-align:middle">'


def eq_html(t, r, nom_long=False):
    """Équipe cliquable vers sa page (pastille + nom)."""
    if t not in EQUIPES:
        return e(t or "")
    return f'<a class="eq" href="{r}{P_EQUIPES}{t.lower()}/">{pastille(t, 22)} {e(EQUIPES[t] if nom_long else t)}</a>'


def barre(p, mx=1.0):
    w = 0 if not p or not mx else min(100, p / mx * 100)
    return f'<span class="barre"><i style="width:{w:.1f}%"></i></span>'


def pc_gros(p):
    """Le gros % de l'application : « 40<small>%</small> », 99+, <0,1, une décimale sous 10 %."""
    if p is None:
        return "–"
    x = p * 100
    t = "99+" if x >= 99.5 else "<0.1" if x < 0.1 else (f"{x:.1f}" if x < 10 else f"{x:.0f}")
    return f"{t}<small>%</small>"


def suffixe(n):
    """1 -> st, 2 -> nd, 3 -> rd, 4 -> th, 11-13 -> th."""
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ""
    return "th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")


def initiales(nom):
    return "".join(w[0] for w in str(nom or "").split()[:2]).upper()


def rond_no(no, nom):
    return f'<span class="rno">{e(str(no)) if no not in (None, "") else e(initiales(nom))}</span>'


def tete(titre, texte="", h1=True):
    """Bandeau marine de l'application (comme « Coupe Stanley » dans l'onglet Trophées)."""
    t = f"<h1>{titre}</h1>" if h1 else f"<h2>{titre}</h2>"
    return f'<div class="cp-tete">{t}{f"<p>{texte}</p>" if texte else ""}</div>'


def page(chemin, titre, desc, corps, actif=None, jsonld=None, maj=None):
    """Enveloppe HTML complète, même en-tête et même menu que l'application."""
    prof = chemin.count("/")
    r = "../" * prof
    ld = f'<script type="application/ld+json">{json.dumps(jsonld, ensure_ascii=False)}</script>\n' if jsonld else ""
    return f"""<!doctype html>
<html lang="en-CA">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{e(titre)}</title>
<meta name="description" content="{e(desc)}">
<link rel="canonical" href="{DOMAINE}/{chemin}">
<link rel="alternate" hreflang="en" href="{DOMAINE}/{chemin}">
<link rel="alternate" hreflang="fr" href="{DOMAINE}/fr/{chemin_fr(chemin)}">
<link rel="alternate" hreflang="x-default" href="{DOMAINE}/{chemin}">
<meta name="theme-color" content="#0A2342">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{NOM_SITE}">
<meta property="og:locale" content="en_CA">
<meta property="og:title" content="{e(titre)}">
<meta property="og:description" content="{e(desc)}">
<meta property="og:url" content="{DOMAINE}/{chemin}">
<meta property="og:image" content="{DOMAINE}/og.png">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" type="image/png" href="{r}favicon-64.png">
<link rel="apple-touch-icon" href="{r}icone-180.png">
<link rel="stylesheet" href="{r}fonts/fonts.css">
<link rel="stylesheet" href="{r}site.css">
<script src="{r}pub.js" data-client="{e(adsense_client())}" defer></script>
{ld}</head>
<body>
<div class="wrap">
<header class="bug">
  <div class="bug-t">
    <a href="{r}" aria-label="{NOM_SITE}, tonight's games"><img class="logo-site" src="{r}logo.png" alt="{NOM_SITE}" width="900" height="150"></a>
    <div class="maj">{e(maj or "")}</div>
  </div>
  <a class="lang" href="{r}fr/{chemin_fr(chemin)}" hreflang="fr" lang="fr" aria-label="Version française">FR</a>
</header>
{menu_html(r, actif)}
<main>
{corps}
</main>
<footer class="pied">
<b>{NOM_SITE}</b> computes probabilities from public NHL data, advanced stats from
<a href="https://moneypuck.com" rel="noopener">MoneyPuck.com</a> and lineups from
<a href="https://www.dailyfaceoff.com" rel="noopener">DailyFaceoff</a>. Independent site, not affiliated with the NHL or its teams.
A probability is not a certainty: hockey is still hockey.
· <a href="{r}{P_CONF}">Privacy</a> · <a href="mailto:{COURRIEL}">{COURRIEL}</a>
{menu_html(r, actif).replace('class="menu"', 'class="menu-pied"')}
</footer>
</div>
</body>
</html>
"""


# ---------------------------------------------------------------------------------
# Lecture des données publiques
# ---------------------------------------------------------------------------------
def probs_joueur(j, principale):
    """{marché: p} de la prédiction principale, et {marché: p} ajusté à l'alignement du soir."""
    P = (j.get("preds") or {})
    base = P.get(principale) or P.get("combo") or {}
    soir = P.get("soir") or {}
    f = lambda d: {m: v["p"] for m, v in d.items() if isinstance(v, dict) and v.get("p") is not None}
    return f(base), f(soir)


def preds_match(g, principale):
    P = g.get("preds") or {}
    return P.get(principale) or P.get("combo") or {}


def candidats_trophees(pub):
    """{pid: {trophée: (rang, p)}} + infos de base des candidats (nom, équipe, position)."""
    out, infos = {}, {}
    for t, B in ((pub.get("trophees") or {}).get("trophees") or {}).items():
        for i, x in enumerate((B or {}).get("top") or []):
            pid = str(x.get("id"))
            out.setdefault(pid, {})[t] = (i + 1, x.get("p"))
            infos[pid] = x
    return out, infos


# ---------------------------------------------------------------------------------
# Mémoire des joueurs (slug stable + dernier calcul connu)
# ---------------------------------------------------------------------------------
def maj_memoire(pub, mem):
    principale = pub.get("principale")
    jour = pub.get("date")
    pris = {v["slug"]: pid for pid, v in mem.items() if v.get("slug")}

    def fiche(pid, nom):
        f = mem.setdefault(pid, {})
        if not f.get("slug"):
            s = slugifier(nom)
            if s in pris and pris[s] != pid:          # deux Sebastian Aho : le 2e prend son numéro LNH
                s = f"{s}-{pid}"
            f["slug"] = s
            pris[s] = pid
        return f

    for j in pub.get("joueurs") or []:
        pid = str(j.get("pid"))
        f = fiche(pid, j.get("name"))
        base, soir = probs_joueur(j, principale)
        f.update({"nom": j.get("name"), "eq": j.get("team"), "pos": j.get("pos"), "no": j.get("no"),
                  "saison": j.get("saison"), "vu": jour})
        if base:
            f["dernier"] = {"date": jour, "opp": j.get("opp"), "home": j.get("home"), "gid": j.get("gameId"),
                            "p": {m: round(p, 4) for m, p in base.items()},
                            "soir": {m: round(p, 4) for m, p in soir.items()},
                            "l10": {"tirs": j.get("l10_shots"), "buts": j.get("l10_goals"), "passes": j.get("l10_assists")}}
    cands, infos = candidats_trophees(pub)
    for f in mem.values():
        f.pop("troph", None)                         # recalculé à neuf : un joueur sorti du top 10 n'y reste pas
    for pid, tr in cands.items():
        x = infos[pid]
        f = fiche(pid, x.get("nom"))
        f.setdefault("nom", x.get("nom"))
        f.setdefault("pos", x.get("pos"))
        f["eq"] = x.get("eq") or f.get("eq")
        f["troph"] = {t: [r, p] for t, (r, p) in tr.items()}
        f.setdefault("vu", jour)
    return mem


# ---------------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------------
def liens_joueurs(mem):
    return {pid: v["slug"] for pid, v in mem.items() if v.get("slug")}


def nom_joueur(nom, pid, slugs, r):
    s = slugs.get(str(pid))
    return f'<a href="{r}{P_JOUEURS}{s}/">{e(nom or "")}</a>' if s else e(nom or "")


def section_matchs(pub, r):
    principale = pub.get("principale")
    lignes = []
    for g in pub.get("games") or []:
        c = preds_match(g, principale)
        ph = c.get("p_home")
        if ph is None:
            continue
        tot = c.get("total")
        lignes.append(f"""<tr><td>{eq_html(g.get("away"), r)} <span class="note">@</span> {eq_html(g.get("home"), r)}</td>
<td class="n"><span class="p">{pct(1 - ph)}</span><br><span class="note">{e(g.get("away") or "")}</span></td>
<td class="n"><span class="p">{pct(ph)}</span><br><span class="note">{e(g.get("home") or "")}</span></td>
<td class="n">{f"{tot:.1f}" if tot else "–"}</td></tr>""")
    if not lignes:
        return "<p>No games scheduled for this date.</p>"
    return f"""<div class="carte tbl"><table><thead><tr><th>Game</th><th class="n">Away</th><th class="n">Home</th>
<th class="n">Expected goals</th></tr></thead><tbody>{"".join(lignes)}</tbody></table></div>
<p class="note">Probability of winning the game (overtime and shootout included).</p>"""


def top_marche(pub, m, n, slugs, r):
    principale = pub.get("principale")
    rows = []
    for j in pub.get("joueurs") or []:
        p = probs_joueur(j, principale)[0].get(m)
        if p is not None:
            rows.append((p, j))
    rows.sort(key=lambda x: -x[0])
    rows = rows[:n]
    if not rows:
        return ""
    mx = rows[0][0]
    corps = "".join(f"""<tr><td>{nom_joueur(j.get("name"), j.get("pid"), slugs, r)}<br><span class="note">{e(j.get("team") or "")} {"vs" if j.get("home") else "@"} {e(j.get("opp") or "")}</span></td>
<td class="n"><span class="p">{pct(p)}</span>{barre(p, mx)}</td></tr>""" for p, j in rows)
    return f"""<div class="carte tbl"><h3>{e(NOM_MARCHE[m])}</h3><table><tbody>{corps}</tbody></table></div>"""


def page_accueil_resume(pub, mem, r=""):
    """Bloc texte inséré dans la page de l'application (index.html) : ce que Google lit."""
    slugs = liens_joueurs(mem)
    jour = pub.get("date")
    favs = ""
    eqs = ((pub.get("coupe") or {}).get("equipes") or [])[:5]
    if eqs:
        favs = ('<div class="carte"><h3>Stanley Cup favorites</h3><ul class="liste">' + "".join(
            f'<li>{eq_html(x["t"], r, True)}<b>{pct(x.get("p_coupe"))}</b></li>' for x in eqs)
            + f'</ul><p><a href="{r}{P_COUPE}">All 32 teams</a></p></div>')
    tr = []
    for t, (nom, _, _) in TROPHEES.items():
        top = ((((pub.get("trophees") or {}).get("trophees") or {}).get(t) or {}).get("top") or [])
        if top:
            x = top[0]
            tr.append(f'<li><span><a href="{r}{P_TROPHEES}{t}/">{e(nom.replace(" Trophy", "").replace(" Award", ""))}</a> · '
                      f'{nom_joueur(x.get("nom"), x.get("id"), slugs, r)}</span><b>{pct(x.get("p"))}</b></li>')
    tr_html = f'<div class="carte"><h3>Award races: the favorites</h3><ul class="liste">{"".join(tr)}</ul></div>' if tr else ""
    return f"""<section class="resume-public" aria-labelledby="resume-titre">
<h2 id="resume-titre">At a glance: {e(date_fr(jour, True))}</h2>
{section_matchs(pub, r)}
<div class="duo">{top_marche(pub, "buts", 10, slugs, r)}{top_marche(pub, "pts1", 10, slugs, r)}{top_marche(pub, "tirs3", 10, slugs, r)}</div>
{favs}{tr_html}
<p><a href="{r}{P_TROPHEES}">All trophies</a> · <a href="{r}{P_EQUIPES}">All 32 teams</a> · <a href="{r}{P_BILAN}">Our track record: are our percentages right?</a> · <a href="{r}{P_APROPOS}">How it works</a></p>
</section>"""


def maj_txt(pub):
    return f"Updated {date_fr(pub.get('date'))}"


def ligne_joueur(rang, nom_html, no, nom, eq, sous, p, mx, stat=""):
    """Une ligne de joueur au style de l'onglet Trophées de l'application."""
    return f"""<div class="tr" style="--eq:{COULEUR.get(eq, '#6B7C8C')}">
<span class="rgn">{rang}</span><span class="ph">{rond_no(no, nom)}</span>
<span class="nm">{nom_html}<small>{sous}</small></span>
<span class="pc">{pc_gros(p)}</span>{barre(p, mx)}{f'<span class="stat">{stat}</span>' if stat else ""}</div>"""


def ligne_equipe(rang, t, r, sous, p, mx, etiquette=""):
    """Une ligne d'équipe au style de la Coupe dans l'application."""
    nom = f'<a href="{r}equipes/{t.lower()}/">{e(EQUIPES.get(t, t))}</a>' if t in EQUIPES else e(t or "")
    return f"""<div class="cp" style="--eq:{COULEUR.get(t, '#6B7C8C')}">
<span class="rgn">{rang}</span><img class="lg" src="{pastille_src(t)}" alt="">
<span class="nm">{nom}<small>{sous}</small></span>
<span class="pc">{pc_gros(p)}{f'<span class="pck">{etiquette}</span>' if etiquette else ""}</span>{barre(p, mx)}</div>"""


def ligne_prob(lib, p, sous=""):
    return f"""<div class="pl"><span class="lib">{e(lib)}{f"<small>{sous}</small>" if sous else ""}</span>
<span class="pc">{pc_gros(p)}</span>{barre(p)}</div>"""


def page_joueur(pid, f, pub, slugs):
    chemin = f"{P_JOUEURS}{f['slug']}/"
    r = "../../"
    nom, eq = f.get("nom") or "Joueur", f.get("eq")
    pos = {"D": "Defenseman", "G": "Goaltender"}.get(f.get("pos"), "Forward")
    jour = pub.get("date")
    d = f.get("dernier")
    s = f.get("saison") or {}
    coul = COULEUR.get(eq, "#6B7C8C")
    no = f.get("no")
    blocs = []
    if d and d.get("p"):
        ce_soir = d.get("date") == jour
        lieu = "vs" if d.get("home") else "at"
        adv = EQUIPES.get(d.get("opp"), d.get("opp"))
        titre = f"Tonight {lieu} {adv}" if ce_soir else f"Last game computed: {date_fr(d.get('date'))}, {lieu} {adv}"
        soir = d.get("soir") or {}
        lignes = "".join(ligne_prob(lib, d["p"][m], f"with tonight's lineup: {pct(soir[m])}" if soir.get(m) is not None else "")
                         for m, lib in MARCHES if m in d["p"])
        l10 = d.get("l10") or {}
        forme = ""
        if l10.get("tirs"):
            forme = (f'<p class="aide" style="margin:8px 2px 0">Last 10 games — shots: {" · ".join(map(str, l10["tirs"]))} · '
                     f'goals: {sum(l10.get("buts") or [])} · assists: {sum(l10.get("passes") or [])}</p>')
        rien = "" if ce_soir else '<p class="aide" style="margin:8px 2px 0">No game for him tonight: this page updates at his next game.</p>'
        blocs.append(f'<section class="bloc"><h2>{e(titre)}</h2><div class="cp-liste" style="--eq:{coul}">{lignes}</div>{forme}{rien}</section>')
    elif f.get("pos") == "G":
        blocs.append('<p class="aide">Goaltenders have no shot or point probabilities: we track them in the Vezina race.</p>')
    tr = f.get("troph") or {}
    if tr:
        lignes = "".join(
            f'<div class="pl" style="--eq:{coul}"><span class="lib"><a href="{r}{P_TROPHEES}{t}/" style="color:inherit">{e((TROPHEES.get(t) or (t,))[0])}</a>'
            f'<small>{rg}{suffixe(rg)} in the race</small></span><span class="pc">{pc_gros(p)}</span>{barre(p)}</div>'
            for t, (rg, p) in sorted(tr.items(), key=lambda kv: -(kv[1][1] or 0)))
        blocs.append(f'<section class="bloc"><h2>Award races</h2><div class="cp-liste">{lignes}</div></section>')
    if s.get("pj") is not None:
        pr = s.get("proj") or {}
        toi = f'<div><b>{s["toi"]:.1f}</b><span>min/game</span></div>' if s.get("toi") else ""
        blocs.append(f"""<section class="bloc"><h2>This season</h2><div class="card"><div class="chiffres">
<div><b>{s.get("pj")}</b><span>games</span></div><div><b>{s.get("b", 0)}</b><span>goals</span></div>
<div><b>{s.get("a", 0)}</b><span>assists</span></div><div><b>{s.get("pts", 0)}</b><span>points</span></div>
<div><b>{s.get("tirs", 0)}</b><span>shots</span></div>{toi}</div>
{f'<p class="aide">End-of-season projection: {pr.get("b")} goals, {pr.get("a")} assists, {pr.get("pts")} points, {pr.get("tirs")} shots.</p>' if pr else ""}</div></section>""")
    num = f" · #{e(str(no))}" if no not in (None, "") else ""
    p_but = d["p"].get("buts") if d and d.get("p") and d.get("date") == jour else None
    desc = (f"{nom} ({EQUIPES.get(eq, eq)}): {pct(p_but)} chance to score tonight, plus his shot, assist and point probabilities and his award odds. Updated daily."
            if p_but is not None else
            f"{nom} ({EQUIPES.get(eq, eq)}): game-by-game goal, shot, assist and point probabilities, stats and award odds.")
    corps = f"""<div class="cp-tete"><div class="fiche-tete" style="--eq:{coul}"><span class="ph">{rond_no(no, nom)}</span>
<div><h1>{e(nom)}</h1><p><a href="{r}{P_EQUIPES}{(eq or '').lower()}/" style="color:inherit">{e(EQUIPES.get(eq, eq or ""))}</a> · {pos}{num}</p></div></div></div>
{"".join(blocs) or '<div class="card"><div class="vide">No data yet.</div></div>'}
<a class="lien-plus" href="{r}">All of tonight's games</a>"""
    ld = {"@context": "https://schema.org", "@type": "ProfilePage",
          "mainEntity": {"@type": "Person", "name": nom, "affiliation": {"@type": "SportsTeam", "name": EQUIPES.get(eq, eq or "")}}}
    return chemin, page(chemin, f"{nom}: goal, point and shot probabilities | {NOM_SITE}", desc, corps, jsonld=ld, maj=maj_txt(pub))


def page_equipe(t, pub, mem, slugs):
    chemin = f"{P_EQUIPES}{t.lower()}/"
    r = "../../"
    nom = EQUIPES[t]
    coul = COULEUR.get(t, "#6B7C8C")
    blocs = []
    C = pub.get("coupe") or {}
    eqs = C.get("equipes") or []
    x = next((v for v in eqs if v.get("t") == t), None)
    if x:
        rang = eqs.index(x) + 1
        etapes = [("p_series", "Makes the playoffs"), ("p_r2", "Wins a round"), ("p_finale_conf", "Conference final"),
                  ("p_finale", "Stanley Cup Final"), ("p_coupe", "Wins the Stanley Cup"), ("p_presidents", "Presidents' Trophy")]
        lignes = "".join(ligne_prob(lib, x.get(k)) for k, lib in etapes if x.get(k) is not None)
        blocs.append(f"""<section class="bloc"><div class="card"><div class="chiffres"><div><b>{x.get("pts", "–")}</b><span>points</span></div>
<div><b>{x.get("pj", "–")}</b><span>games played</span></div><div><b>{round(x["proj"]) if x.get("proj") is not None else "–"}</b><span>projected points</span></div>
<div><b>{rang}<sup>{suffixe(rang)}</sup></b><span>Cup favorite</span></div></div></div></section>
<section class="bloc"><h2>Its odds</h2><p class="aide" style="margin:0 2px 8px">Over {mille(C.get("n_sim", 0))} simulated season endings.</p>
<div class="cp-liste" style="--eq:{coul}">{lignes}</div></section>""")
    principale = pub.get("principale")
    for g in pub.get("games") or []:
        if t in (g.get("home"), g.get("away")):
            c = preds_match(g, principale)
            if c.get("p_home") is None:
                continue
            dom = g.get("home") == t
            adv = g.get("away") if dom else g.get("home")
            p = c["p_home"] if dom else 1 - c["p_home"]
            tot = f'{c["total"]:.1f}' if c.get("total") else None
            blocs.append(f"""<section class="bloc"><h2>Tonight {"vs" if dom else "at"} {e(EQUIPES.get(adv, adv))}</h2>
<div class="cp-liste" style="--eq:{coul}">{ligne_prob("Wins the game", p, "overtime and shootout included")}</div>
{f'<p class="aide" style="margin:8px 2px 0">Expected goals in the game: {tot}</p>' if tot else ""}</section>""")
    jou = sorted(((pid, f) for pid, f in mem.items() if f.get("eq") == t and f.get("slug")),
                 key=lambda kv: -((kv[1].get("saison") or {}).get("pts") or 0))
    if jou:
        liens = "".join(f'<a href="{r}{P_JOUEURS}{f["slug"]}/" style="--eq:{coul}"><span class="ph" style="width:26px;height:26px;border-radius:50%;overflow:hidden;flex:none">{rond_no(f.get("no"), f.get("nom"))}</span>{e(f.get("nom") or "")}</a>' for _, f in jou)
        blocs.append(f'<section class="bloc"><h2>Players</h2><div class="grille">{liens}</div></section>')
    desc = f"{nom}: odds to make the playoffs and win the Stanley Cup, tonight's win probability and its players' probabilities. Updated daily."
    corps = f"""<div class="cp-tete"><div class="eq-t"><img src="{pastille_src(t)}" alt=""><h1>{e(nom)}</h1></div></div>
{"".join(blocs) or '<div class="card"><div class="vide">Simulations arrive with the next update.</div></div>'}"""
    return chemin, page(chemin, f"{nom}: playoff and Stanley Cup odds | {NOM_SITE}", desc, corps, actif=P_EQUIPES,
                        jsonld={"@context": "https://schema.org", "@type": "SportsTeam", "name": nom, "sport": "Hockey"}, maj=maj_txt(pub))


def page_equipes(pub):
    chemin = P_EQUIPES
    liens = "".join(f'<a href="{t.lower()}/"><img src="{pastille_src(t)}" alt="">{e(n)}</a>' for t, n in sorted(EQUIPES.items(), key=lambda kv: kv[1]))
    corps = f"""{tete("All 32 teams", "Playoff odds, Stanley Cup odds and tonight's probabilities, team by team.")}
<div class="grille">{liens}</div>"""
    return chemin, page(chemin, f"NHL teams: playoff and Stanley Cup odds | {NOM_SITE}",
                        "All 32 NHL teams: odds to make the playoffs, win the Stanley Cup and win tonight, updated daily.",
                        corps, actif=P_EQUIPES, maj=maj_txt(pub))


def page_coupe(pub):
    chemin = P_COUPE
    r = "../"
    C = pub.get("coupe") or {}
    eqs = C.get("equipes") or []
    if eqs:
        mx = max((x.get("p_coupe") or 0) for x in eqs) or 1
        lignes = "".join(ligne_equipe(i + 1, x["t"], r, f'{x.get("pts", "–")} pts in {x.get("pj", "–")} games · playoffs {pct(x.get("p_series"))}',
                                      x.get("p_coupe"), mx, "Cup") for i, x in enumerate(eqs))
        liste = f'<div class="cp-liste">{lignes}</div>'
    else:
        liste = '<div class="card"><div class="vide">Simulations arrive with the next update.</div></div>'
    n = C.get("n_sim")
    corps = f"""{tete("Who will win the Stanley Cup?",
                     f"{mille(n) if n else 'Thousands of'} season endings simulated every day from each team's strength (an Elo rating tuned on past seasons) and its remaining schedule, then the playoffs in the real format. The % = the share of simulations where the team lifts the Cup.")}
{liste}"""
    return chemin, page(chemin, f"Stanley Cup odds, team by team | {NOM_SITE}",
                        "Every NHL team's probability of making the playoffs and winning the Stanley Cup, recomputed daily by simulation.",
                        corps, actif=P_COUPE, maj=maj_txt(pub))


def stat_troph(t, x):
    p = lambda v: "–" if v is None else v
    proj = round(x["proj"]) if x.get("proj") is not None else "–"
    if t == "vezina":
        sv = f"{x['sv']:.3f}".lstrip("0") if x.get("sv") is not None else "–"
        return f"<span><b>{p(x.get('v'))}</b> wins</span><span>save % <b>{sv}</b></span><span>projected <b>{proj}</b> wins</span>"
    if t == "rocket":
        return f"<span><b>{p(x.get('b'))}</b> goals</span><span>projected <b>{proj}</b> goals</span>"
    return f"<span><b>{p(x.get('pts'))}</b> pts ({p(x.get('b'))} G, {p(x.get('a'))} A)</span><span>projected <b>{proj}</b> pts</span>"


def page_trophee(t, pub, slugs, mem):
    chemin = f"{P_TROPHEES}{t}/"
    r = "../../"
    nom, desc_t, _ = TROPHEES[t]
    B = ((pub.get("trophees") or {}).get("trophees") or {}).get(t) or {}
    top = B.get("top") or []
    vote = t not in ("art", "rocket")
    methode = ("It's a vote: we learned what voters reward from past seasons' winners, "
               "then simulate the rest of the season 10,000 times." if vote else
               "We simulate the rest of the season 10,000 times, game by game, at each player's pace.")
    if top:
        mx = top[0].get("p") or 1
        lignes = "".join(ligne_joueur(
            i + 1, nom_joueur(x.get("nom"), x.get("id"), slugs, r), (mem.get(str(x.get("id"))) or {}).get("no"), x.get("nom"), x.get("eq"),
            f'{e(x.get("eq") or "")} · {x.get("pj", "–")} games', x.get("p"), mx, stat_troph(t, x)) for i, x in enumerate(top))
        liste = f'<div class="cp-liste">{lignes}</div>'
    else:
        liste = f'<div class="card"><div class="vide">{e("Coming with the next update." if B.get("msg") else "Coming soon.")}</div></div>'
    T = [x for x in (B.get("test") or []) if x.get("gagnant")]
    test = ""
    if T:
        top3 = sum(1 for x in T if x.get("rang_stat") and x["rang_stat"] <= 3)
        s_ = "s" if len(T) > 1 else ""
        test = (f'<p class="aide" style="margin:10px 2px 0">Tested on {len(T)} past season{s_}, on the same date: '
                f'the winner was in our top 3 {top3} times out of {len(T)}.</p>')
    corps = f"""{tete(e(nom), e(desc_t[0].upper() + desc_t[1:]) + ". " + methode)}
{liste}{test}
<a class="lien-plus" href="{r}{P_TROPHEES}">Other trophies</a>"""
    favori = f" Favorite: {top[0].get('nom')} ({pct(top[0].get('p'))})." if top else ""
    return chemin, page(chemin, f"{nom}: who will win it? Odds for every candidate | {NOM_SITE}",
                        f"Odds for every {nom} candidate ({desc_t}), recomputed daily.{favori}", corps,
                        actif=P_TROPHEES, maj=maj_txt(pub))


def page_trophee_eq(t, pub):
    chemin = f"{P_TROPHEES}{t}/"
    r = "../../"
    nom, desc_t = TROPHEES_EQ[t]
    L = (((pub.get("coupe") or {}).get("trophees_equipe")) or {}).get(t) or []
    if L:
        mx = max((x.get("p") or 0) for x in L) or 1
        lignes = "".join(ligne_equipe(i + 1, x.get("t"), r, "", x.get("p"), mx) for i, x in enumerate(L[:16]))
        liste = f'<div class="cp-liste">{lignes}</div>'
    else:
        liste = '<div class="card"><div class="vide">Coming soon.</div></div>'
    corps = f"""{tete(e(nom), e(desc_t[0].upper() + desc_t[1:]) + ".")}
{liste}
<a class="lien-plus" href="{r}{P_TROPHEES}">Other trophies</a>"""
    return chemin, page(chemin, f"{nom}: odds for every team | {NOM_SITE}",
                        f"Every team's odds for the {nom} ({desc_t}), recomputed daily.", corps,
                        actif=P_TROPHEES, maj=maj_txt(pub))


def page_trophees(pub, slugs, mem):
    chemin = P_TROPHEES
    r = "../"
    blocs = []
    for t, (nom, desc_t, _) in TROPHEES.items():
        top = ((((pub.get("trophees") or {}).get("trophees") or {}).get(t) or {}).get("top") or [])[:3]
        mx = (top[0].get("p") if top else 1) or 1
        lignes = "".join(ligne_joueur(i + 1, nom_joueur(x.get("nom"), x.get("id"), slugs, r), (mem.get(str(x.get("id"))) or {}).get("no"),
                                      x.get("nom"), x.get("eq"), e(x.get("eq") or ""), x.get("p"), mx) for i, x in enumerate(top))
        blocs.append(f'<section class="bloc"><h2><a href="{t}/" style="color:inherit">{e(nom)}</a></h2><p class="aide" style="margin:0 2px 8px">{e(desc_t[0].upper() + desc_t[1:])}</p>'
                     f'{f"<div class=cp-liste>{lignes}</div>" if lignes else "<div class=card><div class=vide>Coming soon.</div></div>"}'
                     f'<a class="aide" href="{t}/" style="display:inline-block;margin:6px 2px 0">Top 10 favorites →</a></section>')
    for t, (nom, desc_t) in TROPHEES_EQ.items():
        L = ((((pub.get("coupe") or {}).get("trophees_equipe")) or {}).get(t) or [])[:3]
        mx = (L[0].get("p") if L else 1) or 1
        lignes = "".join(ligne_equipe(i + 1, x.get("t"), r, "", x.get("p"), mx) for i, x in enumerate(L))
        blocs.append(f'<section class="bloc"><h2><a href="{t}/" style="color:inherit">{e(nom)}</a></h2><p class="aide" style="margin:0 2px 8px">{e(desc_t[0].upper() + desc_t[1:])}</p>'
                     f'{f"<div class=cp-liste>{lignes}</div>" if lignes else "<div class=card><div class=vide>Coming soon.</div></div>"}'
                     f'<a class="aide" href="{t}/" style="display:inline-block;margin:6px 2px 0">Full ranking →</a></section>')
    corps = f"""{tete("NHL awards", "The favorites for every trophy, recomputed daily. Tap a trophy to see its top 10.")}
{"".join(blocs)}"""
    return chemin, page(chemin, f"NHL awards: Hart, Norris, Vezina, Calder favorites and more | {NOM_SITE}",
                        "Who will win the Hart, Art Ross, Rocket Richard, Norris, Vezina, Calder and the other NHL awards? Odds recomputed daily.",
                        corps, actif=P_TROPHEES, maj=maj_txt(pub))


def bloc_calib(nom, st):
    calib = [c for c in (st.get("calib") or []) if c.get("n")]
    if not st.get("n") or not calib:
        return ""
    brut = lambda x: "–" if x is None else f"{round(x * 100)}%"
    tranche = lambda t: t.replace("-", " to ") + "%"
    rows = "".join(f"""<tr><td>{e(tranche(c["tranche"]))}</td><td>{c["n"]}</td><td>{brut(c.get("predit"))}</td>
<td><b>{brut(c.get("reel"))}</b></td></tr>""" for c in calib)
    note = st.get("note")
    return f"""<section class="bloc"><h2>{e(nom)}</h2><div class="card">
<div class="chiffres"><div><b>{mille(st["n"])}</b><span>predictions checked</span></div>
{f'<div><b>{note:.0f}</b><span>score /100</span></div>' if note is not None else ""}
{f'<div><b>{round(st["precision"] * 100)}%</b><span>right side</span></div>' if st.get("precision") is not None else ""}</div>
<div class="tbl"><table><thead><tr><th>We said</th><th>Times</th><th>On average</th><th>It happened</th></tr></thead>
<tbody>{rows}</tbody></table></div></div></section>"""


def page_bilan(pub, stats):
    chemin = P_BILAN
    principale = pub.get("principale")
    blocs = []
    for m, st in ((stats or {}).get("matchs") or {}).items():
        blocs.append(bloc_calib(NOM_MARCHE.get(m, m), (st or {}).get(principale) or {}))
    for m, lib in MARCHES:
        st = (((stats or {}).get("joueurs") or {}).get(m) or {}).get(principale) or {}
        blocs.append(bloc_calib(lib, st))
    blocs = [b for b in blocs if b]
    retro, direct = (stats or {}).get("soirs_retro"), (stats or {}).get("soirs_direct")
    soirs = ""
    if retro is not None or direct is not None:
        soirs = (f"<p class=\"aide\">Nights counted: {direct or 0} predicted before the games, {retro or 0} replayed afterwards "
                 "using only the data available before each game (to build history from day one).</p>")
    corps = f"""{tete("Our track record", "Are our percentages right? Every prediction is checked after the game. If we say 70% a hundred times, it should happen about 70 times: the “It happened” column shows it, bucket by bucket.")}
<div class="card"><p class="aide" style="margin:0"><b>Score /100</b>: 50 = no better than giving everyone the same %, 100 = perfect (impossible).
For players, 55 to 60 is a good model; for wins, even the best public models sit around 52 to 55 — hockey is very random.
<b>Right side</b>: how often the side we favored actually happened.</p>{soirs}</div>
{"".join(blocs) or '<div class="card"><div class="vide">The track record fills up night after night.</div></div>'}"""
    return chemin, page(chemin, f"Track record: our NHL probabilities checked after every game | {NOM_SITE}",
                        "Every probability PuckProb publishes is checked after the game. Calibration and accuracy, market by market.",
                        corps, actif=P_BILAN, maj=maj_txt(pub))


def page_apropos(pub):
    chemin = P_APROPOS
    corps = f"""{tete("How it works", f"Every game night, {NOM_SITE} gives the probability that each player gets a shot, a goal, an assist or a point, each team's chance of winning, and the odds for every award and the Stanley Cup. Percentages only.")}
<div class="card texte">
<h2>Players</h2>
<p>For each player: his shot, goal and assist rates per 60 minutes (weighted toward recent games and pulled toward the average when he
has played little), his expected ice time, his power-play unit, the opponent (defense, starting goalie), home ice, back-to-backs,
his own personal tendencies and advanced stats from MoneyPuck. With tonight's lineup, we adjust his line, his power-play role and the opposing goalie.</p>
<p>Each factor pushes his chances up (+) or down (−) compared to an ordinary game: in the app, tap “Why this %” under a player to see them one by one.
Several models are compared continuously against real results; the one that predicts each category best is the one we publish.</p>
<h2>Games</h2>
<p>Each team's expected goals come from recent form, both teams' offense and defense, and the goalies.
The win probability includes overtime and the shootout.</p>
<h2>Awards and the Cup</h2>
<p>The rest of the season is simulated 10,000 times. For voted awards (Hart, Norris, Vezina, Calder, Selke, etc.), we learned what
voters reward from past winners. For the Selke, for example, reputation matters a lot.</p>
<h2>Checked every night</h2>
<p>Every probability is compared with the real result. It's all on the <a href="../{P_BILAN}">Track record</a> page.</p>
<h2>Sources</h2>
<p>Public NHL data, advanced stats from <a href="https://moneypuck.com" rel="noopener">MoneyPuck.com</a>,
lineups from <a href="https://www.dailyfaceoff.com" rel="noopener">DailyFaceoff</a>. Independent site, not affiliated with the NHL
or its teams. No official photos or logos are used.</p></div>"""
    return chemin, page(chemin, f"How PuckProb computes its NHL probabilities | {NOM_SITE}",
                        "The method behind PuckProb's probabilities: players, games, awards and the Stanley Cup.",
                        corps, actif=P_APROPOS, maj=maj_txt(pub))


def page_confidentialite(pub):
    """Politique de confidentialité (Loi 25 du Québec) : ce qu'on recueille, qui le reçoit, comment refuser."""
    chemin = P_CONF
    corps = f"""{tete("Privacy policy", "What PuckProb collects (almost nothing), who receives what, and how to say no.")}
<div class="card texte">
<h2>Who we are</h2>
<p>{NOM_SITE} (puckprob.ca) is an independent website run from Quebec, Canada. Person in charge of the protection of personal information:
the site owner, reachable at <a href="mailto:{COURRIEL}">{COURRIEL}</a>.</p>
<h2>What we collect</h2>
<p>No account, no sign-up form, no analytics. We don't ask for your name or email. If you write to us, we keep your message only as long
as needed to answer it.</p>
<h2>Who receives information when you visit</h2>
<p><b>Hosting.</b> The site is hosted by GitHub Pages (GitHub, Inc., United States), which receives your IP address and browser information
in order to deliver the pages, like any web host.</p>
<p><b>Live scores.</b> When the LIVE button is on, your browser may request game data directly from the NHL's public service (api-web.nhle.com),
which then receives your IP address.</p>
<p><b>Fonts and images.</b> Fonts are hosted on our own site; no official NHL photos or logos are loaded.</p>
<h2>Advertising (Google AdSense)</h2>
<p>To stay free, {NOM_SITE} may show ads from Google AdSense. Nothing related to ads is loaded until you click “Accept” in the banner.
If you accept, Google uses cookies and similar technologies to choose ads (possibly personalized), limit how often you see them and measure them;
this data is processed by Google outside Quebec, including in the United States. If you refuse, no ads are shown and no ad cookie is placed.
You can change your choice at any time with the “Cookie settings” link at the bottom of every page.
More information: <a href="https://policies.google.com/technologies/ads" rel="noopener">how Google uses data in ads</a>.</p>
<h2>Stored on your device</h2>
<p>A few settings are saved in your browser's storage: the LIVE button and your ad choice. They never leave your device.</p>
<h2>Your rights</h2>
<p>You can ask to access or correct personal information about you, or withdraw your consent, by writing to
<a href="mailto:{COURRIEL}">{COURRIEL}</a>.</p>
<p class="aide">Last updated: {date_fr(MAJ_POLITIQUE)}.</p></div>"""
    return chemin, page(chemin, f"Privacy policy | {NOM_SITE}", "PuckProb's privacy policy: what we collect, who receives it, and how to refuse ads and cookies.",
                        corps, maj=maj_txt(pub))


def page_404():
    corps = f"""{tete("Page not found", "This page doesn't exist (or no longer does).")}<a class="lien-plus" href="/">Back to tonight's games</a>"""
    h = page("404/", f"Page not found | {NOM_SITE}", "Page not found.", corps)
    h = h.replace(f'<link rel="canonical" href="{DOMAINE}/404/">\n', '<meta name="robots" content="noindex">\n')
    return h.replace('="../', '="/')


# ---------------------------------------------------------------------------------
# Page de l'application (index.html) : docs/index.html en mode public + texte pour Google
# ---------------------------------------------------------------------------------
def page_app(pub, mem):
    src = (DOCS / "index.html").read_text(encoding="utf-8")
    # lang="en" : l'application traduit tout son texte en anglais (dictionnaire dans docs/index.html)
    src = src.replace('<html lang="fr-CA">', '<html lang="en" data-public="1">', 1)
    titre = f"{NOM_SITE}: tonight's NHL probabilities — goals, points, shots and awards"
    desc = ("Tonight's probabilities for every NHL player (goals, assists, points, shots), every game's win odds, "
            "and the favorites for every award and the Stanley Cup. Updated daily, checked after every game.")
    tete = f"""<title>{e(titre)}</title>
<meta name="description" content="{e(desc)}">
<link rel="canonical" href="{DOMAINE}/">
<link rel="alternate" hreflang="en" href="{DOMAINE}/">
<link rel="alternate" hreflang="fr" href="{DOMAINE}/fr/">
<link rel="alternate" hreflang="x-default" href="{DOMAINE}/">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{NOM_SITE}">
<meta property="og:locale" content="en_CA">
<meta property="og:title" content="{e(titre)}">
<meta property="og:description" content="{e(desc)}">
<meta property="og:url" content="{DOMAINE}/">
<meta property="og:image" content="{DOMAINE}/og.png">
<meta name="twitter:card" content="summary_large_image">
<script type="application/ld+json">{json.dumps({"@context": "https://schema.org", "@type": "WebSite", "name": NOM_SITE, "url": DOMAINE + "/", "inLanguage": "en-CA"}, ensure_ascii=False)}</script>"""
    src = src.replace("<title>PuckProb</title>", tete, 1)
    # Polices hébergées sur le site (aucune requête chez Google avant consentement) + bannière/pub
    src = src.replace('''<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,600;0,700;0,800;1,700;1,800&family=Barlow:wght@400;500;600;700&display=swap">''', '<link rel="stylesheet" href="fonts/fonts.css">', 1)
    src = src.replace("</body>", f'<script src="pub.js" data-client="{e(adsense_client())}" defer></script>\n</body>', 1)
    src = src.replace('<meta name="robots" content="noindex">\n', "", 1)
    # Le résumé texte va juste avant la fin du contenu principal (marqueur posé dans docs/index.html)
    resume = page_accueil_resume(pub, mem)
    style = """<style>.resume-public{margin-top:28px}.resume-public h3{font:800 18px/1.1 var(--f-display);text-transform:uppercase;margin:14px 0 6px}
.resume-public table{width:100%;border-collapse:collapse;font-size:14px}.resume-public td,.resume-public th{padding:6px;border-bottom:1px solid var(--line);text-align:left}
.resume-public .n{text-align:right}.resume-public .p{font:800 18px/1 var(--f-display)}.resume-public .note{color:var(--muted);font-size:12px}
.resume-public .carte{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin:10px 0}
.resume-public .barre{display:block;height:5px;border-radius:3px;background:var(--surface2);margin-top:3px}.resume-public .barre i{display:block;height:100%;border-radius:3px;background:var(--ice)}
.resume-public .pas{display:inline-grid;place-items:center;width:22px;height:22px;border-radius:50%;color:#fff;font:800 9px/1 var(--f-display);margin-right:5px;vertical-align:middle}
.resume-public a{color:var(--ice)}.resume-public a.eq{display:inline-flex;align-items:center;white-space:nowrap;color:inherit;text-decoration:none}
.resume-public th{font-style:normal}.resume-public .liste{list-style:none;margin:0;padding:0}
.resume-public .liste li{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--line)}
.resume-public .liste li:last-child{border-bottom:0}.resume-public .liste b{font:800 18px/1 var(--f-display);white-space:nowrap}</style>"""
    # Préfixe rp- : la page de l'application a déjà ses propres .eq, .liste, .carte, etc.
    for c in ("eq", "pas", "liste", "carte", "barre", "note", "p", "n", "tbl", "duo"):
        resume = resume.replace(f'class="{c}"', f'class="rp-{c}"').replace(f'class="{c} ', f'class="rp-{c} ')
        style = re.sub(rf"\.resume-public (a)?\.{c}\b", lambda m: f".resume-public {m.group(1) or ''}.rp-{c}", style)
    if "<!-- public:resume -->" in src:
        src = src.replace("<!-- public:resume -->", style + resume, 1)
    return src


# ---------------------------------------------------------------------------------
# Construction complète
# ---------------------------------------------------------------------------------
def construire(pub, stats, dossier=None, log=print):
    """pub = données publiques (run.donnees_publiques), stats = sortie["stats"] (pour le bilan).
    Écrit tout dans un dossier temporaire puis remplace docs/public/ d'un coup : jamais de site à moitié écrit."""
    dossier = Path(dossier or DIR_SITE)
    mem = {}
    try:
        mem = json.loads(MEMOIRE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    mem = maj_memoire(pub, mem)
    MEMOIRE.parent.mkdir(parents=True, exist_ok=True)
    MEMOIRE.write_text(json.dumps(mem, ensure_ascii=False, indent=0), encoding="utf-8")
    slugs = liens_joueurs(mem)

    # Données de l'application : slugs ajoutés (liens vers les fiches), photos de la LNH retirées
    app = json.loads(json.dumps(pub))
    for j in app.get("joueurs") or []:
        j["slug"] = slugs.get(str(j.get("pid")))
        j["photo"] = None
    for B in ((app.get("trophees") or {}).get("trophees") or {}).values():
        for x in (B or {}).get("top") or []:
            x["slug"] = slugs.get(str(x.get("id")))
            x["no"] = (mem.get(str(x.get("id"))) or {}).get("no")   # numéro dans le rond, à la place de la photo
            x.pop("photo", None)

    pages = {}
    pages["index.html"] = page_app(pub, mem)
    c, h = page_trophees(pub, slugs, mem)
    pages[c + "index.html"] = h
    for fn in (page_equipes, page_coupe, page_apropos):
        c, h = fn(pub)
        pages[c + "index.html"] = h
    c, h = page_bilan(pub, stats)
    pages[c + "index.html"] = h
    c, h = page_confidentialite(pub)
    pages[c + "index.html"] = h
    for t in TROPHEES:
        c, h = page_trophee(t, pub, slugs, mem)
        pages[c + "index.html"] = h
    for t in TROPHEES_EQ:
        c, h = page_trophee_eq(t, pub)
        pages[c + "index.html"] = h
    for t in EQUIPES:
        c, h = page_equipe(t, pub, mem, slugs)
        pages[c + "index.html"] = h
    for pid, f in mem.items():
        if f.get("slug"):
            c, h = page_joueur(pid, f, pub, slugs)
            pages[c + "index.html"] = h
    pages["404.html"] = page_404()

    tmp = dossier.with_name(dossier.name + ".tmp")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    for chemin, contenu in pages.items():
        p = tmp / chemin
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(contenu, encoding="utf-8")
    # Le style de l'application + les règles des pages texte : un seul look partout
    m_css = re.search(r"<style>(.*?)</style>", (DOCS / "index.html").read_text(encoding="utf-8"), re.S)
    (tmp / "site.css").write_text((m_css.group(1) if m_css else "") + CSS_EXTRA, encoding="utf-8")
    (tmp / "public.json").write_text(json.dumps(app, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    for a in ACTIFS:
        if (DOCS / a).exists():
            shutil.copy2(DOCS / a, tmp / a)
    # Version française : mêmes pages en français sous fr/ (l'app française lit fr/public.json, mêmes images)
    import site_public_fr
    pages_fr = site_public_fr.construire_fr(pub, stats, mem, tmp / "fr")
    for a in ACTIFS + ("site.css", "public.json"):
        if (tmp / a).exists():
            shutil.copy2(tmp / a, tmp / "fr" / a)
    # Polices hébergées + bannière de consentement/pub, à la racine et dans fr/
    for dest in (tmp, tmp / "fr"):
        if (DOCS / "fonts").is_dir():
            shutil.copytree(DOCS / "fonts", dest / "fonts", dirs_exist_ok=True)
        if (DOCS / "pub.js").exists():
            shutil.copy2(DOCS / "pub.js", dest / "pub.js")
    # ads.txt : seulement quand le numéro AdSense est entré (Google le vérifie à la racine du domaine)
    client = adsense_client()
    if client:
        (tmp / "ads.txt").write_text(f"google.com, {client.replace('ca-pub-', 'pub-')}, DIRECT, f08c47fec0942fa0\n", encoding="utf-8")
    (tmp / "manifest.webmanifest").write_text(json.dumps({
        "name": NOM_SITE, "short_name": NOM_SITE, "start_url": "/", "display": "standalone", "lang": "en-CA",
        "background_color": "#0A2342", "theme_color": "#0A2342",
        "icons": [{"src": "icone-180.png", "sizes": "180x180", "type": "image/png"},
                  {"src": "icone-512.png", "sizes": "512x512", "type": "image/png"}]}, ensure_ascii=False), encoding="utf-8")
    (tmp / "robots.txt").write_text(f"User-agent: *\nAllow: /\nSitemap: {DOMAINE}/sitemap.xml\n", encoding="utf-8")
    jour = pub.get("date") or date.today().isoformat()
    urls = []
    for chemin in sorted(pages):
        if not chemin.endswith("index.html"):
            continue
        u = chemin[: -len("index.html")]
        quand = jour
        if u.startswith(P_JOUEURS):
            f = next((v for v in mem.values() if f"{P_JOUEURS}{v.get('slug')}/" == u), {})
            quand = (f.get("dernier") or {}).get("date") or f.get("vu") or jour
        urls.append(f"<url><loc>{DOMAINE}/{u}</loc><lastmod>{quand}</lastmod></url>")
        urls.append(f"<url><loc>{DOMAINE}/fr/{chemin_fr(u)}</loc><lastmod>{quand}</lastmod></url>")
    (tmp / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
                                     + "\n".join(urls) + "\n</urlset>\n", encoding="utf-8")
    (tmp / ".nojekyll").write_text("", encoding="utf-8")
    # Liste de tous les fichiers + empreinte : c'est ce que miroir.py (repo puckprob) lit pour copier
    fichiers = {}
    for p in sorted(tmp.rglob("*")):
        # Les fichiers cachés (.nojekyll) restent hors de la liste : Pages ne les sert pas chez Tirs-nhl
        if p.is_file() and not p.name.startswith("."):
            fichiers[p.relative_to(tmp).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    (tmp / "manifeste.json").write_text(json.dumps({"genere": pub.get("genere"), "date": jour, "fichiers": fichiers},
                                                   ensure_ascii=False, indent=0), encoding="utf-8")
    shutil.rmtree(dossier, ignore_errors=True)
    tmp.rename(dossier)
    n_j = sum(1 for c in pages if c.startswith(P_JOUEURS))
    log(f"  site public : {len(pages)} pages ({n_j} joueurs)")
    return len(pages)
